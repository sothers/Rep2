-- Demonstration 3A - Deadlock retry - second Window

USE Deadlock;
GO

DECLARE @RetryCount int = 5;

WHILE (@RetryCount > 0) -- retry update if deadlock victim
BEGIN
  BEGIN TRY
    BEGIN TRANSACTION;
      UPDATE dbo.Product SET ProductName = 'Prod 2 Modified 1'
        WHERE ProductID = 2;

      WAITFOR DELAY '00:00:10';

      UPDATE dbo.Product SET ProductName = 'Prod 1 Modified 1'
        WHERE ProductID = 1;
      SET @RetryCount = 0;
    COMMIT TRANSACTION;
  END TRY
  BEGIN CATCH 
    IF (ERROR_NUMBER() = 1205) -- deadlock victim
       BEGIN
         SET @RetryCount = @RetryCount - 1; 
         WAITFOR DELAY '00:00:02';
         PRINT 'Warning: Deadlock occurred';
       END
    ELSE
       SET @RetryCount = -1;
    IF XACT_STATE() <> 0
      ROLLBACK TRANSACTION;
  END CATCH;
END;

USE master;
GO
