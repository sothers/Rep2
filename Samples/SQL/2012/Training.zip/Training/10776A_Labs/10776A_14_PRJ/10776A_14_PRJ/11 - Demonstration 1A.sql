-- Demonstration 1A (Error types and severities)

-- Step 1: Open a new query window to MarketDev

USE MarketDev;
GO

-- Step 2: Note the returned error from a syntax error
--         Describe each returned entry in the error message

SELEC * FROM Marketing.Product;
GO

-- Step 3: Note the returned error from an object resolution error
--         Describe each returned entry in the error message

SELECT * FROM Dog;
GO

-- Step 4: Note the returned error from a runtime error
--         Describe each returned entry in the error message
--         and show how double-clicking the error in the messages
--         tab takes you directly to the error

SELECT 12/0;
GO

-- Step 5: Query the contents of the sys.messages view
--         Note the language_id settings

SELECT * FROM sys.messages;
GO

-- Step 6: Query the English messages only with 
--         severity 19 or above. Note the is_event_logged column

SELECT * 
FROM sys.messages
WHERE language_id = 1033
AND severity >= 19
ORDER BY severity, message_id;

