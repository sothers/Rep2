USE MarketDev;
GO

ALTER PROCEDURE Marketing.MoveCampaignBalance_Test
( @FromCampaignID int,
  @ToCampaignID int,
  @BalanceToMove decimal(18,2)
)
AS BEGIN
  DECLARE @RetriesRemaining int = 5;
  
  SET XACT_ABORT ON;
  
  WHILE (@RetriesRemaining > 0) BEGIN
    BEGIN TRY
      BEGIN TRANSACTION 
        UPDATE Marketing.CampaignBalance 
          SET RemainingBalance -= @BalanceToMove
          WHERE CampaignID = @FromCampaignID;
        UPDATE Marketing.CampaignBalance
          SET RemainingBalance += @BalanceToMove
          WHERE CampaignID = @ToCampaignID;
      COMMIT TRANSACTION;
      SET @RetriesRemaining = 0;
    END TRY
    BEGIN CATCH
      IF (ERROR_NUMBER() = 1205) BEGIN
        SET @RetriesRemaining -=1;
        PRINT 'Warning: deadlock retry';
        WAITFOR DELAY '00:00:05';
      END ELSE BEGIN
        SET @RetriesRemaining = 0; -- exit the retry loop
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        PRINT 'Unable to move balance';
        RETURN 1;
      END;
    END CATCH;
  END;
END;
GO
EXEC Marketing.MoveCampaignBalance_Test 3,2,51.50;
GO