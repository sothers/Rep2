USE MarketDev;
GO

CREATE PROCEDURE Marketing.MoveCampaignBalance_Test
( @FromCampaignID int,
  @ToCampaignID int,
  @BalanceToMove decimal(18,2)
)
AS BEGIN
  SET XACT_ABORT ON;
  BEGIN TRY
    BEGIN TRANSACTION 
      UPDATE Marketing.CampaignBalance 
        SET RemainingBalance -= @BalanceToMove
        WHERE CampaignID = @FromCampaignID;
      UPDATE Marketing.CampaignBalance
        SET RemainingBalance += @BalanceToMove
        WHERE CampaignID = @ToCampaignID;
    COMMIT TRANSACTION;
  END TRY
  BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    PRINT 'Unable to move balance';
    RETURN 1;                      -- 7
  END CATCH;
END;
GO
EXEC Marketing.MoveCampaignBalance_Test 3,2,51.50;
GO