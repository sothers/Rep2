-- Demonstration 2A (SQL Server Error Handling)

-- Step 6: Open another window and try to 
--         add the same error number
--         Note that messages are system wide
--         Applications could conflict with error numbers

USE tempdb;
GO

EXECUTE sp_addmessage 61485, 16,
        'Current DatabaseID: %d, Database Name: %s';
GO

-- Step 7: Return to main Demonstration 2A window

