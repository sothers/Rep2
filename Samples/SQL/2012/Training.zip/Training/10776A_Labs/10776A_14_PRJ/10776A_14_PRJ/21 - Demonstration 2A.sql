-- Demonstration 2A (SQL Server Error Handling)

-- Step 1: Open a new query window to tempdb

USE tempdb;
GO

-- Step 2: Use RAISERROR to raise an error of severity 10.
--         Note that in the results pane it is not displayed 
--         as an error

DECLARE @DatabaseID int = DB_ID();
DECLARE @DatabaseName sysname = DB_NAME();

RAISERROR
    (N'The current database ID is:%d, the database name is: %s.',
    10, -- Severity.
    1, -- State.
    @DatabaseID, -- First substitution argument.
    @DatabaseName); -- Second substitution argument.
GO

-- Step 3: See the difference when the severity is 16. It appears
--         as an error.

DECLARE @DatabaseID int = DB_ID();
DECLARE @DatabaseName sysname = DB_NAME();

RAISERROR
    (N'The current database ID is:%d, the database name is: %s.',
    16, -- Severity.
    1, -- State.
    @DatabaseID, -- First substitution argument.
    @DatabaseName); -- Second substitution argument.
GO

-- Step 4: Add a new custom error message

EXECUTE sp_addmessage 61485, 16,
        'Houston, we have a problem in DatabaseID: %d, Database Name: %s';
GO

-- Step 5: Raise the new custom error message

DECLARE @DatabaseID int = DB_ID();
DECLARE @DatabaseName sysname = DB_NAME();

RAISERROR (61485,16,1,@DatabaseID,@DatabaseName);
GO

-- Step 6: Open the Demonstration 2A - second window 
--         and try to add the same error number
--USE tempdb;
--GO

--EXECUTE sp_addmessage 61485, 16,
--        'Current DatabaseID: %d, Database Name: %s';
--GO
-- Step 7: Return here after executing in the second window

-- Step 8: Execute the following code using @@ERROR 
--         Note how the @@ERROR value is quickly cleared

RAISERROR(N'Message', 16, 1);
IF @@ERROR <> 0
  PRINT 'Error=' + CAST(@@ERROR AS VARCHAR(8));
GO

-- Step 9: Execute code to capture the @@ERROR value

DECLARE @ErrorValue int;
RAISERROR(N'Message', 16, 1);
SET @ErrorValue = @@ERROR;
IF @ErrorValue <> 0
  PRINT 'Error=' + CAST(@ErrorValue AS VARCHAR(8));
GO

-- Step 10: Try to raise a system error

RAISERROR (823, 19, 1);
GO

-- Step 11: Use THROW to raise an error

THROW 51245, 'Not Happy Now', 1;
GO
