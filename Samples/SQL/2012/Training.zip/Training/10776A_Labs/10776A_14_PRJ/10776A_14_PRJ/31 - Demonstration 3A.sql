-- Demonstration 3A - Deadlock retry - first Window

-- Step 1: Start SQL Profiler

-- Step 2: Create and start a new trace with only the Deadlock Graph event

-- Step 3: Execute the deadlock retry code in this window
--         and then immediately execute the code in the second window

-- Step 4: Note that both windows complete without apparent error

-- Step 5: Stop the profiler trace and view the graph

USE Deadlock;
GO

DECLARE @RetryCount int = 5;

WHILE (@RetryCount > 0) -- retry update if deadlock victim
BEGIN
  BEGIN TRY
    BEGIN TRANSACTION;
      UPDATE dbo.Product SET ProductName = 'Prod 1 Modified 2'
        WHERE ProductID = 1;

      WAITFOR DELAY '00:00:10';

      UPDATE dbo.Product SET ProductName = 'Prod 2 Modified 2'
        WHERE ProductID = 2;
      SET @RetryCount = 0;
    COMMIT TRANSACTION;
  END TRY
  BEGIN CATCH 
    IF (ERROR_NUMBER() = 1205) -- deadlock victim
       BEGIN
         SET @RetryCount = @RetryCount - 1; 
         WAITFOR DELAY '00:00:02';
         PRINT 'Warning: Deadlock occurred';
       END
    ELSE
       SET @RetryCount = -1;
    IF XACT_STATE() <> 0
      ROLLBACK TRANSACTION;
  END CATCH;
END;

USE master;
GO
