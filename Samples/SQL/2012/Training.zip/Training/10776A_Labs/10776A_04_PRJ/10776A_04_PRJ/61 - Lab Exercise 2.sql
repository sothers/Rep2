USE MarketDev;
GO

-- test default values and data types

INSERT INTO Marketing.Yield (ProspectID, LanguageID, Notes)
VALUES (1,'en', 'Excellent outcome');

SELECT * FROM Marketing.Yield;
GO

-- test primary key (should fail)

INSERT INTO Marketing.Yield (ProspectID, LanguageID, Notes)
VALUES (1,'en', 'Another excellent outcome');

SELECT * FROM Marketing.Yield;
GO

-- test foreign key reference on language (should fail)

INSERT INTO Marketing.Yield (ProspectID, LanguageID, Notes)
VALUES (2,'ex', 'Excellent outcome');

SELECT * FROM Marketing.Yield;
GO

-- test foreign key reference on prospect (should fail)

INSERT INTO Marketing.Yield (ProspectID, LanguageID, Notes)
VALUES (29292,'en', 'Excellent outcome');

SELECT * FROM Marketing.Yield;
GO

