--Lab Exercise 1

USE MarketDev;
GO

ALTER TABLE Marketing.Yield
  ALTER COLUMN ProspectID int NOT NULL;
GO

ALTER TABLE Marketing.Yield
  ALTER COLUMN LanguageID nchar(6) NOT NULL;
GO

ALTER TABLE Marketing.Yield
  ALTER COLUMN YieldOutcome int NOT NULL;
GO

ALTER TABLE Marketing.Yield
  ALTER COLUMN RowID uniqueidentifier NOT NULL;
GO

ALTER TABLE Marketing.Yield
  ALTER COLUMN LastUpdate datetime2 NOT NULL;
GO

ALTER TABLE Marketing.Yield
  ADD CONSTRAINT PK_Yield PRIMARY KEY CLUSTERED (ProspectID, LanguageID);
GO

ALTER TABLE Marketing.Yield
  ADD CONSTRAINT FK_Yield_Prospect
  FOREIGN KEY (ProspectID) REFERENCES Marketing.Prospect(ProspectID);
GO

ALTER TABLE Marketing.Yield
  ADD CONSTRAINT FK_Yield_Language
  FOREIGN KEY (LanguageID) REFERENCES Marketing.Language(LanguageID);
GO

ALTER TABLE Marketing.Yield
  ADD CONSTRAINT CHK_Yield_YieldOutcome_Range0To9
  CHECK (YieldOutcome BETWEEN 0 And 9);
GO

ALTER TABLE Marketing.Yield
  ADD CONSTRAINT DF_Yield_YieldOutcome
  DEFAULT (0) FOR YieldOutcome;
GO

ALTER TABLE Marketing.Yield
  ADD CONSTRAINT DF_Yield_RowID
  DEFAULT (NEWID()) FOR RowID;
GO

ALTER TABLE Marketing.Yield
  ADD CONSTRAINT DF_Yield_LastUpdate
  DEFAULT (SYSDATETIME()) FOR LastUpdate;
GO
