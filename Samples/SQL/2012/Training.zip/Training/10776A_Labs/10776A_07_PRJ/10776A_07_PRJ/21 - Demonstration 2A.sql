-- Demonstration 2A

-- Step 1: Open a new query window to the AdventureWorks database

USE AdventureWorks;
GO

-- Step 2: On the query menu, choose to Include Actual Execution Plan

-- Step 3: Execute a query that performs a table scan

SELECT * FROM dbo.DatabaseLog;
GO

-- Step 4: Note the plan returned and use Object Browser to inspect the structure of the table. Note if the table is a heap or has a clustered index.

-- Step 5: Execute a query involving a Clustered Index Scan

SELECT * FROM Person.Contact;
GO

-- Step 6: Execute a query involving a Clustered Index Seek

SELECT * FROM Person.Contact WHERE ContactID = 12;
GO


-- Step 7: Execute a query involving a Sort

SELECT * 
FROM Production.ProductInventory
ORDER BY Shelf;
GO


-- Step 8: Execute a query involving a RID Lookup and Nested Loops

SELECT * FROM dbo.DatabaseLog WHERE DatabaseLogID = 1;
GO

-- Step 9: Execute a query involving a Merge Join and a Hash Match

SELECT c.CustomerID
FROM Sales.SalesOrderDetail AS od
INNER JOIN Sales.SalesOrderHeader AS oh
ON od.SalesOrderID = oh.SalesOrderID
INNER JOIN Sales.Customer AS c
ON oh.CustomerID = c.CustomerID;
GO

-- Question: Why was SQL Server able to join with a Merge Join in one place
--           but needed a Hash Match in another?

-- Step 10: Obtain an estimated execution plan for this statement
--          (note that executing it would cause it to fail)

DELETE FROM Person.Address
WHERE AddressID = 52;
GO

-- Question: Why is the plan for a simple delete so complex?

