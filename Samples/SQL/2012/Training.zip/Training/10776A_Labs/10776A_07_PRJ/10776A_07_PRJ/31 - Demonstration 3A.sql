-- Demonstration 3A

-- Step 1: Open Activity Monitor from the toolbar

-- Step 2: Expand the Recent Expensive Queries node by clicking on it

-- Step 3: Note the available columns

-- Step 4: Right-click a query in the list and choose Edit Query Text

-- Step 5: Quickly review the window and close it

-- Step 6: Right-click a query in the list and choose Show Execution Plan

-- Step 7: Quickly review the window and close it
