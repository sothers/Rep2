-- Demonstration 1A

-- Step 1: Open a new query window to the AdventureWorks database

USE AdventureWorks;
GO

-- Step 2: Highlight a query and from the query menu, choose Display Estimated Execution Plan

SELECT ProductID, Name, Color 
FROM Production.Product
WHERE Color IN ('Blue','Red')
ORDER BY Name;
GO

-- Step 3: Request an estimated execution plan for a batch that creates an object then accesses it
--         (Highlight the following code, then hit Ctrl-L)

CREATE TABLE SomeTable
( SomeTableID INT IDENTITY(1, 1) PRIMARY KEY,
  FullName varchar(35)
);
INSERT INTO SomeTable VALUES('Hello'),('There');
SELECT * FROM SomeTable;
DROP TABLE SomeTable;
GO

-- Step 4: Note the returned error

-- Step 5: Use the estimated execution plan to compare two queries

SELECT p.ProductID, p.Name, p.Color, p.Size
FROM Production.Product AS p
LEFT OUTER JOIN Production.ProductModel AS pm
ON p.ProductModelID = pm.ProductModelID 
WHERE pm.ProductModelID IS NOT NULL;
GO
SELECT p.ProductID, p.Name, p.Color, p.Size
FROM Production.Product AS p
WHERE EXISTS(SELECT 1 FROM Production.ProductModel AS pm
             WHERE p.ProductModelID = pm.ProductModelID);
GO

-- Step 6: Compare the costs and the plan

-- Question: How do you explain that such different queries return the same plan?

-- Step 7: From the query menu, choose Include Actual Execution Plan

-- Step 8: Execute the query

SELECT ProductID, Name, Color 
FROM Production.Product
WHERE Color IN ('Blue','Red')
ORDER BY Name;
GO

-- Step 9: Click on the Execution Plan tab to see the plan used

-- Step 10: Right-click on the plan and choose "Show Execution Plan XML"

-- Step 11: Briefly show the XML plan and then close it

-- Step 12: Right-click on the plan and choose "Save Execution Plan As"

-- Step 13: Note the suggested file type as .sqlplan


