USE MarketDev;
GO

SELECT * FROM sys.stats WHERE object_id = OBJECT_ID('Marketing.Product');
GO

CREATE STATISTICS Product_Color_Stats ON Marketing.Product (Color)
WITH FULLSCAN;
GO

SELECT * FROM sys.stats WHERE object_id = OBJECT_ID('Marketing.Product');
GO

DBCC SHOW_STATISTICS('Marketing.Product',Product_Color_Stats);
GO

SELECT COUNT(1) FROM Marketing.Product WHERE Color = 'Black';
GO

-- Calculate the total number of rows in the table

SELECT COUNT(1) FROM Marketing.Prospect;
GO

-- Query 1

SELECT ProspectID, FirstName, LastName 
FROM Marketing.Prospect 
WHERE FirstName LIKE 'A%';

-- Query 2

SELECT ProspectID, FirstName, LastName 
FROM Marketing.Prospect 
WHERE FirstName LIKE 'Alejandro%';

-- Query 3

SELECT ProspectID, FirstName, LastName 
FROM Marketing.Prospect 
WHERE FirstName LIKE 'Arif%';
GO
