USE MarketDev;
GO

-- Query 1

SELECT ProspectID, FirstName, LastName 
FROM Marketing.Prospect 
WHERE ProspectID = 12553;

-- Query 2

SELECT ProspectID, FirstName, LastName 
FROM Marketing.Prospect 
WHERE FirstName LIKE 'Arif%';

-- Query 3

SELECT ProspectID, FirstName, LastName 
FROM Marketing.Prospect 
WHERE FirstName = 'Alejandro'
ORDER BY LastName, FirstName;

-- Query 4

SELECT ProspectID, FirstName, LastName 
FROM Marketing.Prospect 
WHERE FirstName >= 'S'
ORDER BY LastName, FirstName;

-- Query 5

SELECT LanguageID, COUNT(1)
FROM Marketing.ProductDescription
GROUP BY LanguageID;
GO