-- Demonstration 3A

-- Step 1: Open a new query window to the AdventureWorks database

USE AdventureWorks;
GO

-- Step 2: Explore the existing statistics on the Person.Contact table.
--         There may or may not be statistics available. If they are
--         present and have a _WA prefix, they are autostats.

SELECT * FROM sys.stats WHERE object_id = OBJECT_ID('Person.Contact');
GO

-- Step 3: Create statistics on the FirstName column in the Person.Contact table

CREATE STATISTICS Person_FirstName_Stats ON Person.Contact (FirstName)
WITH FULLSCAN;
GO

-- Step 4: Check the list of statistics again

SELECT * FROM sys.stats WHERE object_id = OBJECT_ID('Person.Contact');
GO

-- Step 5: Use DBCC SHOW_STATISTICS to obtain details of the new statistics

DBCC SHOW_STATISTICS('Person.Contact',Person_FirstName_Stats);
GO

-- Step 6: Note how many rows exist for the name Abigail

-- Step 7: Execute a query to count the rows to see if the statistics are accurate

SELECT COUNT(1) FROM Person.Contact WHERE FirstName = 'Abigail';
GO