USE MarketDev;
GO

CREATE TABLE Relationship.Table_Heap
( ApplicationID INT IDENTITY(1,1),
  ApplicantName NVARCHAR(150),
  EmailAddress NVARCHAR(100),
  ReferenceID UNIQUEIDENTIFIER,
  Comments NVARCHAR(500)
);
GO

CREATE TABLE Relationship.Table_ApplicationID
( ApplicationID INT IDENTITY(1,1),
  ApplicantName NVARCHAR(150),
  EmailAddress NVARCHAR(100),
  ReferenceID UNIQUEIDENTIFIER,
  Comments NVARCHAR(500)
);
GO
CREATE CLUSTERED INDEX IX_ApplicantID
  ON Relationship.Table_ApplicationID (ApplicationID);
GO

CREATE TABLE Relationship.Table_EmailAddress
( ApplicationID INT IDENTITY(1,1),
  ApplicantName NVARCHAR(150),
  EmailAddress NVARCHAR(100),
  ReferenceID UNIQUEIDENTIFIER,
  Comments NVARCHAR(500)
);
GO
CREATE CLUSTERED INDEX IX_EmailAddress
  ON Relationship.Table_EmailAddress (EmailAddress);
GO

CREATE TABLE Relationship.Table_ReferenceID
( ApplicationID INT IDENTITY(1,1),
  ApplicantName NVARCHAR(150),
  EmailAddress NVARCHAR(100),
  ReferenceID UNIQUEIDENTIFIER,
  Comments NVARCHAR(500)
);
GO
CREATE CLUSTERED INDEX IX_ReferenceID
  ON Relationship.Table_ReferenceID (ReferenceID);
GO
