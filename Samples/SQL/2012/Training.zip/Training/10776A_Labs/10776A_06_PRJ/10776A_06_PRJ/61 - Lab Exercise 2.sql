USE MarketDev;
GO

CREATE TABLE Relationship.MediaOutlet
( MediaOutletID INT PRIMARY KEY CLUSTERED,
  MediaOutletName NVARCHAR(40),
  PrimaryContact NVARCHAR(50),
  City NVARCHAR(50)
);
GO

CREATE TABLE Relationship.PrintMediaPlacement
( PrintMediaPlacementID INT PRIMARY KEY CLUSTERED,
  MediaOutletID INT,
  PlacementDate DATETIME,
  PublicationDate DATETIME,
  RelatedProductID INT,
  PlacementCost DECIMAL(18,2)
);
GO

