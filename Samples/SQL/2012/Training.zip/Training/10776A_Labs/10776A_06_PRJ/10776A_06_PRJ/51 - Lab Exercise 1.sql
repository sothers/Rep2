USE MarketDev;
GO

CREATE TABLE Relationship.ActivityLog
( ActivityTime DATETIMEOFFSET,
  SessionID INT,
  Duration INT,
  ActivityType INT
);
GO

CREATE TABLE Relationship.PhoneLog
( PhoneLogID INT PRIMARY KEY NONCLUSTERED,
  SalespersonID INT,
  CalledPhoneNumber NVARCHAR(16),
  CallDurationSeconds INT
);
GO

