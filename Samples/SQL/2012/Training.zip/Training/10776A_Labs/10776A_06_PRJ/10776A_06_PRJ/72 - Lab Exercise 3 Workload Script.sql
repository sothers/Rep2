--Module 06 - Test Workload for Exercise 3

USE MarketDev;
GO

DECLARE @Counter INT;
DECLARE @StartTime DATETIME2;
DECLARE @HeapFinish DATETIME2;
DECLARE @ApplicationIDFinish DATETIME2;
DECLARE @EmailAddressFinish DATETIME2;
DECLARE @ReferenceIDFinish DATETIME2;

SET NOCOUNT ON;

SET @StartTime = SYSDATETIME();
SET @Counter = 0;

WHILE (@Counter < 20) BEGIN
  INSERT Relationship.Table_Heap
    (ApplicantName, EmailAddress, ReferenceID, Comments)
  SELECT p.FirstName + ' ' + p.LastName,
         p.EmailAddress,
         NEWID(),
         REPLICATE('A',500)
  FROM Marketing.Prospect AS p;
  SET @Counter += 1;
END;

SET @HeapFinish = SYSDATETIME();

PRINT 'Heap loaded';

SET @Counter = 0;

WHILE (@Counter < 20) BEGIN
  INSERT Relationship.Table_ApplicationID
    (ApplicantName, EmailAddress, ReferenceID, Comments)
  SELECT p.FirstName + ' ' + p.LastName,
         p.EmailAddress,
         NEWID(),
         REPLICATE('A',500)
  FROM Marketing.Prospect AS p;
  SET @Counter += 1;
END;

SET @ApplicationIDFinish = SYSDATETIME();

PRINT 'ApplicationID Table Loaded';

SET @Counter = 0;

WHILE (@Counter < 20) BEGIN
  INSERT Relationship.Table_EmailAddress
    (ApplicantName, EmailAddress, ReferenceID, Comments)
  SELECT p.FirstName + ' ' + p.LastName,
         p.EmailAddress,
         NEWID(),
         REPLICATE('A',500)
  FROM Marketing.Prospect AS p;
  SET @Counter += 1;
END;

SET @EmailAddressFinish = SYSDATETIME();

PRINT 'EmailAddress Table Loaded';

SET @Counter = 0;

WHILE (@Counter < 20) BEGIN
  INSERT Relationship.Table_ReferenceID
    (ApplicantName, EmailAddress, ReferenceID, Comments)
  SELECT p.FirstName + ' ' + p.LastName,
         p.EmailAddress,
         NEWID(),
         REPLICATE('A',500)
  FROM Marketing.Prospect AS p;
  SET @Counter += 1;
END;

SET @ReferenceIDFinish = SYSDATETIME();

PRINT 'ReferenceID Table Loaded';

SELECT DATEDIFF(second,@StartTime,@HeapFinish) AS HeapTime,
       DATEDIFF(second,@HeapFinish,@ApplicationIDFinish) AS ApplicationIDTime,
       DATEDIFF(second,@ApplicationIDFinish,@EmailAddressFinish) AS EmailAddressTime,
       DATEDIFF(second,@EmailAddressFinish,@ReferenceIDFinish) AS ReferenceIDTime;
       

