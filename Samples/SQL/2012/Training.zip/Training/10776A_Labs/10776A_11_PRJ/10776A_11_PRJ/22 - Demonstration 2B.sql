-- Demonstration 2B

-- Step 1 - Open a new query window to the tempdb database

USE tempdb;
GO

-- Step 2 - Many users have not worked with row constructors
--          so show a few common uses - start by creating a test table


CREATE TABLE dbo.TestTable
( TestTableID int IDENTITY,
  ValueA int,
  ValueB int
);
GO

-- Step 3 - Perform a multi-row insert

INSERT INTO TestTable (ValueA,ValueB) 
  VALUES(1, 2), (3, 4), (5, 6);
GO

-- Step 4 - Show that sub-selects are now also
--          permitted in the values clause in INSERT statements

INSERT INTO TestTable (ValueA,ValueB) 
  VALUES
   ((SELECT MIN(ValueA) FROM TestTable),(SELECT MAX(ValueA) FROM TestTable)), 
   ((SELECT MIN(ValueB) FROM TestTable), 4);
GO

SELECT * FROM dbo.TestTable;
GO

-- Step 5 - Show that a VALUES clause can be used without
--          an INSERT statement to construct a table on
--          the fly. Mention that we will use this ability
--          in the last lesson in this module. Note also that
--          this example also uses the alternate method for
--          assigning column aliases (within the table alias
--          rather than in an AS clause after each column)

SELECT * FROM (VALUES(1), (2), (3), (4)) AS SomeTable(SomeColumn);
GO

-- Step 6 - Create the CustomerBalance table type

CREATE TYPE dbo.CustomerBalance
AS TABLE ( CustomerID int,
           CurrentBalance decimal(18,2));
GO

-- Step 7 - Declare a variable of type CustomerBalance and
--          populate it with 3 rows

DECLARE @Balance dbo.CustomerBalance;

INSERT INTO @Balance
  VALUES (12,14.50),(15,13.75),(22,19.50);

SELECT * FROM @Balance;
GO

-- Step 8 - Do the same operation with the SELECT statement
--          in a separate batch - note that like all variables
--          table variables are batch scoped and an error occurs

DECLARE @Balance dbo.CustomerBalance;

INSERT INTO @Balance
  VALUES (12,14.50),(15,13.75),(22,19.50);

GO
SELECT * FROM @Balance;
GO

