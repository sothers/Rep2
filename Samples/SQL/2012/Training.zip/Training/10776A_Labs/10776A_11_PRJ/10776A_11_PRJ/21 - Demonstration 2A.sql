-- Demonstraton 2A

-- Step 1 - Open a new query window to the MarketDev database on the Marketing server

USE MarketDev;
GO

-- Step 2 - Select from the dbo.StringListToTable function

DECLARE @CustomerList nvarchar(200);

SET @CustomerList = '12,15,99,214,228,917';

SELECT * FROM dbo.StringListToTable(@CustomerList,',');
GO

-- Step 3 - Try a different delimiter

DECLARE @CustomerList nvarchar(200);

SET @CustomerList = '12|15|99|214|228|917';

SELECT * FROM dbo.StringListToTable(@CustomerList,'|');
GO

-- Step 4 - Use the function in a join
--          Even though it "works", what is the issue?


DECLARE @CustomerList nvarchar(200);

SET @CustomerList = '12,15,99,214,228,917';

SELECT * 
FROM dbo.StringListToTable(@CustomerList,',') AS sl
INNER JOIN Marketing.Prospect AS p
ON sl.StringValue = p.ProspectID
ORDER BY p.ProspectID;
GO

-- Step 5 - Execute a query with an incorrectly formed list
--          to discover the issue

DECLARE @CustomerList nvarchar(200);

SET @CustomerList = '12,15,99A,214,228,917';

SELECT * 
FROM dbo.StringListToTable(@CustomerList,',') AS sl
INNER JOIN Marketing.Prospect AS p
ON sl.StringValue = p.ProspectID
ORDER BY p.ProspectID;
GO

 