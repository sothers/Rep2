USE MarketDev;
GO

CREATE PROCEDURE Reports.GetProductsByColorList_Test
(@ColorList StringList READONLY)
AS
SELECT p.ProductID, 
       p.ProductName, 
       p.ListPrice AS Price, 
       p.Color, 
       p.Size,
       p.SizeUnitMeasureCode AS UnitOfMeasure
FROM Marketing.Product AS p
INNER JOIN @ColorList AS cl
ON p.Color = cl.StringValue  
ORDER BY p.ProductName;
GO

DECLARE @ColorList StringList;
INSERT INTO @ColorList VALUES('Red'),('Blue'),('Silver');
EXEC Reports.GetProductsByColorList_Test @ColorList;
GO

