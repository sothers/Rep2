-- Demonstration 1A

-- Step 1 - Open a new query window to tempdb

USE tempdb;
GO

-- Step 2 - Create a master table and populate some rows

CREATE TABLE dbo.Employee
( EmployeeID int PRIMARY KEY,
  FullName nvarchar(40),
  EmploymentStatus int
);
GO

INSERT INTO dbo.Employee  (EmployeeID, FullName, EmploymentStatus)
  VALUES (1, 'David Hamilton',1);
INSERT INTO dbo.Employee  (EmployeeID, FullName, EmploymentStatus)
  VALUES (2, 'Nupur Argawal',1);
INSERT INTO dbo.Employee  (EmployeeID, FullName, EmploymentStatus)
  VALUES (3, 'Guido Pica',2);
INSERT INTO dbo.Employee  (EmployeeID, FullName, EmploymentStatus)
  VALUES (4, 'Kim Truelsen',1);
GO

-- Step 3 - Create a table of updates and populate some rows
--          Note that we are updating David Hamilton's employment
--          status and Kim Truelsen is now Kim Akers. Also, we
--          have a new employee

CREATE TABLE dbo.EmployeeUpdate
( EmployeeUpdateID int IDENTITY(1,1) PRIMARY KEY,
  EmployeeID int NOT NULL,
  FullName nvarchar(40) NULL,
  EmploymentStatus int NULL
);
GO

INSERT INTO dbo.EmployeeUpdate (EmployeeID,FullName,EmploymentStatus)
VALUES (1, 'David Hamilton',2);
INSERT INTO dbo.EmployeeUpdate (EmployeeID,FullName,EmploymentStatus)
VALUES (4, 'Kim Akers',1);
INSERT INTO dbo.EmployeeUpdate (EmployeeID,FullName,EmploymentStatus)
VALUES (5, 'Phyllis Harris',1);
GO

-- Step 4 - Perform the merge and note the use of the OUTPUT clause

MERGE INTO dbo.Employee AS e
USING dbo.EmployeeUpdate AS eu
ON e.EmployeeID = eu.EmployeeID
WHEN MATCHED THEN
    UPDATE SET e.FullName = eu.FullName,
               e.EmploymentStatus = eu.EmploymentStatus
WHEN NOT MATCHED THEN
    INSERT (EmployeeID, FullName, EmploymentStatus)
        VALUES (eu.EmployeeID, eu.FullName, eu.EmploymentStatus)
OUTPUT $action, inserted.EmployeeID, deleted.EmployeeID;
GO

-- Step 5 - Query the target table

SELECT * FROM dbo.Employee;
GO

-- Step 6 - Now repopulate the EmployeeUpdate table
--          Note that only values that are changing are provided

DELETE FROM dbo.EmployeeUpdate;
GO

INSERT INTO dbo.EmployeeUpdate (EmployeeID,FullName,EmploymentStatus)
VALUES (1, NULL,3);
INSERT INTO dbo.EmployeeUpdate (EmployeeID,FullName,EmploymentStatus)
VALUES (5, 'Kim Truelsen',NULL);
INSERT INTO dbo.EmployeeUpdate (EmployeeID,FullName,EmploymentStatus)
VALUES (6, 'David Alexander',1);
GO
SELECT * FROM dbo.EmployeeUpdate;
GO

-- Step 7 - Change the MERGE statement to only update columns
--          where a value has been provided

MERGE INTO dbo.Employee AS e
USING dbo.EmployeeUpdate AS eu
ON e.EmployeeID = eu.EmployeeID
WHEN MATCHED THEN
    UPDATE SET e.FullName = COALESCE(eu.FullName,e.FullName),
               e.EmploymentStatus = COALESCE(eu.EmploymentStatus,e.EmploymentStatus)
WHEN NOT MATCHED THEN
    INSERT (EmployeeID, FullName, EmploymentStatus)
        VALUES (eu.EmployeeID, eu.FullName, eu.EmploymentStatus)
OUTPUT $action, inserted.EmployeeID, deleted.EmployeeID;
GO
SELECT * FROM dbo.Employee;
GO

-- Step 8 - Create an audit table

CREATE TABLE dbo.NewEmployeeAudit
( NewEmployeeAuditID int IDENTITY(1,1) PRIMARY KEY,
  EmployeeAdded datetime2 DEFAULT (SYSDATETIME()),
  EmployeeID int,
  FullName nvarchar(40),
  EmploymentStatus int
);
GO

-- Step 9 - Repopulate the employeeupdate table

DELETE FROM dbo.EmployeeUpdate;
GO

INSERT INTO dbo.EmployeeUpdate (EmployeeID,FullName,EmploymentStatus)
VALUES (1, NULL,1);
INSERT INTO dbo.EmployeeUpdate (EmployeeID,FullName,EmploymentStatus)
VALUES (5, NULL,2);
INSERT INTO dbo.EmployeeUpdate (EmployeeID,FullName,EmploymentStatus)
VALUES (7, 'Mark Alexieff',3);
GO
SELECT * FROM dbo.EmployeeUpdate;
GO

-- Step 10 - Use the output of the OUTPUT clause as in the input
--           to a SELECT statement - note the use of the WHERE
--           clause which makes this more powerful than OUTPUT INTO

INSERT INTO dbo.NewEmployeeAudit 
  (EmployeeID, FullName, EmploymentStatus)
SELECT EmployeeID, FullName, EmploymentStatus 
FROM ( MERGE INTO dbo.Employee AS e
       USING dbo.EmployeeUpdate AS eu
       ON e.EmployeeID = eu.EmployeeID
       WHEN MATCHED THEN
           UPDATE SET e.FullName = COALESCE(eu.FullName,e.FullName),
                      e.EmploymentStatus = COALESCE(eu.EmploymentStatus,e.EmploymentStatus)
       WHEN NOT MATCHED THEN
           INSERT (EmployeeID, FullName, EmploymentStatus)
             VALUES (eu.EmployeeID, eu.FullName, eu.EmploymentStatus)
       OUTPUT $action AS Action, 
              inserted.EmployeeID,
              inserted.FullName,
              inserted.EmploymentStatus
     ) AS EmployeeChanges
WHERE EmployeeChanges.Action = 'INSERT';
GO

-- Step 11 - Query the employee table and the audit table

SELECT * FROM dbo.Employee;
GO
SELECT * FROM dbo.NewEmployeeAudit;
GO

-- Step 12 - Perform a MERGE with a VALUES clause as the source

MERGE INTO dbo.Employee AS e
USING (VALUES (1,NULL,2),(8,'Roger Harui',1)) 
      AS eu(EmployeeID,FullName,EmploymentStatus)
ON e.EmployeeID = eu.EmployeeID
WHEN MATCHED THEN
    UPDATE SET e.FullName = COALESCE(eu.FullName,e.FullName),
               e.EmploymentStatus = COALESCE(eu.EmploymentStatus,e.EmploymentStatus)
WHEN NOT MATCHED THEN
    INSERT (EmployeeID, FullName, EmploymentStatus)
        VALUES (eu.EmployeeID, eu.FullName, eu.EmploymentStatus)
OUTPUT $action, inserted.EmployeeID, deleted.EmployeeID;
GO
SELECT * FROM dbo.Employee;
GO
