USE MarketDev;
GO

CREATE TYPE StringList AS TABLE(StringValue nvarchar(1000) NOT NULL);
GO

