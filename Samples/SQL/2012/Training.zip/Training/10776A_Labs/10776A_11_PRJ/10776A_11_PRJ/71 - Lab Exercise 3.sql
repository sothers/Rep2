USE MarketDev;
GO

CREATE TYPE dbo.SalespersonList 
AS TABLE (SalespersonID int NOT NULL,
          FirstName nvarchar(50) NULL,
          MiddleName nvarchar(50) NULL,
          LastName nvarchar(50) NULL,
          BadgeNumber nvarchar(15) NULL,
          EmailAlias nvarchar(256) NULL,
          SalesTerritoryID int NULL);
GO
                                    
CREATE PROCEDURE Marketing.SalespersonMerge
(@SalespersonDetails SalespersonList READONLY)
AS BEGIN
  MERGE INTO Marketing.Salesperson AS sp
  USING @SalespersonDetails AS spd
  ON sp.SalespersonID = spd.SalespersonID 
  WHEN MATCHED THEN
    UPDATE SET 
      sp.FirstName = COALESCE(spd.FirstName, sp.FirstName),
      sp.MiddleName = COALESCE(spd.MiddleName, sp.MiddleName),
      sp.LastName = COALESCE(spd.LastName, sp.LastName),
      sp.BadgeNumber = COALESCE(spd.BadgeNumber, sp.BadgeNumber),
      sp.EmailAlias = COALESCE(spd.EmailAlias, sp.EmailAlias),
      sp.SalesTerritoryID = COALESCE(spd.SalesTerritoryID, sp.SalesTerritoryID)
  WHEN NOT MATCHED THEN
    INSERT (SalespersonID, 
            FirstName,
            MiddleName,
            LastName,
            BadgeNumber,
            EmailAlias,
            SalesTerritoryID)
    VALUES (spd.SalespersonID, 
            spd.FirstName,
            spd.MiddleName,
            spd.LastName,
            spd.BadgeNumber,
            spd.EmailAlias,
            spd.SalesTerritoryID)
  OUTPUT $action AS Action, inserted.SalespersonID;
END;
GO

DECLARE @Salespeople SalespersonList;
INSERT INTO @Salespeople 
  (SalespersonID, 
   FirstName,
   MiddleName,
   LastName,
   BadgeNumber,
   EmailAlias,
   SalesTerritoryID)
VALUES
  (276,'Michael','','Wong',NULL,'adventure-works\mwong',NULL),
  (601,'John','','Wong','234232','adventure-works\jwong',3);
EXEC Marketing.SalespersonMerge @Salespeople;
GO
