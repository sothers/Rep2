USE MarketDev;
GO

CREATE SCHEMA WebStock AUTHORIZATION dbo;
GO

CREATE VIEW WebStock.OnlineProducts
AS
SELECT p.ProductID, 
       p.ProductName, 
       p.ProductNumber, 
       COALESCE(p.Color,'N/A') AS Color, 
       CASE p.DaysToManufacture
         WHEN 0 THEN 'Instock'
         WHEN 1 THEN 'Overnight'
         WHEN 2 THEN 'Fast'
         ELSE 'Call'
       END AS Availability,
       p.Size, 
       p.SizeUnitMeasureCode AS UnitOfMeasure,
       p.ListPrice AS Price, 
       p.Weight
FROM Marketing.Product AS p
WHERE p.SellEndDate IS NULL
AND p.SellStartDate IS NOT NULL;
GO

CREATE VIEW WebStock.AvailableModels
AS
SELECT p.ProductID,
       p.ProductName,
       pm.ProductModelID,
       pm.ProductModel 
FROM Marketing.Product AS p
INNER JOIN Marketing.ProductModel AS pm
ON p.ProductModelID = pm.ProductModelID 
WHERE p.SellEndDate IS NULL
AND p.SellStartDate IS NOT NULL;
GO


SELECT * FROM WebStock.OnlineProducts;
GO

SELECT * FROM WebStock.AvailableModels;
GO

