USE MarketDev;
GO

ALTER VIEW WebStock.AvailableModels
AS
SELECT p.ProductID,
       p.ProductName,
       pm.ProductModelID,
       pm.ProductModel,
       COALESCE(ed.Description,id.Description) AS CatalogDescription
FROM Marketing.Product AS p
INNER JOIN Marketing.ProductModel AS pm
ON p.ProductModelID = pm.ProductModelID 
LEFT OUTER JOIN Marketing.ProductDescription AS ed
ON pm.ProductModelID = ed.ProductModelID 
AND ed.LanguageID = 'en'
LEFT OUTER JOIN Marketing.ProductDescription as id
ON pm.ProductModelID = id.ProductModelID 
AND id.LanguageID = ''
WHERE p.SellEndDate IS NULL
AND p.SellStartDate IS NOT NULL;
GO

SELECT * FROM WebStock.AvailableModels;
GO
