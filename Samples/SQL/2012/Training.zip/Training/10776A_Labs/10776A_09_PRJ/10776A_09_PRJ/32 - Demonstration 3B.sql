-- Demonstration 3A

-- Step 1: Use the AdventureWorks database

USE AdventureWorks;
GO

-- Step 2: Expand the views node in the AdventureWorks database in Object Explorer
--         (From View menu, click Object Explorer, expand Databases, expand AdventureWorks)

-- Step 3: Expand the Purchasing.vVendor view and the indexes node within it
--         (In Object Explorer, expand Views, expand the Purchasing.vVendor view, 
--         and expand Indexes).

-- Step 4: Right-click the view and choose SELECT TOP ... ROWS
--         (Right-click the Purchasing.vVendor view and 
--          click Select Top 1000 Rows).

-- Step 5: From the Query menu, choose Display Estimated Execution Plan 
--         (Note the large number of tables involved and that the view is not one of the objects shown)

-- Step 6: Now expand the indexes node within the Person.vStateProvinceCountryRegion view
--         (In Object Explorer, expand Databases, expand AdventureWorks, expand Views, 
--          expand Person.vStateProvinceCountryRegion, and expand Indexes. Note the 
--          IX_vStateProvinceCountryRegion (Clustered) index that is present).

-- Step 7: Right-click the view and choose SELECT TOP ... ROWS
--         (In Object Explorer, right-click the Person.vStateProvinceCountryRegion 
--          view and click Select Top 1000 Rows).

-- Step 8: From the Query menu, choose Display Estimated Execution Plan 
--         (Note that a clustered index scan is shown for the view object)

-- Step 9: Right-click the index on the view (in object explorer) and choose
--         options to script the index
--         (In Object Explorer, expand Databases, expand AdventureWorks, 
--          expand Views, right-click the Person.vStateProvinceCountryRegion, 
--          expand Indexes and right-click IX_vStateProvinceCountryRegion (Clustered), 
--          click Script Index as, click CREATE To, and click New Query Editor Window). 

-- Step 10: Note the definition of the index and note the SET options specified

