USE MarketDev;
GO

CREATE SCHEMA Relationship AUTHORIZATION dbo;
GO

CREATE VIEW Relationship.Contacts
AS
SELECT p.ProspectID AS ContactID,
       p.FirstName,
       p.MiddleName,
       p.LastName,
       'PROSPECT' AS ContactRole
FROM Marketing.Prospect AS p
UNION ALL 
SELECT sp.SalespersonID,
       sp.FirstName,
       sp.MiddleName,
       sp.LastName,
       'SALESPERSON'
FROM Marketing.Salesperson AS sp;
GO

SELECT * FROM Relationship.Contacts;
GO