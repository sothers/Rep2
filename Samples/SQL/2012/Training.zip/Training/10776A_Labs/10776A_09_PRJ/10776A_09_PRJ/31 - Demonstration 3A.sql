-- Demonstration 3A

-- Step 1 - Open a new query window to the AdventureWorks database

USE AdventureWorks;
GO

-- Step 2 - Create a view

CREATE VIEW dbo.EmployeeName AS
SELECT e.EmployeeID, c.LastName, c.FirstName
FROM HumanResources.Employee AS e 
JOIN Person.Contact AS c
ON e.EmployeeID = c.ContactID;
GO

-- Step 3 - Query the view and request an estimated query plan 

SELECT * FROM dbo.EmployeeName;
GO

-- Step 4 - Request an estimated query plan for both the following queries at once.

/* SELECT referencing the EmployeeName view. */
SELECT LastName AS EmployeeLastName, SalesOrderID, OrderDate
FROM AdventureWorks.Sales.SalesOrderHeader AS soh
JOIN AdventureWorks.dbo.EmployeeName AS EmpN
ON (soh.SalesPersonID = EmpN.EmployeeID)
WHERE OrderDate > '20020531';

/* SELECT referencing the Person and Employee tables directly. */
SELECT LastName AS EmployeeLastName, SalesOrderID, OrderDate
FROM AdventureWorks.HumanResources.Employee AS e 
JOIN AdventureWorks.Sales.SalesOrderHeader AS soh
ON soh.SalesPersonID = e.EmployeeID
JOIN AdventureWorks.Person.Contact AS c
ON e.EmployeeID = c.ContactID
WHERE OrderDate > '20020531';
GO

-- Step 5 - Compare the relative query costs

-- Step 6 - Drop the view

DROP VIEW dbo.EmployeeName;
GO

-- Step 7 - Create another view

CREATE VIEW dbo.PersonAddress
AS
SELECT c.ContactID,
       c.LastName,
       c.FirstName,
       ea.ModifiedDate,
       a.City 
FROM Person.contact AS c
LEFT OUTER JOIN HumanResources.EmployeeAddress AS ea
ON c.ContactID = ea.EmployeeID 
LEFT OUTER JOIN Person.Address AS a
ON ea.AddressID = a.AddressID;
GO

-- Step 8 - Request execution plans for the two queries together

SELECT * 
FROM dbo.PersonAddress;

SELECT ContactID,LastName, FirstName
FROM dbo.PersonAddress;
GO

-- Step 9 - Evaluate the resulting query plan

-- Step 10 - Drop the view

DROP VIEW dbo.PersonAddress;
GO

-- Step 11 - Request an execution plan for the following query 

SELECT StateProvinceID, 
       StateProvinceCode,
       StateProvinceName,
       CountryRegionName 
FROM Person.vStateProvinceCountryRegion;
GO


