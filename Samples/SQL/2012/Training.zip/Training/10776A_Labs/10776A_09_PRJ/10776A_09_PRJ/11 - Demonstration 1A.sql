-- Demonstration 1A

-- Step 1 - Open a new query window to the AdventureWorks database

USE AdventureWorks;
GO

-- Step 2 - SELECT * FROM sys.views

SELECT * FROM sys.views;
GO

-- Step 3 - SELECT * FROM sys.tables

SELECT * FROM sys.tables;
GO

-- Step 4 - Browse to the list of system views in Object Explorer
--          (In Object Explorer click Connect, click Database Engine. In
--           the Connect to Server window, type AdventureWorks in the
--           Server name and click Connect. Expand the AdventureWorks
--           server, expand Databases, expand AdventureWorks, expand Views,
--           expand System Views)

-- Step 5 - SELECT * FROM INFORMATION_SCHEMA.TABLES 
--          to compare the results to sys.tables

SELECT * FROM INFORMATION_SCHEMA.TABLES;
GO

-- Step 6 - Scroll down in the Object Explorer to 
--          see the list of dynamic management views
--          (In Object Explorer in the list of System Views that you expanded
--           in Step 4, note the Views with names that begin with sys.dm)

-- Step 7 - SELECT * FROM sys.dm_exec_connections 
--          to see the current connection.

SELECT * FROM sys.dm_exec_connections;
GO

-- Step 8 - SELECT * FROM sys.dm_exec_sessions 
--          and locate the current session.

SELECT * FROM sys.dm_exec_sessions;
GO

-- Step 9 - SELECT * FROM sys.dm_exec_requests and locate the currently 
--          executing request. Copy the sql_handle and plan_handle from 
--          the currently running SELECT query. (ie: your session)

SELECT * FROM sys.dm_exec_requests;
GO

-- Step 10 - SELECT * FROM sys.dm_exec_sql_text( <insert the sql_handle here> )
--           to see the returned details of the executing SQL statement.

SELECT * FROM sys.dm_exec_sql_text(handle);
GO

-- Step 11 - SELECT * FROM sys.dm_exec_query_plan ( <insert the plan_handle here> ) 
--           to see the returned details of execution plans in memory.

SELECT * FROM sys.dm_exec_query_plan(handle);
GO

-- Step 12 - Click on the returned XML plan to open the graphical query plan

-- Step 13 - SELECT * FROM sys.dm_exec_query_stats

SELECT * FROM sys.dm_exec_query_stats;
GO

-- Step 14 - Modify the query to add a TOP(20) and an ORDER BY

SELECT TOP (20) qs.max_logical_reads,
                st.text 
FROM sys.dm_exec_query_stats AS qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
ORDER BY qs.max_logical_reads DESC;
