USE MarketDev;
GO

CREATE FUNCTION dbo.IntegerListToTable
( @InputList nvarchar(MAX),
  @Delimiter nchar(1) = N',')
RETURNS @OutputTable TABLE (PositionInList int IDENTITY(1, 1) NOT NULL,
                            IntegerValue int)
AS BEGIN
   DECLARE @RemainingString nvarchar(MAX) = @InputList;
   DECLARE @DelimiterPosition int;
   DECLARE @CurrentToken nvarchar(8);
   
   WHILE LEN(@RemainingString) > 0 
   BEGIN
     SET @DelimiterPosition = CHARINDEX(@Delimiter, @RemainingString);
     IF (@DelimiterPosition = 0) SET @DelimiterPosition = LEN(@RemainingString) + 1;
     IF (@DelimiterPosition > 8) SET @DelimiterPosition = 8;
     SET @CurrentToken = SUBSTRING(@RemainingString,1,@DelimiterPosition - 1);
     
     INSERT INTO @OutputTable (IntegerValue)
       VALUES(CAST(@CurrentToken AS int));
       
     SET @RemainingString = SUBSTRING(@RemainingString,@DelimiterPosition + 1,LEN(@RemainingString));
  END;
  RETURN;
END;
GO
SELECT * FROM dbo.IntegerListToTable('234,354253,3242,2',',');
GO
SELECT * FROM dbo.IntegerListToTable('234|354253|3242|2','|');
GO
