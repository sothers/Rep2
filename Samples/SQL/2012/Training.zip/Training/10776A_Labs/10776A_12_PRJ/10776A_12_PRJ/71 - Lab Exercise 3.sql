USE MarketDev;
GO

SET STATISTICS TIME ON;
GO

SELECT dbo.JoinNames(FirstName,MiddleName,LastName) AS FullName
FROM Marketing.Prospect
ORDER BY FullName;
GO

SELECT FirstName + N' ' 
       + CASE WHEN LEN(MiddleName) > 0 THEN MiddleName + N' '
              ELSE N''
         END
       + LastName AS FullName
FROM Marketing.Prospect
ORDER BY FullName;
GO

SET STATISTICS TIME OFF;
GO
