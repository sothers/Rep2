-- Module 15 Lab Exercise 1 - Suggested solution

USE MarketDev;
GO

CREATE TRIGGER Marketing.TR_CampaignBalance_Update
ON Marketing.CampaignBalance
AFTER UPDATE
AS BEGIN
  SET NOCOUNT ON;
  
  INSERT Marketing.CampaignAudit 
    (AuditTime, ModifyingUser, RemainingBalance)
  SELECT SYSDATETIME(),
         ORIGINAL_LOGIN(),
         inserted.RemainingBalance
  FROM deleted
  INNER JOIN inserted
  ON deleted.CampaignID = inserted.CampaignID 
  WHERE deleted.RemainingBalance > 10000
  OR inserted.RemainingBalance > 10000;
END;
GO
  
EXEC Marketing.MoveCampaignBalance 3,2,101000;
GO

SELECT * FROM Marketing.CampaignBalance;
GO

SELECT * FROM Marketing.CampaignAudit;
GO
