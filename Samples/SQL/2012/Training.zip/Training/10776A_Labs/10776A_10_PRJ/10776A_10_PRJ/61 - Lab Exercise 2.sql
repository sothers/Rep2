USE MarketDev;
GO

CREATE PROCEDURE Reports.GetProductsByColor
@Color nvarchar(16)
AS
SELECT p.ProductID, 
       p.ProductName, 
       p.ListPrice AS Price, 
       p.Color, 
       p.Size,
       p.SizeUnitMeasureCode AS UnitOfMeasure
FROM Marketing.Product AS p
WHERE (p.Color = @Color) OR (p.Color IS NULL AND @Color IS NULL)
ORDER BY ProductName;
GO
EXEC Reports.GetProductsByColor 'Blue';
GO
EXEC Reports.GetProductsByColor NULL;
GO

