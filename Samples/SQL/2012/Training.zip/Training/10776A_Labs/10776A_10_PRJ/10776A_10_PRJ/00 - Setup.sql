--Module 10 - Setup

USE master;
GO

IF EXISTS(SELECT 1 FROM sys.databases WHERE name = N'MarketDev')
  DROP DATABASE MarketDev;
GO

RESTORE DATABASE MarketDev
FROM DISK = 'D:\10776A_LABS\Resources\MarketDev.bak'
WITH MOVE 'MarketDev' TO 'D:\MKTG\MarketDev.mdf',
     MOVE 'MarketDev_Log' TO 'L:\MKTG\MarketDev.ldf';
     
GO

ALTER AUTHORIZATION ON DATABASE::MarketDev TO [ADVENTUREWORKS\Administrator];
GO

-- Added in module 3

USE MarketDev;
GO

CREATE SCHEMA DirectMarketing AUTHORIZATION dbo;
GO

CREATE TABLE DirectMarketing.Competitor
( CompetitorID INT NOT NULL PRIMARY KEY,
  CompetitorName NVARCHAR(30) NOT NULL,
  StreetAddress NVARCHAR(MAX) NOT NULL,
  DateEntered DATE NOT NULL,
  StrengthOfCompetition NVARCHAR(8) NOT NULL,
  Comments NVARCHAR(MAX) NULL
);
GO

CREATE TABLE DirectMarketing.City
( CityID INT NOT NULL PRIMARY KEY,
  CityName NVARCHAR(25) NOT NULL
);
GO

CREATE TABLE DirectMarketing.TVStation
( TVStationID INT NOT NULL PRIMARY KEY,
  TVStationName NVARCHAR(15) NOT NULL,
  CityID INT NOT NULL,
  CostPerAdvertisement DECIMAL(12,2) NOT NULL
);
GO

CREATE TABLE DirectMarketing.TVAdvertisement
( TVAdvertisementID INT NOT NULL PRIMARY KEY,
  TVStationID INT NOT NULL,
  ScreeningTime DATETIME NOT NULL
);
GO

CREATE TABLE DirectMarketing.CampaignResponse
( CampaignResponseID INT NOT NULL PRIMARY KEY,
  ResponseReceived DATETIME NOT NULL,
  ProspectID INT NOT NULL,
  ResponseMethodCode CHAR(1) NOT NULL,
  ChargeFromReferrer DECIMAL(12,2) NOT NULL,
  RevenueReceived DECIMAL(12,2) NOT NULL
);
GO     
-- Added in module 4

CREATE SCHEMA WebStock AUTHORIZATION dbo;
GO

CREATE VIEW WebStock.OnlineProducts
AS
SELECT p.ProductID, 
       p.ProductName, 
       p.ProductNumber, 
       COALESCE(p.Color,'N/A') AS Color, 
       CASE p.DaysToManufacture
         WHEN 0 THEN 'Instock'
         WHEN 1 THEN 'Overnight'
         WHEN 2 THEN 'Fast'
         ELSE 'Call'
       END AS Availability,
       p.Size, 
       p.SizeUnitMeasureCode AS UnitOfMeasure,
       p.ListPrice AS Price, 
       p.Weight
FROM Marketing.Product AS p
WHERE p.SellEndDate IS NULL
AND p.SellStartDate IS NOT NULL;
GO

CREATE VIEW WebStock.AvailableModels
AS
SELECT p.ProductID,
       p.ProductName,
       pm.ProductModelID,
       pm.ProductModel,
       COALESCE(ed.Description,id.Description) AS CatalogDescription
FROM Marketing.Product AS p
INNER JOIN Marketing.ProductModel AS pm
ON p.ProductModelID = pm.ProductModelID 
LEFT OUTER JOIN Marketing.ProductDescription AS ed
ON pm.ProductModelID = ed.ProductModelID 
AND ed.LanguageID = 'en'
LEFT OUTER JOIN Marketing.ProductDescription as id
ON pm.ProductModelID = id.ProductModelID 
AND id.LanguageID = ''
WHERE p.SellEndDate IS NULL
AND p.SellStartDate IS NOT NULL;
GO

CREATE SCHEMA Relationship AUTHORIZATION dbo;
GO

CREATE VIEW Relationship.Contacts
AS
SELECT p.ProspectID AS ContactID,
       p.FirstName,
       p.MiddleName,
       p.LastName,
       'PROSPECT' AS ContactRole
FROM Marketing.Prospect AS p
UNION ALL 
SELECT sp.SalespersonID,
       sp.FirstName,
       sp.MiddleName,
       sp.LastName,
       'SALESPERSON'
FROM Marketing.Salesperson AS sp;
GO

USE master;
GO

CREATE LOGIN SecureUser WITH PASSWORD = 'Pa$$w0rd',
                             CHECK_POLICY = OFF;
GO

USE tempdb;
GO

CREATE USER SecureUser FOR LOGIN SecureUser;
GO

USE master;
GO
                            




