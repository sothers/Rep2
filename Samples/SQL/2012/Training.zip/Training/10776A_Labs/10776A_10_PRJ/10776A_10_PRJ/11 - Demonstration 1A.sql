-- Demonstration 1A

-- Step 1: Open a new query window to the tempdb database

USE tempdb;
GO

-- Step 2: Browse the list of system stored procedures 
--         in the master database using object browser
--         note that most are sp_ but some are xp_
--         (In Object Explorer, expand the Proseware server, 
--          expand Databases, expand System Databases, expand
--          master, expand Programmability, expand Stored 
--          Procedures)

-- Step 3: Execute some system stored procedures to see 
--         how they could be used

EXEC sys.sp_configure;
GO
EXEC sys.sp_helpdb;
GO
EXEC sys.sp_helpsort;
GO

-- Step 4: Note how many of the values returned by system
--         stored procedures can now be returned from 
--         object functions

SELECT SERVERPROPERTY('collation');
GO
SELECT SERVERPROPERTY('edition');
GO

-- Step 5: Browse the list of system extended stored procedures 
--         in the master database using object browser
--         note that there is a mixture of xp_ and sp_
--         (In Object Explorer, expand the Proseware server, 
--          expand Databases, expand System Databases, expand
--          master, expand Programmability, expand Extended 
--          Stored Procedures)

-- Step 6: Query some system extended stored procedures

EXEC sys.xp_fixeddrives;
GO
EXEC sys.xp_dirtree 'D:\';
GO
