-- Lab Solutions for Exercise 3

USE MarketDev;
GO

-- Existing tables with phone numbers

-- Marketing.Prospect CellPhoneNumber nvarchar(20)
--                    HomePhoneNumber nvarchar(25)
--                    WorkPhoneNumber nvarchar(22)

CREATE TYPE PhoneNumber
FROM nvarchar(25);
GO


-- Existing tables with email addresses

-- Marketing.Prospect    EmailAddress  nvarchar(100)
-- Marketing.Salesperson EmailAlias    nvarchar(256)

CREATE TYPE EmailAddress
FROM nvarchar(256);
GO
