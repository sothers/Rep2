-- Lab Solutions for Exercise 2

USE MarketDev;
GO

-- Suggested solution for Query 1

SELECT ProductID, 
       ProductName, 
       CONVERT(varchar(8),SellEndDate,112) AS SellEndDate
FROM Marketing.Product;

GO

-- Suggested solution for Query 2

SELECT ProspectID, 
       CAST(Demographics AS nvarchar(1000)) AS Demographics 
FROM Marketing.Prospect;

GO
