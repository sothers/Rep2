-- Demonstration 3B

-- Step 1: From the Tools menu of SQL Profiler, select 
--         to open Database Engine Tuning Advisor and in
--         the Connect to Server windows, click Connect.

-- Step 2: Click the Browse for a Workload File tool button, select
--         the Trace_10776A.trc file created in Demo 3A

-- Step 3: In the Database for Workload Analysis dropdown
--         list, select AdventureWorks

-- Step 4: In the Select databases and tables to tune 
--         list, also select AdventureWorks

-- Step 5: Click the Start Analysis toolbar icon
--         When the analysis completes, review the
--         recommendations and the estimated improvement.

-- Step 6: For any recommended changes, click the entry
--         in the Definition column to review it

