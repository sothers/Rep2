-- Demonstration 3A

-- Step 1: Reconnect this query window to the tempdb database on the AdventureWorks server.
--         (Right-click in whitespace, click Connection, click Change Connection, 
--         then in the Connect to Server windows, enter AdventureWorks as the 
--         server name and click Connect). Then use the AdventureWorks database.

USE AdventureWorks;
GO

-- Step 2: Open SQL Server Profiler (from the Tools menu in SSMS, click SQL Server Profiler. 
--         In the Connect to Server window, click Connect)

-- Step 2: Change the trace name to Trace_10776A

-- Step 3: Select the tuning template

-- Step 4: Choose the Save to File option and select the desktop as the file location

-- Step 5: Set the maximum filesize to 5000

-- Step 6: On the Events Selection tab, note the selected events. 

-- Step 7: Check the "Show all events" checkbox to show available events, then uncheck it.

-- Step 8: Check the "Show all columns" checkbox to show available columns, then uncheck it.

-- Step 9: Click on the DatabaseName column heading and enter AdventureWorks in the LIKE textbox.

-- Step 10: Click Run to start the trace.

-- Step 11: Execute the following code:



DECLARE @Counter int = 0;

WHILE @Counter < 100 BEGIN
  SELECT TOP(1) ProductID, Name, Color, Size
  FROM Production.Product
  WHERE ProductID < @Counter
  ORDER BY Size, Color, Name;
  SET @Counter += 1;
END;
GO

-- Step 12: Switch back to the trace window and note the output

-- Question: When so many statements were execution, why is there
--           only one entry in the trace?

-- Step 13: Stop the trace by clicking on the Stop toolbar icon.

-- Step 14: Click on the trace properties toolbar icon

-- Step 15: Add the SQL:StmtCompleted event (On the Events Selection
--          tab, click Show all Events then scroll the list to the TSQL
--          section. Check the box beside SQL:StmtCompleted). Click Run to 
--          start the trace (Do not reset the file output as we will use the existing 
--          output in the next demonstration)

-- Step 16: Re-execute the code:

DECLARE @Counter int = 0;

WHILE @Counter < 100 BEGIN
  SELECT TOP(1) ProductID, Name, Color, Size
  FROM Production.Product
  WHERE ProductID < @Counter
  ORDER BY Size, Color, Name;
  SET @Counter += 1;
END;
GO

-- Step 17: Note the output now present in the trace window

-- Step 18: Stop the trace by clicking Stop on the toolbar in SQL Server Profiler
