-- Demonstration 1A

-- Step 1: In Object Explorer, click Connect then click Database Engine. In the 
--         Connect to Server window, type AdventureWorks as the server name and 
--         click Connect. In Object Explorer, expand the AdventureWorks server, 
--         expand Databases, expand AdventureWorks, expand Tables, expand 
--         the Person.Contact table, and expand the Indexes node. Review the available 
--         indexes.

-- Step 2: Right-click the PK_Contact_ContactID index and choose Properties.
--         Note that indexes that support primary keys are shown in the list of indexes.

-- Step 3: Right-click the AdventureWorks database and then choose the
--         Reports option, then Standard Reports then Index Usage Statistics. Review
--         the report.

-- Step 4: Right-click the AdventureWorks database and then choose the
--         Reports option, then Standard Reports then Index Physical Statistics. Review
--         the report.

-- Step 5: Reconnect this query window to the AdventureWorks server.
--         (Right-click in whitespace, click Connection, click Change Connection, 
--         then in the Connect to Server windows, enter AdventureWorks as the 
--         server name and click Connect). Then use the AdventureWorks Database

USE AdventureWorks;
GO

-- Step 6: Query the sys.indexes system view

SELECT * FROM sys.indexes;
GO

-- Step 7: Note the columns that indicate if the index is unique 
--         and if it is related to a primary or unique key constraint

-- Step 8: Execute a more useful query that includes object names
--         and avoids internal objects

SELECT OBJECT_SCHEMA_NAME(o.object_id) as SchemaName,
       o.name as TableName,
       i.name as IndexName,
       i.index_id,
       i.type_desc,
       i.*
FROM sys.objects AS o
INNER JOIN sys.indexes AS i
ON o.object_id = i.object_id
WHERE o.is_ms_shipped  = 0;

