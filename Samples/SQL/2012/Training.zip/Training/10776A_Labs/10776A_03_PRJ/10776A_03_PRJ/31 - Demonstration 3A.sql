-- Demonstration 3A

-- Step 1: Open a new query window to the tempdb database

USE tempdb;
GO

-- Step 2: Create a schema to hold the tables

CREATE SCHEMA PetStore AUTHORIZATION dbo;
GO

-- Step 3: Create the Owner table and add a few rows

CREATE TABLE PetStore.Owner
( OwnerID int IDENTITY(1,1) PRIMARY KEY,
  OwnerName nvarchar(30) NOT NULL,
  HairColor nvarchar(10) NULL
);
GO

INSERT PetStore.Owner (OwnerName, Haircolor)
  VALUES('Luka Abrus','Blonde'),('Mu Han','Black');
GO
  
SELECT * FROM PetStore.Owner;
GO

-- Step 4: Add a column to the Owner Table and update a row

ALTER TABLE PetStore.Owner
  ADD PreferredName nvarchar(30) NULL;
GO

SELECT * FROM PetStore.Owner;
GO

UPDATE PetStore.Owner SET PreferredName = 'Luka' WHERE OwnerID = 1;
GO

SELECT * FROM PetStore.Owner;
GO

-- Step 5: Drop a column from the Owner Table

ALTER TABLE PetStore.Owner
  DROP COLUMN PreferredName;
GO

SELECT * FROM PetStore.Owner;
GO