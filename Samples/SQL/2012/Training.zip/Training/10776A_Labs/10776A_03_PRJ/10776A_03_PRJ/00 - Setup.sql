-- 10776A - Module 3 - Setup

USE master;
GO

IF EXISTS(SELECT 1 FROM sys.databases WHERE name = N'MarketDev')
  DROP DATABASE MarketDev;
GO

RESTORE DATABASE MarketDev
FROM DISK = 'D:\10776A_LABS\Resources\MarketDev.bak'
WITH MOVE 'MarketDev' TO 'D:\MKTG\MarketDev.mdf',
     MOVE 'MarketDev_Log' TO 'L:\MKTG\MarketDev.ldf';
