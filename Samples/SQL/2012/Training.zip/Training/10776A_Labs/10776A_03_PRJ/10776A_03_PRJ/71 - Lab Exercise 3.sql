-- Lab Exercise 3 Suggested Solution

USE MarketDev;
GO

CREATE TABLE DirectMarketing.Competitor
( CompetitorID INT NOT NULL PRIMARY KEY,
  CompetitorName NVARCHAR(30) NOT NULL,
  StreetAddress NVARCHAR(MAX) NOT NULL,
  DateEntered DATE NOT NULL,
  StrengthOfCompetition NVARCHAR(8) NOT NULL,
  Comments NVARCHAR(MAX) NULL
);
GO

CREATE TABLE DirectMarketing.City
( CityID INT NOT NULL PRIMARY KEY,
  CityName NVARCHAR(25) NOT NULL
);
GO

CREATE TABLE DirectMarketing.TVStation
( TVStationID INT NOT NULL PRIMARY KEY,
  TVStationName NVARCHAR(15) NOT NULL,
  CityID INT NOT NULL,
  CostPerAdvertisement DECIMAL(12,2) NOT NULL
);
GO

CREATE TABLE DirectMarketing.TVAdvertisement
( TVAdvertisementID INT NOT NULL PRIMARY KEY,
  TVStationID INT NOT NULL,
  ScreeningTime DATETIME NOT NULL
);
GO

CREATE TABLE DirectMarketing.CampaignResponse
( CampaignResponseID INT NOT NULL PRIMARY KEY,
  ResponseReceived DATETIME NOT NULL,
  ProspectID INT NOT NULL,
  ResponseMethodCode CHAR(1) NOT NULL,
  ChargeFromReferrer DECIMAL(12,2) NOT NULL,
  RevenueReceived DECIMAL(12,2) NOT NULL
);
GO

  
  