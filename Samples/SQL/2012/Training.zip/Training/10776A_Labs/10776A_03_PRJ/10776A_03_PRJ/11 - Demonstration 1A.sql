-- Demonstration 1A - Common normalization errors

-- Step 1: Consider the following table design

USE tempdb;
GO

CREATE TABLE PetOwners
( Owner1 nvarchar(20),
  Owner1Hair nvarchar(10),
  Owner2 nvarchar(20),
  Owner2Hair nvarchar(10),
  PetName nvarchar(20),
  PetType nvarchar(10),
  PetBirthDate date,
  PetBirthYear int
);
GO

INSERT PetOwners (Owner1,Owner1Hair,Owner2,Owner2Hair,PetName,PetType,
                  PetBirthDate,PetBirthYear)
VALUES ('Kim Akers','Brown','Joe Healy','Blonde','Bruce','Dog','19971201',1997),
       ('Kim Akers','Brown','Joe Healy','Blonde','Tweetie','Bird','20070401',2007),
       ('Kim Akers','Brown','Joe Healy','Blonde','Victor','Dog','20061214',2006),
       ('Luis Alverca','Blonde','','','Bruno','Dog','20030119',2003),
       ('Luis Alverca','Blonde','','','Brutus','Dog','20071219',2007),
       ('Charlie Herb','Brown','Cassie Hicks','Red','Brutus','Dog','20060619',2006);
GO

SELECT * FROM PetOwners;
GO

-- Step 2: Describe an improved design






