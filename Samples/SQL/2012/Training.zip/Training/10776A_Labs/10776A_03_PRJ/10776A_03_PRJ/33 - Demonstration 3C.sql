-- Demonstration 3C

-- Step 1: Open a new query window to the tempdb database

USE tempdb;
GO

-- Step 2: Create a table with a persisted computed column

CREATE TABLE PetStore.Pet
(PetID int IDENTITY(1,1) PRIMARY KEY,
 PetName nvarchar(30) NOT NULL,
 PetType nvarchar(10) NOT NULL,
 DateOfBirth date NOT NULL,
 YearOfBirth AS DATEPART(year,DateOfBirth) PERSISTED
);
GO

-- Step 3: Insert some data into the table

INSERT PetStore.Pet (PetName, PetType, DateOfBirth)
  VALUES ('Brutus','DOG','2007-12-31'),
         ('Bruno','DOG','2006-01-01'),
         ('Tweetie','BIRD','2005-04-02');
GO

-- Step 4: Query the table

SELECT * FROM PetStore.Pet;
GO
