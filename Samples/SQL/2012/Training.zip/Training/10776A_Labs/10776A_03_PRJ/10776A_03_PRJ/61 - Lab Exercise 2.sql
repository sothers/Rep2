USE MarketDev;
GO

CREATE SCHEMA DirectMarketing AUTHORIZATION dbo;
GO
