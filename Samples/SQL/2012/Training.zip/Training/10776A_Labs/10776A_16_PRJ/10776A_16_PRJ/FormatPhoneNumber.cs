﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Text;
using Microsoft.SqlServer.Server;

public partial class UserDefinedFunctions
{
    [SqlFunction(DataAccess=DataAccessKind.None)]
    public static SqlString FormatPhoneNumber(SqlString PhoneNumberToFormat)
    {
        SqlString returnSqlString = new SqlString();

        if (PhoneNumberToFormat.IsNull)
            return returnSqlString;

        StringBuilder numbersOnly = new StringBuilder("");

        for (int counter = 0; counter < PhoneNumberToFormat.Value.Length; counter++)
        {
            if ((PhoneNumberToFormat.Value[counter] >= '0') 
                && (PhoneNumberToFormat.Value[counter] <= '9'))
                numbersOnly.Append(PhoneNumberToFormat.Value[counter]);
        }
        
        string numbers = numbersOnly.ToString();
        string returnString = "";

        switch (numbers.Length)
        {
            case 6:
                returnString = numbers.Substring(0,3) + "-" + numbers.Substring(3,3);
                break;
            case 7:
                returnString = numbers.Substring(0,3) + "-" + numbers.Substring(3,4);
                break;
            case 8:
                returnString = numbers.Substring(0,4) + "-" + numbers.Substring(4,4);
                break;
            case 10:
                returnString = "(" + numbers.Substring(0,3) + ") "
                             + numbers.Substring(3,3) + "-" + numbers.Substring(6,4);
                break;
        }

        return new SqlString(returnString);
    }
};

