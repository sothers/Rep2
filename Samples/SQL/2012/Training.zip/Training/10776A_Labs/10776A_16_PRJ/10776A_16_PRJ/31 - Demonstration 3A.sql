-- Demonstration 3A - User-defined Functions

-- Step 1: Open a new query window 
--         and use the AdventureWorks database

USE AdventureWorks;
GO

-- Step 2: Catalog the scalar function dbo.FormatPhoneNumber

CREATE FUNCTION dbo.FormatPhoneNumber (@PhoneNumberToFormat nvarchar(max))
RETURNS nvarchar(max)
AS EXTERNAL NAME SQLCLR10776A.UserDefinedFunctions.FormatPhoneNumber;
GO

-- Step 3: Execute code to test the function

SELECT dbo.FormatPhoneNumber('(234820)23');
SELECT dbo.FormatPhoneNumber('12-2342');
SELECT dbo.FormatPhoneNumber('23-2352-23(12)');
SELECT dbo.FormatPhoneNumber('(234820)2');
GO

-- Step 4: Catalog the table-valued function dbo.RangeOfIntegers

CREATE FUNCTION dbo.RangeOfIntegers 
(@FromValue int, @ToValue int)
RETURNS TABLE (PositionInList int, IntegerValue int)
AS EXTERNAL NAME 
SQLCLR10776A.UserDefinedFunctions.RangeOfIntegers;
GO

-- Step 5: Test the function

SELECT * FROM dbo.RangeOfIntegers(1,20);
SELECT * FROM dbo.RangeOfIntegers(15,25);
SELECT * FROM dbo.RangeOfIntegers(-25,20);
SELECT * FROM dbo.RangeOfIntegers(35,15);

-- Step 6: Using the function, find the missing values in the productid 
--         column from production.product between 300 and 399

SELECT roi.IntegerValue AS MissingIDs
FROM dbo.RangeOfIntegers(300,399) AS roi
LEFT OUTER JOIN Production.Product AS p
ON roi.IntegerValue = p.ProductID 
WHERE p.ProductID IS NULL
ORDER BY roi.IntegerValue;
