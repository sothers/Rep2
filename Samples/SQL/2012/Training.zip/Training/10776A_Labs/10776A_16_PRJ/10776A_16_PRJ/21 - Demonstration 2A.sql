-- Demonstration 2A - Importing and Configuring an Assembly

-- Step 1: Open a new query window 
--         and use the AdventureWorks database

USE master;
GO

ALTER AUTHORIZATION ON DATABASE::AdventureWorks TO [ADVENTUREWORKS\Administrator];
GO

USE AdventureWorks;
GO

-- Step 2: Browse to the Assemblies node in Object Browser
--         and show any existing assemblies

-- Step 3: Catalog the sample assembly

USE master;
GO

EXEC sp_configure 'clr enabled',1;
GO
RECONFIGURE;
GO

USE AdventureWorks;
GO

ALTER DATABASE AdventureWorks SET TRUSTWORTHY ON;
GO

CREATE ASSEMBLY SQLCLR10776A
FROM 'D:\10776A_Labs\10776A_16_PRJ\10776A_16_PRJ\SQLCLR_10776A.DLL'
WITH PERMISSION_SET = EXTERNAL_ACCESS;

-- Step 4: Query the system views to see what has been loaded
--         Note the types already supplied by the 
--         assembly named Microsoft.SqlServer.Types

SELECT * FROM sys.assemblies;
SELECT * FROM sys.assembly_files;
SELECT * FROM sys.assembly_types;

-- Step 5: Refresh the list of assemblies in object explorer
--         (In Object Explorer, click Connect, click Database Engine.
--          In the Connect to Server window, type AdventureWorks for the 
--          Server name and click Connect. Expand AdventureWorks server,
--          expand Databases, expand AdventureWorks database,
--          expand Programmability, expand Assemblies. Right-click
--          Assemblies and click Refresh).

-- Step 6: Script the SQLCLR_10776A assembly to a new query window 
--         and explain the code presented. Note the binary form of 
--         the CREATE ASSEMBLY statement.
--         (In Object Explorer, right-click the SQLCLR_10776A assembly
--          that was in the list from step 5, and choose Script Assembly As,
--          then choose CREATE To, then click New Query Editor Window).


