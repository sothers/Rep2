﻿using System;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;


public partial class StoredProcedures
{
    [SqlProcedure]
    public static void WriteOSFile(SqlString OutputFileName, 
                                   SqlBinary DataToWrite)
    {
        try
        {
            FileStream outputFile = new FileStream(OutputFileName.Value,
                                                    FileMode.Create);
            outputFile.Write(DataToWrite.Value,0,DataToWrite.Length);
            outputFile.Close();
        }
        catch (Exception e)
        {
            SqlContext.Pipe.Send(e.Message);
        }
    }
};
