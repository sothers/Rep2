-- Lab Exercise 3

-- Task 1

USE MarketDev;
GO

CREATE AGGREGATE dbo.AggString(@s nvarchar(4000))
RETURNS nvarchar(4000)
EXTERNAL NAME SQLCLRDemo.[SQLCLRDemo.AggString];
GO

SELECT dbo.AggString(DISTINCT ProductNumber) 
FROM Marketing.Product
WHERE Color = 'Black';
GO

-- Task 2

CREATE TYPE dbo.zVarChar
EXTERNAL NAME SQLCLRDemo.[SQLCLRDemo.zVarChar];
GO

CREATE TABLE dbo.TestTable
( RecID int IDENTITY(1,1),
  TextValue zVarChar
);
GO

INSERT INTO dbo.TestTable VALUES('Some        compressible         data');
GO

SELECT TextValue.ToString(),
       TextValue.CompressedLength(),
       TextValue.CompressionPercentage() 
FROM dbo.TestTable;
GO

SELECT AVG(TextValue.CompressionPercentage()) FROM dbo.TestTable;
GO

DROP TABLE dbo.TestTable;
GO

DECLARE @TestString zVarChar;
SET @TestString = 'Some            compressible          value';
PRINT @TestString.CompressedValue();
GO

PRINT zVarChar::Compress('Some              compressible        value');
GO
