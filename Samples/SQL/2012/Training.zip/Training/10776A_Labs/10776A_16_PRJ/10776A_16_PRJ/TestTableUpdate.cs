﻿using System;
using System.Data;
using System.Data.SqlClient;
using Microsoft.SqlServer.Server;


public partial class Triggers
{
    [SqlTrigger (Name="TR_TestTable_Update", 
                 Target="TestTable", 
                 Event="FOR UPDATE")]
    public static void TestTableUpdate()
    {
        SqlContext.Pipe.Send("Trigger FIRED");
    }
}
