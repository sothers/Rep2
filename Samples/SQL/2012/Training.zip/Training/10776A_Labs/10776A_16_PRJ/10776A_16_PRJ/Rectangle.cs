﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

[Serializable]
[SqlUserDefinedType(Format.Native)]
public struct Rectangle : INullable
{
    private bool valueIsNotCurrentlyNull;
    private double x1;
    private double y1;
    private double x2;
    private double y2;

    public override string ToString()
    {
        if (this.valueIsNotCurrentlyNull)
        {
            return "(" + this.x1.ToString() + ","
                   + this.y1.ToString() + ") - ("
                   + this.x2.ToString() + ","
                   + this.y2.ToString() + ")";
        }
        else
        {
            return "NULL";
        }
    }

    public bool IsNull
    {
        get
        {
            return (!this.valueIsNotCurrentlyNull);
        }
    }

    public static Rectangle Null
    {
        get
        {
            return new Rectangle();
        }
    }

    public static Rectangle Parse(SqlString s)
    {
        if (s.IsNull)
            return Null;

        string recString = s.Value;
        if (recString.Length < 2)
        {
            throw new ArgumentException("Invalid rectangle value");
        }
        if ((recString[0] != '(') || (!recString.EndsWith(")")))
        {
            throw new ArgumentException("Invalid rectangle value");
        }
        try
        {
            Rectangle rec = new Rectangle();
            int firstCommaPosition = s.Value.IndexOf(',');
            int secondCommaPosition = s.Value.IndexOf(','
                                      , firstCommaPosition + 1);
            int firstClosePosition = s.Value.IndexOf(')');
            int secondOpenPosition = s.Value.IndexOf('(', 1);
            // get the X1 value
            string numberString = recString.Substring(1,
                                      firstCommaPosition - 1);
            rec.x1 = double.Parse(numberString);
            // get the Y1 value
            numberString = recString.Substring(
                           firstCommaPosition + 1,
                           firstClosePosition - firstCommaPosition - 1);
            rec.y1 = double.Parse(numberString);
            // get the X2 value
            numberString = recString.Substring(
                           secondOpenPosition + 1,
                           secondCommaPosition - secondOpenPosition - 1);
            rec.x2 = double.Parse(numberString);
            // get the Y2 value
            numberString = recString.Substring(
                           secondCommaPosition + 1,
                           recString.Length - secondCommaPosition - 2);
            rec.y2 = double.Parse(numberString);
            rec.valueIsNotCurrentlyNull = true;
            return rec;
        }
        catch
        {
            throw new ArgumentException("Invalid rectangle value");
        }
    }

    public SqlDouble Width()
    {
        if (this.valueIsNotCurrentlyNull)
        {
            return new SqlDouble(Math.Abs(this.x1 - this.x2));
        }
        else
        {
            return SqlDouble.Null;
        }
    }

    public SqlDouble Height()
    {
        if (this.valueIsNotCurrentlyNull)
        {
            return new SqlDouble(Math.Abs(this.y1 - this.y2));
        }
        else
        {
            return SqlDouble.Null;
        }
    }

    public SqlDouble Area()
    {
        if (this.valueIsNotCurrentlyNull)
        {
            return new SqlDouble(Math.Abs(this.y1 - this.y2) * Math.Abs(this.x1 - this.x2));
        }
        else
        {
            return SqlDouble.Null;
        }
    }

    public SqlDouble X1Value
    {
        get
        {
            if (this.valueIsNotCurrentlyNull)
            {
                return new SqlDouble(this.x1);
            }
            else
            {
                return SqlDouble.Null;
            }
        }
        set
        {
            if (valueIsNotCurrentlyNull)
            {
                this.x1 = value.Value;
            }
            else
            {
                throw new NullReferenceException();
            }
        }
    }

    public SqlDouble Y1Value
    {
        get
        {
            if (this.valueIsNotCurrentlyNull)
            {
                return new SqlDouble(this.y1);
            }
            else
            {
                return SqlDouble.Null;
            }
        }
        set
        {
            if (valueIsNotCurrentlyNull)
            {
                this.y1 = value.Value;
            }
            else
            {
                throw new NullReferenceException();
            }
        }
    }

    public SqlDouble X2Value
    {
        get
        {
            if (this.valueIsNotCurrentlyNull)
            {
                return new SqlDouble(this.x2);
            }
            else
            {
                return SqlDouble.Null;
            }
        }
        set
        {
            if (valueIsNotCurrentlyNull)
            {
                this.x2 = value.Value;
            }
            else
            {
                throw new NullReferenceException();
            }
        }
    }

    public SqlDouble Y2Value
    {
        get
        {
            if (this.valueIsNotCurrentlyNull)
            {
                return new SqlDouble(this.y2);
            }
            else
            {
                return SqlDouble.Null;
            }
        }
        set
        {
            if (valueIsNotCurrentlyNull)
            {
                this.y2 = value.Value;
            }
            else
            {
                throw new NullReferenceException();
            }
        }
    }
}

