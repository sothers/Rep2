-- Demonstration 3B - Stored Procedures and Triggers

-- Step 1: Open a new query window 
--         and use the AdventureWorks database

USE AdventureWorks;
GO

-- Step 2: Catalog the stored procedure dbo.ProductsByColor

CREATE PROCEDURE dbo.ProductsByColor
(@Color nvarchar(16))
AS EXTERNAL NAME 
SQLCLR10776A.StoredProcedures.ProductsByColor;
GO

-- Step 3: Test the stored procedure
--         (make sure you also look on the messages tab in the 
--         output as the stored procedure also sends the 
--         equivalent of a PRINT statement there)

EXEC dbo.ProductsByColor NULL;
EXEC dbo.ProductsByColor 'Blue';
GO

-- Step 4: Catalog the stored procedure dbo.WriteOSFile
--         Note: this procedure will perform external access

CREATE PROCEDURE dbo.WriteOSFile
(@OutputFileName nvarchar(400), @FileData varbinary(max))
AS EXTERNAL NAME SQLCLR10776A.StoredProcedures.WriteOSFile;
GO

-- Step 5: Test the dbo.WriteOSFile stored procedure

DECLARE @XmlData varbinary(max);
SET @XmlData = CAST(
N'<CustomerBalances>
    <Customer CustomerID="12" Balance="234.24" />
    <Customer CustomerID="14" Balance="100.00" />
 </CustomerBalances>'
 AS varbinary(max));
 
EXEC dbo.WriteOSFile 'D:\10776A_Labs\10776A_16_PRJ\CustomerBalances.xml',
                     @XmlData;
GO

-- Step 6: Open the file that was written using notepad 
--         and view the results

-- Step 7: Create and populate a test table

CREATE TABLE dbo.TestTable
( TestTableID int IDENTITY(1,1) PRIMARY KEY,
  TestName nvarchar(20)
);
GO
INSERT INTO dbo.TestTable (TestName)
  VALUES ('Hello'),('There');
GO

-- Step 8: Catalog a trigger on the table that fires 
--         when it is updated

CREATE TRIGGER TR_TestTableUpdate
ON dbo.TestTable
AFTER UPDATE
AS EXTERNAL NAME SQLCLR10776A.Triggers.TestTableUpdate;
GO

-- Step 9: Test the trigger � it simply sends a message 
--         to the messages tab when the trigger fires

UPDATE dbo.TestTable 
SET TestName = 'Goodbye' 
WHERE TestTableID = 1;
GO

-- Step 10: Drop the test table 

DROP TABLE dbo.TestTable;
GO
