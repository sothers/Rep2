﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Collections;
using Microsoft.SqlServer.Server;

public partial class UserDefinedFunctions
{
    [SqlFunction(DataAccess=DataAccessKind.None,
                 FillRowMethodName="FillIntegerRow",
                 TableDefinition="PositionInList int, IntegerValue int")]
    public static IEnumerator RangeOfIntegers(SqlInt32 FromValue, 
                                              SqlInt32 ToValue)
    {
        if (FromValue.IsNull || ToValue.IsNull)
            return new IntegerList(0, -1); // return an empty list
        return new IntegerList(FromValue.Value, ToValue.Value);
    }

    public static void FillIntegerRow(object RowToOutput, 
                                      out SqlInt32 PositionInList, 
                                      out SqlInt32 IntegerValue)
    {
        if (RowToOutput == null)
        {
            PositionInList = new SqlInt32();
            IntegerValue = new SqlInt32();
        }
        IntegerListItem currentRow = (IntegerListItem)RowToOutput;
        PositionInList = new SqlInt32(currentRow.PositionInList);
        IntegerValue = new SqlInt32(currentRow.IntegerValue);
    }

    public class IntegerList : IEnumerator
    {
        private int[] intList;
        private int arraySize = 0;
        private int fromValue;
        private int currentPosition;

        public IntegerList(int FromValue, int ToValue)
        {
            this.fromValue = FromValue;
            this.currentPosition = -1;
            if (FromValue <= ToValue)
            {
                this.arraySize = ToValue - FromValue + 1;
                this.intList = new int[arraySize];
                for (int counter = FromValue; counter <= ToValue; counter++)
                {
                    this.intList[counter - FromValue] = counter;
                }
            }
        }

        public object Current
        {
            get 
            {
                if ((this.currentPosition < 0 )
                    || (this.currentPosition > this.arraySize - 1)) 
                    return null;
                return new IntegerListItem(currentPosition + 1,
                                           this.intList[currentPosition]);
            }
        }

        public bool MoveNext()
        {
            this.currentPosition++;
            return (this.currentPosition < this.arraySize);
        }

        public void Reset()
        {
            this.currentPosition = -1;
        }
    }

    public struct IntegerListItem
    {
        public int PositionInList;
        public int IntegerValue;

        public IntegerListItem(int Position, int Value)
        {
            PositionInList = Position;
            IntegerValue = Value;
        }
    }
};

