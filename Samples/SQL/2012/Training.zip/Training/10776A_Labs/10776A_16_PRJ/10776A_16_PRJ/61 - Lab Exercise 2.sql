-- Lab Exercise 2

-- Task 1

USE master;
GO

EXEC sp_configure 'clr enabled',1;
GO

RECONFIGURE;
GO

ALTER DATABASE MarketDev SET TRUSTWORTHY ON;
GO

-- Task 2

USE MarketDev;
GO

CREATE ASSEMBLY SQLCLRDemo
FROM 'D:\10776A_Labs\10776A_16_PRJ\10776A_16_PRJ\SQLCLRDemo.DLL'
WITH PERMISSION_SET = EXTERNAL_ACCESS;
GO

SELECT * FROM sys.assemblies;
SELECT * FROM sys.assembly_files;
GO

CREATE FUNCTION dbo.IsValidEmailAddress(@email NVARCHAR(4000))
RETURNS BIT AS EXTERNAL NAME SQLCLRDemo.[SQLCLRDemo.CLRDemoClass].IsValidEmailAddress;
GO

CREATE FUNCTION dbo.FormatAustralianPhoneNumber(@PhoneNumber NVARCHAR(4000))
RETURNS NVARCHAR(4000) AS EXTERNAL NAME SQLCLRDemo.[SQLCLRDemo.CLRDemoClass].FormatAustralianPhoneNumber;
GO

CREATE FUNCTION dbo.FolderList(@RequiredPath NVARCHAR(4000),@FileMask NVARCHAR(4000))
RETURNS TABLE (FileName NVARCHAR(4000))
AS EXTERNAL NAME SQLCLRDemo.[SQLCLRDemo.CLRDemoClass].FolderList;
GO

-- Task 3

SELECT dbo.IsValidEmailAddress('test@somewhere.com');
GO
SELECT dbo.IsValidEmailAddress('test.somewhere.com');
GO

SELECT dbo.FormatAustralianPhoneNumber('0419201410');
SELECT dbo.FormatAustralianPhoneNumber('9 87 2 41 23');
SELECT dbo.FormatAustralianPhoneNumber('039 87 2 41 23');
GO

SELECT * FROM dbo.FolderList('D:\10776A_Labs\10776A_16_PRJ\10776A_16_PRJ','*.txt');
GO

