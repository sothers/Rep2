﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;


[Serializable]
[SqlUserDefinedAggregate(Format.Native,
                         IsInvariantToDuplicates=true,
                         IsInvariantToNulls=true,
                         IsNullIfEmpty=true,
                         Name="IntegerRange")]
public struct IntegerRange
{
    private SqlInt32 minimumSoFar;
    private SqlInt32 maximumSoFar;

    public void Init()
    {
    }

    public void Accumulate(SqlInt32 Value)
    {
        if (!Value.IsNull)
        {
            if (this.minimumSoFar.IsNull)
            {
                this.minimumSoFar = Value.Value;
                this.maximumSoFar = Value.Value;
            }
            else
            {
                if (this.minimumSoFar.Value > Value.Value)
                    this.minimumSoFar = new SqlInt32(Value.Value);
                if (this.maximumSoFar.Value < Value.Value)
                    this.maximumSoFar = new SqlInt32(Value.Value);
            }
        }
    }

    public void Merge(IntegerRange Group)
    {
        if (!Group.minimumSoFar.IsNull)
        {
            if (this.minimumSoFar.Value > Group.minimumSoFar.Value)
                this.minimumSoFar = new SqlInt32(Group.minimumSoFar.Value);
            if (this.maximumSoFar.Value < Group.maximumSoFar.Value)
                this.maximumSoFar = new SqlInt32(Group.maximumSoFar.Value);
        }
    }

    public SqlInt32 Terminate()
    {
        if (this.minimumSoFar.IsNull)
            return new SqlInt32();
        else
            return new SqlInt32(this.maximumSoFar.Value - this.minimumSoFar.Value);
    }
}
