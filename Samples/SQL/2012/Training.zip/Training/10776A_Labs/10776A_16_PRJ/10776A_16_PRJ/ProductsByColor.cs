﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;


public partial class StoredProcedures
{
    [SqlProcedure]
    public static void ProductsByColor(SqlString Color)
    {
        SqlConnection conn = new SqlConnection("context connection=true");
        SqlCommand command = conn.CreateCommand();
        SqlPipe outputPipe = SqlContext.Pipe;

        outputPipe.Send("Hello. It's now " + DateTime.Now.ToLongTimeString() + " at the server.");

        if (Color.IsNull)
        {
            command.CommandText = "SELECT * FROM Production.Product WHERE (Color IS NULL) ORDER BY ProductID";
        }
        else
        {
            command.CommandText = "SELECT * FROM Production.Product WHERE (Color = @Color) ORDER BY ProductID";
            command.Parameters.Add(new SqlParameter("@Color", Color.Value));
        }
        conn.Open();
        outputPipe.Send(command.ExecuteReader());
        conn.Close();
    }
};
