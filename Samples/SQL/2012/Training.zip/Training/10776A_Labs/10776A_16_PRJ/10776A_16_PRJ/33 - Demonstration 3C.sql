-- Demonstration 3C - User-defined aggregates and data types

-- Step 1: Open a new query window 
--         and use the AdventureWorks database

USE AdventureWorks;
GO

-- Step 2: Catalog the IntegerRange aggregate
--         This aggregate implements a RANGE aggregate 
--         for integer values. (This is an example of creating 
--         an aggregate that exists in other database engines 
--         to assist in migrating existing code to SQL Server)

CREATE AGGREGATE dbo.IntegerRange
(@IntegerValue int)
RETURNS int
EXTERNAL NAME SQLCLR10776A.IntegerRange;
GO

-- Step 3: Test the integerrange aggregate 

SELECT dbo.IntegerRange(ProductID) AS RangeOfValues
FROM Production.Product;
GO
SELECT dbo.IntegerRange(ProductID) AS RangeOfValues
FROM Production.Product
WHERE Color = 'Turquoise';
GO

-- Step 4: Catalog the Rectangle data type

CREATE TYPE dbo.Rectangle
EXTERNAL NAME SQLCLR10776A.Rectangle;
GO

-- Step 5: Test the properties and methods of the data type

DECLARE @MyRectangle Rectangle;
SET @MyRectangle = '(2,3) - (4,6)';
SELECT @MyRectangle.ToString();
SELECT @MyRectangle.Width();
SELECT @MyRectangle.Height();
SELECT @MyRectangle.Area();
GO

DECLARE @MyRectangle Rectangle;
SET @MyRectangle = '(2,3) - (4,6)';
SET @MyRectangle.X1Value = 14;
SET @MyRectangle.Y1Value = 12;
SET @MyRectangle.X2Value = 19;
SET @MyRectangle.Y2Value = 4;
SELECT @MyRectangle.ToString();
GO

-- Step 6: Select the type itself, rather than a property 
--         or method of the type

DECLARE @MyRectangle Rectangle;
SET @MyRectangle = '(2,3) - (4,6)';
SELECT @MyRectangle;
GO

-- Step 7: Create a table using the Rectangle type

CREATE TABLE dbo.TempTest
( RecID int IDENTITY(1,1),
  Location Rectangle
);
GO

-- Step 8: Insert some rows into the table

INSERT INTO dbo.TempTest (Location) VALUES(CONVERT(Rectangle,'(35,3) - (4,5)'));
INSERT INTO dbo.TempTest (Location) VALUES(CONVERT(Rectangle,'(12.4,45) - (94,16.2)'));
GO

-- Step 9: Try to insert invalid data 
--         Note that all SQL CLR errors are wrapped in a 6522 error

INSERT INTO dbo.TempTest (Location) VALUES(CONVERT(Rectangle,'invaliddata'));
GO

-- Step 10: Access the data in the table � request properties

SELECT Location.X1Value AS X1,
       Location.Y1Value AS Y1
FROM dbo.TempTest;
GO

SELECT Location.ToString() 
FROM dbo.TempTest;
GO

-- Step 11: SELECT the object itself from the table to see how it is stored

SELECT Location
FROM dbo.TempTest;
GO

-- Step 12: Drop the table and the objects created

DROP TABLE dbo.TempTest;
GO

DROP TYPE dbo.Rectangle;
DROP AGGREGATE dbo.IntegerRange;
DROP PROCEDURE dbo.ProductsByColor;
DROP PROCEDURE dbo.WriteOSFile;
DROP FUNCTION dbo.RangeOfIntegers;
DROP FUNCTION dbo.FormatPhoneNumber;
DROP ASSEMBLY SQLCLR10776A;
GO

-- Step 13: Remove the TRUSTWORTHY setting from the database

ALTER DATABASE AdventureWorks SET TRUSTWORTHY OFF;
GO
