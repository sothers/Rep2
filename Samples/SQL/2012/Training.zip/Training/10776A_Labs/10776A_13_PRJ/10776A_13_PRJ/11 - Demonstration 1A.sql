-- Demonstration 1A

-- Step 1 - Open a query window to the tempdb database

USE tempdb;
GO

-- Step 2 - Create and populate a test table

CREATE TABLE dbo.TestTable
( TestTableID int IDENTITY(1,1) PRIMARY KEY,
  TestName nvarchar(20)
);
GO

INSERT INTO dbo.TestTable 
  (TestName)
  VALUES ('Row 1'),('Row 2'),('Row 3'),('Row 4');
GO

SELECT * FROM dbo.TestTable;
GO

-- Step 3 - Update the test table

UPDATE dbo.TestTable 
SET TestName = 'Update 1'
WHERE TestTableID = 1;
GO

-- Step 4 - Ask the students what they would expect to see if you now tried to rollback the transaction

-- Step 5 - Then attempt to roll it back
--          (An error occurs as there is no transaction current)

ROLLBACK;
GO

-- Step 6 - Requery the table and show that the update was not rolled back

SELECT * FROM dbo.TestTable;
GO

-- Step 7 - Now try the same in a transaction

BEGIN TRANSACTION;

UPDATE dbo.TestTable 
SET TestName = 'Update 2'
WHERE TestTableID = 2;

UPDATE dbo.TestTable 
SET TestName = 'Update 3'
WHERE TestTableID = 3;
GO

-- Step 8 - Ask the students what they would expect to see if they queried the table from within this transaction

-- Step 9 - Select from the table to show them the result

SELECT * FROM dbo.TestTable;
GO

-- Step 10 - Ask the students what they would expect to see at this point in another query window that selected from the table

-- Step 11 - Switch to a second query window


-- Step 14 - Then back in the first window, roll the transaction back

ROLLBACK;
GO

-- Step 15 - Note that the second query window has completed 
-- and the data in the same state it was prior to the transaction starting

-- Step 16 - Clean up 

DROP TABLE dbo.TestTable;
GO
