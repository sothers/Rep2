-- Demonstration 3A second Window

-- Step 6 - Open a second query window to the Deadlock database

USE Deadlock;
GO

-- Step 7 - Attempt to update the same product within a transaction

BEGIN TRANSACTION;

UPDATE dbo.Product 
SET ProductName = 'Update from window 2'
WHERE ProductID = 1;
GO

-- Step 8 - Back in activity monitor, note the lock information 
--          and in particular note the process that is blocked 
--          and the other process that is shown as being at the 
--          head of the blocking chain

-- Step 9 - Switch to the third window

