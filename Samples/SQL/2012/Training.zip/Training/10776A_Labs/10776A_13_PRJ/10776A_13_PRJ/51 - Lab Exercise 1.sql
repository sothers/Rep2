USE Deadlock;
GO

BEGIN TRAN
  UPDATE dbo.Product SET ProductName = 'Prod 2 Modified 1'
    WHERE ProductID = 2;

  WAITFOR DELAY '00:00:10';

  UPDATE dbo.Product SET ProductName = 'Prod 1 Modified 1'
    WHERE ProductID = 1;
COMMIT;

USE master;
GO
