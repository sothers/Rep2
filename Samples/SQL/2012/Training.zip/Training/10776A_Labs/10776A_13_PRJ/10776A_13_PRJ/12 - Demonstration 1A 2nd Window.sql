-- Demonstration 1A second Window

-- Step 12 - Query the table from the second window

USE tempdb;
GO

SELECT * FROM dbo.TestTable;
GO

-- Step 13 - Switch back to the first window
