-- Demonstration 3A

-- Step 1 - Open activity monitor to view the current lock information.

-- Step 2 - Explain each of the rows returned

-- Step 3 - Open a new query window to the Deadlock database

USE Deadlock;
GO

-- Step 4 - Update product 1 in a transaction

BEGIN TRANSACTION;

UPDATE dbo.Product 
SET ProductName = 'Update from window 1'
WHERE ProductID = 1;
GO

-- Step 5 - Switch to the second window

-- Step 15 - Roll back the transaction in the first window

ROLLBACK;
GO
