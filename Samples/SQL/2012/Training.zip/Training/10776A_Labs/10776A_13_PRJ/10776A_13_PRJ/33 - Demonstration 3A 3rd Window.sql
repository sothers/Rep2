-- Demonstration 3A third Window

-- Step 10 - Open a third query window to the Deadlock database

USE Deadlock;
GO

-- Step 11 - Query the system views to see the current locking

SELECT * FROM sys.dm_tran_locks;
SELECT * FROM sys.dm_tran_active_transactions;
GO

-- Step 12 - Make sure to locate the relevant info and explain it briefly

-- Step 13 - Cancel the query in the second window

-- Step 14 - Then return to the first window
