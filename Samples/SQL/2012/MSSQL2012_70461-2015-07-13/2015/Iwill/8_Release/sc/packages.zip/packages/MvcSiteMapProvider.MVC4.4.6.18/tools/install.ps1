# install.ps1
param($rootPath, $toolsPath, $package, $project)

$DTE.ItemOperations.Navigate("http://maartenba.github.io/MvcSiteMapProvider/getting-started.html", $DTE.vsNavigateOptions.vsNavigateOptionsNewWindow)
