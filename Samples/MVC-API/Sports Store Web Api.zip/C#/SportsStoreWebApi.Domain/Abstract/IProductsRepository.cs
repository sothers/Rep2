﻿using System.Collections.Generic;
using System.Linq;
using SportsStoreWebApi.Domain.Entities;

namespace SportsStoreWebApi.Domain.Abstract
{
    public interface IProductRepository
    {
        IEnumerable<Product> Products { get; set; }
    }
}
