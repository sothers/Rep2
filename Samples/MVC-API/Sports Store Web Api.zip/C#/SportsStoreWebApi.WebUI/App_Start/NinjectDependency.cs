﻿using System;
using System.Collections.Generic;
using System.Web.Http.Dependencies;
using Ninject;
using Ninject.Syntax;

namespace SportsStoreWebApi.WebUI.App_Start
{
    public class NinjectDependencyScope : IDependencyScope
    {
        private IResolutionRoot _resolutionRoot;

        public NinjectDependencyScope(IResolutionRoot resolver)
        {
            _resolutionRoot = resolver;
        }

        public object GetService(Type serviceType)
        {
            if (_resolutionRoot == null)
                throw new ObjectDisposedException("this", "This scope has been disposed");

            return _resolutionRoot.TryGet(serviceType);
        }

        public IEnumerable<object> GetServices(Type serviceType)
        {
            if (_resolutionRoot == null)
                throw new ObjectDisposedException("this", "This scope has been disposed");

            return _resolutionRoot.GetAll(serviceType);
        }

        public void Dispose()
        {
            var disposable = _resolutionRoot as IDisposable;
            if (disposable != null)
                disposable.Dispose();

            _resolutionRoot = null;
        }
    }

    // This class is the resolver, but it is also the global scope
    // so we derive from NinjectScope.
    public class NinjectDependencyResolver : NinjectDependencyScope, IDependencyResolver
    {
        private readonly IKernel _kernel;

        public NinjectDependencyResolver(IKernel kernel)
            : base(kernel)
        {
            _kernel = kernel;
        }

        public IDependencyScope BeginScope()
        {
            return new NinjectDependencyScope(_kernel.BeginBlock());
        }
    }
}