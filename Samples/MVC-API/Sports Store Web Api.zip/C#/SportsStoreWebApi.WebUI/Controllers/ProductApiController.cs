﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SportsStoreWebApi.Domain.Abstract;
using SportsStoreWebApi.Domain.Entities;
using SportsStoreWebApi.WebUI.Concrete;

namespace SportsStoreWebApi.WebUI.Controllers
{
    public class ProductApiController : ApiController
    {
        private readonly IProductRepository _productRepository;

        
        public ProductApiController(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }
        
        
        // GET api/product
        public IEnumerable<Product> GetAllProducts()
        {
            return _productRepository.Products.ToList();
        }

        public IEnumerable<Product> GetAllProducts(string category)
        {
            return _productRepository.Products.Where(p => p.Category == category).ToList();
        }

        public IEnumerable<Product> GetAllProducts(int page)
        {
            return _productRepository.Products.Skip((page - 1)*4).Take(4);
        }

        public IEnumerable<Product> GetAllProducts(string category, int page)
        {
            return _productRepository.Products.Where(p => p.Category == category).Skip((page - 1)*4).Take(4);
        }

        /*
        public int GetCount()
        {
            return _productRepository.Products.Count();
        }*/

        // GET api/product/5
        

        // POST api/product
        public void Post([FromBody]string value)
        {
        }

        // PUT api/product/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/product/5
        public void Delete(int id)
        {
        }
    }
}
