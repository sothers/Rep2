﻿using System.Collections.Generic;
using System.Linq;
using SportsStoreWebApi.Domain.Abstract;
using SportsStoreWebApi.Domain.Entities;
using System.ComponentModel.DataAnnotations.Schema;

namespace SportsStoreWebApi.WebUI.Concrete
{
    public class EfProductRepository : IProductRepository
    {

        private IList<Product> _products = new[]
                                                     {
                                                           new Product{ProductId = 1, Name = "Kayak", Description = "A boat for one person", Category = "WaterSports", Price = 275.00M},
                                                           new Product{ProductId = 2, Name = "Life Jacket", Description = "protective and fashionable", Category = "WaterSports", Price = 48.95M},
                                                           new Product{ProductId = 3, Name = "Soccer Ball", Description = "FIFA apporved size and weight", Category = "Soccer", Price = 19.50M},
                                                           new Product{ProductId = 4, Name = "Corner Flags", Description = "Give your playing field a professional touch", Category = "Soccer", Price = 34.95M},
                                                           new Product{ProductId = 5, Name = "Stadium", Description = "Flat packed 35,000 seat stadium", Category = "Soccer", Price = 79000.00M},
                                                           new Product{ProductId = 6, Name = "Thinking Cap", Description = "Impove brain by 75 %", Category = "Chess", Price = 16.00M},
                                                           new Product{ProductId = 7, Name = "Unsteady Chair", Description = "Secreatly give your opponnent a disadvantage", Category = "Chess", Price = 29.965M},
                                                           new Product{ProductId = 8, Name = "Human Chess Board", Description = "A fun for whole family", Category = "Chess", Price = 75.00M},
                                                           new Product{ProductId = 9, Name = "Bling Bling King", Description = "Gold plated, diamond stuffed king", Category = "Chess", Price = 1200.00M}
                                                      }; 

        public IEnumerable<Product> Products
        {
            get { return _products; }
            set { _products = value.ToArray(); }
        }
    }
}