﻿public class ResulMessage
{
    public string Message { get; set; }
}