﻿using System;

namespace MVCDemo13JSONAjaxRequestResponse.Models 
{
    //[Serializable]
    public class PersonModel
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
}