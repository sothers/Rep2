﻿using System.Collections.Generic;

namespace MVCDemo5ViewBag
{
    public class ColorModel
    {
        public int NumberOfColors 
        { 
            get; set; 
        }
        public List<string> Colors 
        { 
            get; set; 
        }
    }
}