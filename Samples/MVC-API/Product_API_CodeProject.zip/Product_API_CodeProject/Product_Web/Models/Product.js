﻿function Product()
{
    this.ID;
    this.Name;
    this.Category;
    this.Price;
}