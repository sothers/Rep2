﻿using ProductAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;

namespace ProductAPI.Controllers
{
    public class ProductController : ApiController
    {
        public static Lazy<List<Product>> products = new Lazy<List<Product>>();
        public static int PageLoadFlag = 1;
        public static int ProductId = 4;

        public ProductController()
        {
            if (PageLoadFlag == 1)
            {
                products.Value.Add(new Product { Id=1, Name="Bus", Category="Toy", Price=200.12F });
                products.Value.Add(new Product { Id = 2, Name = "Doll", Category = "Toy", Price = 300.25F });
                products.Value.Add(new Product { Id = 3, Name = "Car", Category = "Toy", Price = 500.10F });
                PageLoadFlag++;
            }
        }

        public List<Product> GetAllProducts()
        {
            return products.Value;
        }

        //
        // GET: /Product/Details/5
        public IHttpActionResult GetProduct(int id)
        {
            Product product = products.Value.FirstOrDefault((p) => p.Id == id);
            if (product == null)
                return NotFound();

            return Ok(product);
        }

        //
        // GET: /Product/Create
        public void ProductAdd(Product product)
        {
            product.Id = ProductId;
            products.Value.Add(product);
            ProductId++;
        }

    }
}
