// Database Setup, if you have not done so yet
/*

connect scott/tiger@oracle
drop procedure odp_obj1_sample_upd_contacts;
drop table odp_obj1_sample_contacts;
drop type odp_obj1_sample_person_type;

create type odp_obj1_sample_person_type as object 
  (name varchar2(30), address varchar2(60), age number(3)) NOT FINAL;
/
 
create table odp_obj1_sample_contacts (
  contact        odp_obj1_sample_person_type, 
  contact_phone  varchar2(20));

create procedure odp_obj1_sample_upd_contacts(
  param1 IN OUT odp_obj1_sample_person_type,
  param2 IN     varchar2) as
  begin
    param1.age := param1.age + 1;    
    insert into odp_obj1_sample_contacts values(param1,param2);   
  end;
/

*/

//C#

using System;
using System.Data;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

/// <summary name=PsfObject1>
/// Object Sample : Demonstrates how to map, fetch, and 
///   manipulate the Oracle UDT as a custom object
/// </summary>
class ObjectSample
{
  static void Main(string[] args)
  {
    string constr = "user id=scott;password=tiger;data source=oracle";
    string sql1 = "odp_obj1_sample_upd_contacts";
    string sql2 = "select c.contact from odp_obj1_sample_contacts c";    

    // Create a new Person object
    Person p1   = new Person();
    p1.Name     = "John";
    p1.Address  = "Address1";
#if NET20
    // Since Age is a .NET 2.0 Nullable Type (which can store nulls), the
    // AgeIsNull property is not required.
#else
    p1.AgeIsNull = false;
#endif
    p1.Age = 20;

    // Establish a connection to Oracle
    OracleConnection con = new OracleConnection(constr);
    con.Open();

    // Update Person object and insert it into a database table
    OracleCommand cmd = new OracleCommand(sql1, con);
    cmd.CommandType = CommandType.StoredProcedure;
    OracleParameter param1 = new OracleParameter();
    
    param1.OracleDbType   = OracleDbType.Object;
    param1.Direction      = ParameterDirection.InputOutput;

    // Note: The UdtTypeName is case-senstive
    param1.UdtTypeName     = "SCOTT.ODP_OBJ1_SAMPLE_PERSON_TYPE";   
    param1.Value           = p1;
    
    cmd.Parameters.Add(param1);

    OracleParameter param2 = new OracleParameter();
    param2.OracleDbType = OracleDbType.Varchar2;
    param2.Direction = ParameterDirection.Input;   
    param2.Value = "1-800-555-4412";

    cmd.Parameters.Add(param2);

    // Insert the UDT into the table
    cmd.ExecuteNonQuery();

    // Print out the updated Person object
    Console.WriteLine("Updated Person: " + param1.Value);

    // Retrieve the updated objects from the database table
    cmd.Parameters.Clear();
    cmd.CommandText = sql2;
    cmd.CommandType = CommandType.Text;
    OracleDataReader reader = cmd.ExecuteReader();
    
    // Fetch each row
    int rowCount = 0;
    while (reader.Read())
    {
      // Fetch the objects as a custom type
      Person p;      
      if (reader.IsDBNull(0))
        p = Person.Null;
      else
        p = (Person)reader.GetValue(0);

      Console.WriteLine("Row {0}: {1}", rowCount++, p);
    }
   
    // Clean up
    reader.Dispose();
    cmd.Dispose();
    con.Close();
    con.Dispose();
  }
}

/* Person Class
**   An instance of a Person class represents an ODP_OBJ1_SAMPLE_PERSON_TYPE object
**   A custom type must implement INullable and IOracleCustomType interfaces
*/
public class Person : INullable, IOracleCustomType
{
  private bool          m_bIsNull;  // Whether the Person object is NULL    
  private string        m_name;     // "NAME" attribute  
  private OracleString  m_address;  // "ADDRESS" attribute  
#if NET20
  // Use .NET 2.0 Nullable Types to store NULL attribute values
  private int?    m_age;              // "AGE" attribute
#else
  private int     m_age;              // "AGE" attribute

  // Note that if the "NAME" attribute is NULL, then m_name will be set to null
  private bool    m_bAgeIsNull = true; // Whether the "AGE" attribute is NULL 
#endif // NET20

  // Implementation of INullable.IsNull
  public virtual bool IsNull
  {
    get
    {
      return m_bIsNull;
    }
  }

  // Person.Null is used to return a NULL Person object
  public static Person Null
  {
    get
    {
      Person p = new Person();
      p.m_bIsNull = true;
      return p;
    }
  }

  // Specify the OracleObjectMappingAttribute to map "Name" to "NAME"
  [OracleObjectMappingAttribute("NAME")]
  // The mapping can also be specified using attribute index 0
  // [OracleObjectMappingAttribute(0)]
  public string Name
  {
    get
    {
      return m_name;
    }
    set
    {
      m_name = value;
    }
  }

  // Specify the OracleObjectMappingAttribute to map "Address" to "ADDRESS"
  [OracleObjectMappingAttribute("ADDRESS")]
  // The mapping can also be specified using attribute index 1
  // [OracleObjectMappingAttribute(1)]
  public OracleString Address
  {
    get
    {
      return m_address;
    }
    set
    {
      m_address = value;
    }
  }

  // Specify the OracleObjectMappingAttribute to map "Age" to "AGE"
  [OracleObjectMappingAttribute("AGE")]
  // The mapping can also be specified using attribute index 2
  // [OracleObjectMappingAttribute(2)]
#if NET20
  public int? Age
#else
  public int Age
#endif
  {
    get
    {
      return m_age;
    }
    set
    {
      m_age = value;
    }
  }

#if NET20  
  // Since Age is a .NET 2.0 Nullable Type (which can store nulls), the
  // AgeIsNull property is not required.
#else
  public bool AgeIsNull
  {
    get
    {
      return m_bAgeIsNull;
    }
    set
    {
      m_bAgeIsNull = value;
    }
  }
#endif

  // Implementation of IOracleCustomType.FromCustomObject()
  public virtual void FromCustomObject(OracleConnection con, IntPtr pUdt)
  {
    // Convert from the Custom Type to Oracle Object

    // Set the "NAME" attribute.     
    // By default the "NAME" attribute will be set to NULL
    if (m_name != null)
    {
      OracleUdt.SetValue(con, pUdt, "NAME", m_name);
      // The "NAME" attribute can also be accessed by specifying index 0
      // OracleUdt.SetValue(con, pUdt, 0, m_name);
    }

    // Set the "ADDRESS" attribute.     
    // By default the "ADDRESS" attribute will be set to NULL
    if (!m_address.IsNull)
    {
      OracleUdt.SetValue(con, pUdt, "ADDRESS", m_address);
      // The "ADDRESS" attribute can also be accessed by specifying index 1
      // OracleUdt.SetValue(con, pUdt, 1, m_address);
    }

    // Set the "AGE" attribute.    
#if NET20
    // By default the "AGE" attribute will be set to NULL
    if (m_age != null)
    {
      OracleUdt.SetValue(con, pUdt, "AGE", m_age);
      // The "AGE attribute can also be accessed by specifying index 2
      // OracleUdt.SetValue(con, pUdt, 2, m_age);
    }    
#else
    // By default the "AGE" attribute will be set to NULL
    if (!m_bAgeIsNull)
    {
      OracleUdt.SetValue(con, pUdt, "AGE", m_age);
      // The "AGE attribute can also be accessed by specifying index 2
      // OracleUdt.SetValue(con, pUdt, 2, m_age);
    }    
#endif
  }

  // Implementation of IOracleCustomType.ToCustomObject()
  public virtual void ToCustomObject(OracleConnection con, IntPtr pUdt)
  {
    // Convert from the Oracle Object to a Custom Type

    // Get the "NAME" attribute
    // If the "NAME" attribute is NULL, then null will be returned
    m_name = (string)OracleUdt.GetValue(con, pUdt, "NAME");

    // The "NAME" attribute can also be accessed by specifying index 0
    // m_name = (string)OracleUdt.GetValue(con, pUdt, 0);

    // Get the "ADDRESS" attribute
    // If the "ADDRESS" attribute is NULL, then OracleString.Null will be returned
    m_address = (OracleString)OracleUdt.GetValue(con, pUdt, "ADDRESS");

    // The "NAME" attribute can also be accessed by specifying index 1
    // m_address = (OracleString)OracleUdt.GetValue(con, pUdt, 1);

    // Get the "AGE" attribute
#if NET20
    // If the "AGE" attribute is NULL, then null will  be returned
    m_age = (int?)OracleUdt.GetValue(con, pUdt, "AGE");
    // The "AGE" attribute can also be accessed by specifying index 2
    // m_age = (int?)OracleUdt.GetValue(con, pUdt, 2);    
#else
    // If the "AGE" attribute is NULL, then OracleUdt.GetValue will 
    //   return DBNull.Value
    if (!(m_bAgeIsNull = OracleUdt.IsDBNull(con, pUdt, "AGE")))
      m_age = (int)OracleUdt.GetValue(con, pUdt, "AGE");

    // The "AGE" attribute can also be accessed by specifying index 2
    /*
    if (!(m_bAgeIsNull = OracleUdt.IsDBNull(con, pUdt, 2)))
      m_age = (int)OracleUdt.GetValue(con, pUdt, 2);    
    */
#endif
  }

  public override string ToString()
  {
    // Return a string representation of the custom object
    if (m_bIsNull)
      return "Person.Null";
    else
    {
      string name     =  (m_name == null) ? "NULL" : m_name;
      string address  =  (m_address.IsNull) ? "NULL" : m_address.Value;
#if NET20
      string age      = (m_age == null)? "NULL" : m_age.ToString(); 
#else      
      string age      = (m_bAgeIsNull)? "NULL" : m_age.ToString();
#endif
      return "Person(" + name + ", " + address + ", " + age + ")";
    }
  }
}

/* PersonFactory Class
**   An instance of the PersonFactory class is used to create Person objects
*/
[OracleCustomTypeMappingAttribute("SCOTT.ODP_OBJ1_SAMPLE_PERSON_TYPE")]
public class PersonFactory : IOracleCustomTypeFactory
{
  // Implementation of IOracleCustomTypeFactory.CreateObject()
  public IOracleCustomType CreateObject()
  {
    // Return a new custom object
    return new Person();
  }
}