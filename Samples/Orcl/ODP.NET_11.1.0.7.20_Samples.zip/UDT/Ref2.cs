// Database Setup, if you have not done so yet
/*

connect scott/tiger@oracle
drop table odp_ref2_sample_person_obj_tab;
drop type odp_ref2_sample_student_type;
drop type odp_ref2_sample_person_type;

create type odp_ref2_sample_person_type as object 
  (name varchar2(30), address varchar2(60), age number(3)) NOT FINAL;
/
create type odp_ref2_sample_student_type under odp_ref2_sample_person_type
  (dept_id number(2), major varchar2(20));
/

-- odp_ref2_sample_person_obj_tab can store both persons and student objects
create table odp_ref2_sample_person_obj_tab of odp_ref2_sample_person_type;
 
*/

//C#

using System;
using System.Data;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

/// <summary name=RefRef2>
/// REF Type Sample : Demonstrates how to obtain Custom Type objects
///   from OracleRef objects.  It also demonstrates how to update 
///   UDTs through the OracleRef object and to obtain the appropriate 
///   instantce type for those UDTs that have an inheritance hierarchy
///   from OracleRef objects.
/// </summary>
class RefSample
{
  static void Main(string[] args)
  {
    string constr = "user id=scott;password=tiger;data source=oracle";
    string sql1   = "select value(p) from odp_ref2_sample_person_obj_tab p";
    string udtTypeNameP = "ODP_REF2_SAMPLE_PERSON_TYPE";
    string udtTypeNameS = "ODP_REF2_SAMPLE_STUDENT_TYPE";
    string objTabNameP = "ODP_REF2_SAMPLE_PERSON_OBJ_TAB";

    // Create a new Person object
    Person p = new Person();
    p.Name = "John";
    p.Address = "Address1";
#if NET20
    // Since Age is a .NET 2.0 Nullable Type (which can store nulls), the
    // AgeIsNull property is not required.
#else
    p.AgeIsNull = false;
#endif
    p.Age = 20;

    // Create a new Student object
    Student s = new Student();
    s.Name = "Jim";
    s.Address = "Address2";
#if NET20
    // Since Age is a .NET 2.0 Nullable Type (which can store nulls), the
    // AgeIsNull property is not required.
#else
    s.AgeIsNull = false;
#endif
    s.Age = 25;
    s.Major = "Physics";

    // Establish a connection to Oracle
    OracleConnection con = new OracleConnection(constr);
    con.Open();

    // Insert 2 rows into an object table
    OracleTransaction txn1 = con.BeginTransaction();
    OracleRef refP = new OracleRef(con, udtTypeNameP, objTabNameP);
    OracleRef refS = new OracleRef(con, udtTypeNameS, objTabNameP);    

    // Update refs
    refP.Update(p, false);
    refS.Update(s, false);
     
    // Flush changes made on both refs back to database
    con.FlushCache();
    txn1.Commit();

    // Fetch rows from database table
    Person p1 = (Person)refP.GetCustomObject(OracleUdtFetchOption.Server);
    Student s1 = (Student)refS.GetCustomObject(OracleUdtFetchOption.Server);
    Console.WriteLine("Person: " + p1);
    Console.WriteLine("Student: " + s1);

    // Update person object
    OracleTransaction txn2 = con.BeginTransaction();
    
    Console.WriteLine("IsLocked before GetCustomObjectForUpdate: {0}", 
                      refP.IsLocked);

    // Instead of calling GetCustomObjectForUpdate(), we could have called 
    // Lock() followed by GetCustomObject(OracleUdtFetchOption.Server) to 
    // achieve the same.
    Person p2 = (Person)refP.GetCustomObjectForUpdate(true);

    Console.WriteLine("IsLocked after GetCustomObjectForUpdate: {0}", 
                      refP.IsLocked);

    p2.Age = p2.Age +1 ;    
    refP.Update(p2, false);

    Console.WriteLine("HasChanges before Flush: {0}",
                       refP.HasChanges);
    refP.Flush();

    Console.WriteLine("HasChanges after Flush: {0}",
                       refP.HasChanges);
    txn2.Commit();

    // Delete student object 
    OracleTransaction txn3 = con.BeginTransaction();   
    refS.Delete(true);
    txn3.Commit();    

    // Retrieve rows from the database table
    OracleCommand cmd = new OracleCommand(sql1, con);
    cmd.CommandType = CommandType.Text;
    OracleDataReader reader = cmd.ExecuteReader();
    
    // Fetch each row
    int rowCount = 0;
    while (reader.Read())
    {
      // Fetch the objects as a custom type
      Person p3;      
      if (reader.IsDBNull(0))
        p3 = Person.Null;
      else
        p3 = (Person)reader.GetValue(0);

      Console.WriteLine("Row {0}: {1}", rowCount++, p3);
    }
   
    // Clean up
    refS.Dispose();
    refP.Dispose();
    reader.Dispose();
    cmd.Dispose();
    txn1.Dispose();
    txn2.Dispose();
    txn3.Dispose();
    con.Close();
    con.Dispose();
  }
}

/* Person Class
**   An instance of a Person class represents an 
**     ODP_REF2_SAMPLE_PERSON_TYPE object
**   A custom type must implement INullable and IOracleCustomType interfaces
*/
public class Person : INullable, IOracleCustomType
{
  private bool          m_bIsNull;  // Whether the Person object is NULL    
  private string        m_name;     // "NAME" attribute  
  private OracleString  m_address;  // "ADDRESS" attribute  
#if NET20
  // Use .NET 2.0 Nullable Types to store NULL attribute values
  private int?    m_age;              // "AGE" attribute
#else
  private int     m_age;              // "AGE" attribute

  // Note that if the "NAME" attribute is NULL, then m_name will be set to null
  private bool    m_bAgeIsNull = true; // Whether the "AGE" attribute is NULL 
#endif // NET20

  // Implementation of INullable.IsNull
  public virtual bool IsNull
  {
    get
    {
      return m_bIsNull;
    }
  }

  // Person.Null is used to return a NULL Person object
  public static Person Null
  {
    get
    {
      Person p = new Person();
      p.m_bIsNull = true;
      return p;
    }
  }

  // Specify the OracleObjectMappingAttribute to map "Name" to "NAME"
  [OracleObjectMappingAttribute("NAME")]
  // The mapping can also be specified using attribute index 0
  // [OracleObjectMappingAttribute(0)]
  public string Name
  {
    get
    {
      return m_name;
    }
    set
    {
      m_name = value;
    }
  }

  // Specify the OracleObjectMappingAttribute to map "Address" to "ADDRESS"
  [OracleObjectMappingAttribute("ADDRESS")]
  // The mapping can also be specified using attribute index 1
  // [OracleObjectMappingAttribute(1)]
  public OracleString Address
  {
    get
    {
      return m_address;
    }
    set
    {
      m_address = value;
    }
  }

  // Specify the OracleObjectMappingAttribute to map "Age" to "AGE"
  [OracleObjectMappingAttribute("AGE")]
  // The mapping can also be specified using attribute index 2
  // [OracleObjectMappingAttribute(2)]
#if NET20
  public int? Age
#else
  public int Age
#endif
  {
    get
    {
      return m_age;
    }
    set
    {
      m_age = value;
    }
  }

#if NET20  
  // Since Age is a .NET 2.0 Nullable Type (which can store nulls), the
  // AgeIsNull property is not required.
#else
  public bool AgeIsNull
  {
    get
    {
      return m_bAgeIsNull;
    }
    set
    {
      m_bAgeIsNull = value;
    }
  }
#endif

  // Implementation of IOracleCustomType.FromCustomObject()
  public virtual void FromCustomObject(OracleConnection con, IntPtr pUdt)
  {
    // Convert from the Custom Type to Oracle Object

    // Set the "NAME" attribute.     
    // By default the "NAME" attribute will be set to NULL
    if (m_name != null)
    {
      OracleUdt.SetValue(con, pUdt, "NAME", m_name);
      // The "NAME" attribute can also be accessed by specifying index 0
      // OracleUdt.SetValue(con, pUdt, 0, m_name);
    }

    // Set the "ADDRESS" attribute.     
    // By default the "ADDRESS" attribute will be set to NULL
    if (!m_address.IsNull)
    {
      OracleUdt.SetValue(con, pUdt, "ADDRESS", m_address);
      // The "ADDRESS" attribute can also be accessed by specifying index 1
      // OracleUdt.SetValue(con, pUdt, 1, m_address);
    }

    // Set the "AGE" attribute.    
#if NET20
    // By default the "AGE" attribute will be set to NULL
    if (m_age != null)
    {
      OracleUdt.SetValue(con, pUdt, "AGE", m_age);
      // The "AGE attribute can also be accessed by specifying index 2
      // OracleUdt.SetValue(con, pUdt, 2, m_age);
    }    
#else
    // By default the "AGE" attribute will be set to NULL
    if (!m_bAgeIsNull)
    {
      OracleUdt.SetValue(con, pUdt, "AGE", m_age);
      // The "AGE attribute can also be accessed by specifying index 2
      // OracleUdt.SetValue(con, pUdt, 2, m_age);
    }    
#endif
  }

  // Implementation of IOracleCustomType.ToCustomObject()
  public virtual void ToCustomObject(OracleConnection con, IntPtr pUdt)
  {
    // Convert from the Oracle Object to a Custom Type

    // Get the "NAME" attribute
    // If the "NAME" attribute is NULL, then null will be returned
    m_name = (string)OracleUdt.GetValue(con, pUdt, "NAME");

    // The "NAME" attribute can also be accessed by specifying index 0
    // m_name = (string)OracleUdt.GetValue(con, pUdt, 0);

    // Get the "ADDRESS" attribute
    // If the "ADDRESS" attribute is NULL, then OracleString.Null will be returned
    m_address = (OracleString)OracleUdt.GetValue(con, pUdt, "ADDRESS");

    // The "NAME" attribute can also be accessed by specifying index 1
    // m_address = (OracleString)OracleUdt.GetValue(con, pUdt, 1);

    // Get the "AGE" attribute
#if NET20
    // If the "AGE" attribute is NULL, then null will  be returned
    m_age = (int?)OracleUdt.GetValue(con, pUdt, "AGE");
    // The "AGE" attribute can also be accessed by specifying index 2
    // m_age = (int?)OracleUdt.GetValue(con, pUdt, 2);    
#else
    // If the "AGE" attribute is NULL, then OracleUdt.GetValue will 
    //   return DBNull.Value
    if (!(m_bAgeIsNull = OracleUdt.IsDBNull(con, pUdt, "AGE")))
      m_age = (int)OracleUdt.GetValue(con, pUdt, "AGE");

    // The "AGE" attribute can also be accessed by specifying index 2
    /*
    if (!(m_bAgeIsNull = OracleUdt.IsDBNull(con, pUdt, 2)))
      m_age = (int)OracleUdt.GetValue(con, pUdt, 2);    
    */
#endif
  }

  public override string ToString()
  {
    // Return a string representation of the custom object
    if (m_bIsNull)
      return "Person.Null";
    else
    {
      string name     =  (m_name == null) ? "NULL" : m_name;
      string address  =  (m_address.IsNull) ? "NULL" : m_address.Value;
#if NET20
      string age      = (m_age == null)? "NULL" : m_age.ToString(); 
#else      
      string age      = (m_bAgeIsNull)? "NULL" : m_age.ToString();
#endif
      return "Person(" + name + ", " + address + ", " + age + ")";
    }
  }
}

/* PersonFactory Class
**   An instance of the PersonFactory class is used to create Person objects
*/
[OracleCustomTypeMappingAttribute("SCOTT.ODP_REF2_SAMPLE_PERSON_TYPE")]
public class PersonFactory : IOracleCustomTypeFactory
{
  // Implementation of IOracleCustomTypeFactory.CreateObject()
  public IOracleCustomType CreateObject()
  {
    // Return a new custom object
    return new Person();
  }
}

/* Student Class
**   An instance of a Student class represents an 
**     ODP_REF2_SAMPLE_STUDENT_TYPE object
**   Note that we do not map the "DEPT_ID" attribute (attribute index 3), 
**     so it will always be NULL
**   A custom type must implement INullable and IOracleCustomType interfaces
*/
public class Student : Person, INullable, IOracleCustomType
{
  private bool m_bIsNull;           // Whether the Student object is NULL
  private string m_major;           // "MAJOR" attribute

  // Implementation of INullable.IsNull
  public override bool IsNull
  {
    get
    {
      return m_bIsNull;
    }
  }

  // Student.Null is used to return a NULL Student object
  public new static Student Null
  {
    get
    {
      Student s = new Student();
      s.m_bIsNull = true;
      return s;
    }
  }

  // Specify the OracleObjectMappingAttribute to map "Major" to "MAJOR"
  [OracleObjectMappingAttribute("MAJOR")]
  // The mapping can also be specified using attribute index 4
  // [OracleObjectMappingAttribute(4)]
  public string Major
  {
    get
    {
      return m_major;
    }
    set
    {
      m_major = value;
    }
  }

  // Implementation of IOracleCustomType.FromCustomObject()
  public override void FromCustomObject(OracleConnection con, IntPtr pUdt)
  {
    // Convert from the Custom Type to Oracle Object
    // Invoke the base class conversion method
    base.FromCustomObject(con, pUdt);

    // Set the "MAJOR" attribute. 
    // By default the "MAJOR" attribute will be set to NULL
    if (m_major != null)
      OracleUdt.SetValue(con, pUdt, "MAJOR", m_major);

    // The "MAJOR" attribute can also be accessed by specifying index 4
    // OracleUdt.SetValue(con, pUdt, 4, m_major);
  }

  // Implementation of IOracleCustomType.ToCustomObject()
  public override void ToCustomObject(OracleConnection con, IntPtr pUdt)
  {
    // Convert from the Oracle Object to a Custom Type
    // Invoke the base class conversion method
    base.ToCustomObject(con, pUdt);

    // Get the "MAJOR" attribute
    // If the "MAJOR" attribute is NULL, then "null" will be returned
    m_major = (string)OracleUdt.GetValue(con, pUdt, "MAJOR");

    // The "MAJOR" attribute can also be accessed by specifying index 4
    // m_major = (string)OracleUdt.GetValue(con, pUdt, 4);
  }

  public override string ToString()
  {
    // Return a string representation of the custom object
    if (m_bIsNull)
    {
      return "Student.Null";
    }
    else
    {
      string name     = (Name == null) ? "NULL" : Name;
      string address  = (Address.IsNull) ? "NULL" : Address.Value;
#if NET20
      string age      = (Age == null) ? "NULL" : Age.ToString();
#else      
      string age      = (AgeIsNull)?    "NULL" : Age.ToString();
#endif
      string major = (m_major == null) ? "NULL" : m_major;
      return "Student(" + name + ", " + address + ", " + age + ", " + 
        major + ")";
    }
  }
}

/* StudentFactory Class
**   An instance of the StudentFactory class is used to create Student objects
*/
[OracleCustomTypeMappingAttribute("SCOTT.ODP_REF2_SAMPLE_STUDENT_TYPE")]
public class StudentFactory : IOracleCustomTypeFactory
{
  // Implementation of IOracleCustomTypeFactory.CreateObject()
  public IOracleCustomType CreateObject()
  {
    // Return a new custom object
    return new Student();
  }
}