// Database Setup, if you have not done so yet
// The following types are being created to demonstrate retrieval of 
// types quite similar to the spatial types.
/*

connect scott/tiger@oracle
drop table odp_sample_sdo_geo_obj_tab;
drop type odp_sample_sdo_geometry_type;
drop type odp_sample_sdo_ordinate_type;
drop type odp_sample_sdo_elem_info_type;
drop type odp_sample_sdo_point_type;

create type odp_sample_sdo_point_type as object
 (sdo_point_x number, sdo_point_y number, sdo_point_z number);
/

create type odp_sample_sdo_elem_info_type as varray(100) of number;
/

create type odp_sample_sdo_ordinate_type as  varray(100) of number;
/

create type odp_sample_sdo_geometry_type as object 
 (sdo_gtype number, sdo_srid number, sdo_point odp_sample_sdo_point_type,
  sdo_elem_info odp_sample_sdo_elem_info_type,
  sdo_ordinate odp_sample_sdo_ordinate_type);
/

create table odp_sample_sdo_geo_obj_tab of odp_sample_sdo_geometry_type;

insert into odp_sample_sdo_geo_obj_tab values(odp_sample_sdo_geometry_type(
 123,123,odp_sample_sdo_point_type(123.45,123.45,123.45),
 odp_sample_sdo_elem_info_type(123,123),
 odp_sample_sdo_ordinate_type(123.45,123.45)));

commit;

*/
using System;
using System.Data;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

/// <summary name=PsfObject3>
/// Spatial Types Sample: Demonstrates how to map and fetch 
///   types similar to Oracle Spatial Types as Custom Types.
/// </summary>
class SpatialTypeSample
{
  static void Main(string[] args)
  {
    string constr = "user id=scott;password=tiger;data source=oracle";
    string sql1 = "select value(p) from odp_sample_sdo_geo_obj_tab p";

    // Establish a connection to Oracle
    OracleConnection con = new OracleConnection(constr);
    con.Open();

    OracleCommand cmd = new OracleCommand(sql1, con);

    OracleDataReader reader = cmd.ExecuteReader();

    // Fetch each row
    int rowCount = 0;
    while (reader.Read())
    {
      // Fetch the objects as a custom type
      SdoGeometry p;
      if (reader.IsDBNull(0))
        p = SdoGeometry.Null;
      else
        p = (SdoGeometry)reader.GetValue(0);

      Console.WriteLine("Row {0}: {1}", rowCount++, p);
    }

    // Clean up
    reader.Dispose();
    cmd.Dispose();
    con.Close();
    con.Dispose();
  }
}

public class SdoPoint : IOracleCustomType, INullable
{
  [OracleObjectMapping(0)]
  public double X;
  [OracleObjectMapping(1)]
  public double Y;
  [OracleObjectMapping(2)]
  public double Z;

  private bool m_bIsNull;

  public bool IsNull
  {
    get
    {
      return m_bIsNull;
    }
  }

  public static SdoPoint Null
  {
    get
    {
      SdoPoint obj = new SdoPoint();
      obj.m_bIsNull = true;
      return obj;
    }
  }
  public override string ToString()
  {
    if (m_bIsNull)
      return "SdoPoint.Null";
    else
      return "SdoPoint(" + X + "," + Y + "," + Z + ")";
  }

  public void ToCustomObject(OracleConnection con, IntPtr pUdt)
  {
    // If the UDT may contain NULL attribute data, enable the following code
    //if (!OracleUdt.IsDBNull(con, pUdt, 0))
    X = (double)OracleUdt.GetValue(con, pUdt, 0);

    // If the UDT may contain NULL attribute data, enable the following code
    //if (!OracleUdt.IsDBNull(con, pUdt, 1))
    Y = (double)OracleUdt.GetValue(con, pUdt, 1);

    // If the UDT may contain NULL attribute data, enable the following code
    //if (!OracleUdt.IsDBNull(con, pUdt, 2))
    Z = (double)OracleUdt.GetValue(con, pUdt, 2);
  }

  public void FromCustomObject(OracleConnection con, IntPtr pUdt)
  {
    OracleUdt.SetValue(con, pUdt, 0, X);
    OracleUdt.SetValue(con, pUdt, 1, Y);
    OracleUdt.SetValue(con, pUdt, 2, Z);
  }
}

[OracleCustomTypeMapping("SCOTT.ODP_SAMPLE_SDO_POINT_TYPE")]
public class SdoPointFactory : IOracleCustomTypeFactory
{
  // IOracleCustomTypeFactory Inteface
  public IOracleCustomType CreateObject()
  {
    SdoPoint sdoPoint = new SdoPoint();
    return sdoPoint;
  }
}

public class SdoGeometry : INullable, IOracleCustomType
{
  [OracleObjectMapping(0)]
  public int _gtype;
  [OracleObjectMapping(1)]
  public int _srid;
  [OracleObjectMapping(2)]
  public SdoPoint _point;
  [OracleObjectMapping(3)]
  public int[] _elementInfo;
  [OracleObjectMapping(4)]
  public double[] _ordinates;

  private bool m_bIsNull;

  public bool IsNull
  {
    get
    {
      return m_bIsNull;
    }
  }

  public static SdoGeometry Null
  {
    get
    {
      SdoGeometry obj = new SdoGeometry();
      obj.m_bIsNull = true;
      return obj;
    }
  }
  public void ToCustomObject(OracleConnection con, IntPtr pUdt)
  {
    // If the UDT may contain NULL attribute data, enable the following code
    //if (!OracleUdt.IsDBNull(con, pUdt, 0))
    _gtype = (int)OracleUdt.GetValue(con, pUdt, 0);

    // If the UDT may contain NULL attribute data, enable the following code
    //if (!OracleUdt.IsDBNull(con, pUdt, 0))
    _srid = (int)OracleUdt.GetValue(con, pUdt, 1);
    _point = (SdoPoint)OracleUdt.GetValue(con, pUdt, 2);
    _elementInfo = (int[])OracleUdt.GetValue(con, pUdt, 3);
    _ordinates = (double[])OracleUdt.GetValue(con, pUdt, 4);
  }

  public void FromCustomObject(OracleConnection con, IntPtr pUdt)
  {
    OracleUdt.SetValue(con, pUdt, 0, _gtype);
    OracleUdt.SetValue(con, pUdt, 1, _srid);
    OracleUdt.SetValue(con, pUdt, 2, _point);
    OracleUdt.SetValue(con, pUdt, 3, _elementInfo);
    OracleUdt.SetValue(con, pUdt, 4, _ordinates);
  }

  public int[] ElementInfo
  {
    get
    {
      return _elementInfo;
    }
  }

  public double[] Ordinates
  {
    get
    {
      return _ordinates;
    }
  }

  public override string ToString()
  {
    string eleminfostr = String.Empty, ordinatesstr = String.Empty;
    if (m_bIsNull)
      return "SdoGeometry.Null";
    else
    {
      eleminfostr = _elementInfo[0].ToString();
      for (int i = 1; i < _elementInfo.Length; i++)
        eleminfostr += "," + _elementInfo[i];
      eleminfostr = "ElementInfo(" + eleminfostr + ")";

      ordinatesstr = _ordinates[0].ToString();
      for (int i = 1; i < _ordinates.Length; i++)
        ordinatesstr += "," + _ordinates[i];
      ordinatesstr = "Ordinates(" + ordinatesstr + ")";
    }
    return String.Format("SdoGeometry({0},{1},{2},{3},{4})",
      _gtype, _srid, _point, eleminfostr, ordinatesstr);
  }
}

[OracleCustomTypeMapping("SCOTT.ODP_SAMPLE_SDO_GEOMETRY_TYPE")]
public class SdoGeometryFactory : IOracleCustomTypeFactory
{
  // IOracleCustomTypeFactory Inteface
  public IOracleCustomType CreateObject()
  {
    return new SdoGeometry();
  }
}

[OracleCustomTypeMapping("SCOTT.ODP_SAMPLE_SDO_ELEM_INFO_TYPE")]
public class SdoElemInfoArrayFactory : IOracleArrayTypeFactory
{
  // IOracleArrayTypeFactory.CreateArray Inteface
  public Array CreateArray(int numElems)
  {
    return new int[numElems];
  }

  // IOracleArrayTypeFactory.CreateStatusArray
  public Array CreateStatusArray(int numElems)
  {
    // An OracleUdtStatus[] is not required to store null status information
    // if there is no NULL attribute data in the element array
    return null;
  }
}

[OracleCustomTypeMapping("SCOTT.ODP_SAMPLE_SDO_ORDINATE_TYPE")]
public class SdoOrdinateArrayFactory : IOracleArrayTypeFactory
{
  // IOracleArrayTypeFactory.CreateArray Inteface
  public Array CreateArray(int numElems)
  {
    return new double[numElems];
  }

  // IOracleArrayTypeFactory.CreateStatusArray
  public Array CreateStatusArray(int numElems)
  {
    // An OracleUdtStatus[] is not required to store null status information
    // if there is no NULL attribute data in the element array
    return null;

  }
}

