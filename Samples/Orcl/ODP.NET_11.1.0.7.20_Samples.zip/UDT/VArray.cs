// Database Setup, if you have not done so yet
/*

connect scott/tiger@oracle
drop procedure odp_varray_sample_proc;
drop table odp_varray_sample_rel_tab;
drop type odp_varray_sample_type;

create type odp_varray_sample_type as varray(10) of number; 
/

create table odp_varray_sample_rel_tab
  (col1 odp_varray_sample_type);

create procedure odp_varray_sample_proc(
  param1 IN OUT odp_varray_sample_type) as
  begin
    param1.Extend(1);
    param1(param1.Last) := 9;
    insert into odp_varray_sample_rel_tab values(param1);   
  end;
/

*/

using System;
using System.Data;
using System.Collections;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

/// <summary name=PsfArray1>
/// VARRAY sample: Demonstrates how to map, fetch, and 
///   manipulate the Oracle VARRAY as a custom object
/// </summary>
class VArraySample
{
  static void Main(string[] args)
  {
    string constr = "user id=scott;password=tiger;data source=oracle";
    string sql1 = "select col1 from odp_varray_sample_rel_tab";
    string sql2 = "odp_varray_sample_proc";

    // create a new simple varray with values 1, 2, 3, and 4.
    SimpleVarray pa = new SimpleVarray();
    pa.Array = new Int32[] { 1, 2, 3, 4 };

    // create status array indicate element 2 is Null
    pa.StatusArray = new OracleUdtStatus[] { OracleUdtStatus.NotNull, 
      OracleUdtStatus.Null, OracleUdtStatus.NotNull, OracleUdtStatus.NotNull };

    // Establish a connection to Oracle
    OracleConnection con = new OracleConnection(constr);
    con.Open();

    OracleCommand cmd = new OracleCommand(sql2, con);
    cmd.CommandType = CommandType.StoredProcedure;

    OracleParameter param = new OracleParameter();
    param.OracleDbType = OracleDbType.Array;
    param.Direction = ParameterDirection.InputOutput;

    // Note: The UdtTypeName is case-senstive
    param.UdtTypeName = "SCOTT.ODP_VARRAY_SAMPLE_TYPE";
    param.Value = pa;
    cmd.Parameters.Add(param);

    // Insert SimpleVarray(1,NULL,3,4,9) into the table
    cmd.ExecuteNonQuery();

    // Print out the updated Simple Varray
    Console.WriteLine("Updated SimpleVarray: " + param.Value);

    // Modify element 3 to Null and element 2 to Not Null
    pa.StatusArray[1] = OracleUdtStatus.NotNull;
    pa.StatusArray[2] = OracleUdtStatus.Null;

    param.Value = pa;

    // Insert SimpleVarray(1,2,NULL,4,9) into the table
    cmd.ExecuteNonQuery();

    // Add/remove some elements by converting the Int32[] to an ArrayList
    ArrayList pa1 = new ArrayList(pa.Array);

    // Create a corresponding array list for the status
    ArrayList sa1 = new ArrayList(pa.StatusArray);

    // remove the first element
    pa1.RemoveAt(0);
    sa1.RemoveAt(0);

    // add element 6
    pa1.Add(6);
    sa1.Add(OracleUdtStatus.NotNull);

    // add a NULL element
    pa1.Add(-1);
    sa1.Add(OracleUdtStatus.Null);

    pa.Array = (Int32[])pa1.ToArray(typeof(Int32));
    pa.StatusArray = (OracleUdtStatus[])sa1.ToArray(typeof(OracleUdtStatus));

    param.Value = pa;

    // Insert SimpleVarray(2,NULL,4,6,NULL,9) into the table
    cmd.ExecuteNonQuery();

    cmd.CommandText = sql1;
    cmd.CommandType = CommandType.Text;
    OracleDataReader reader = cmd.ExecuteReader();

    // Fetch each row and display the VARRAY data
    int rowCount = 0;
    while (reader.Read())
    {
      // Fetch the objects as a custom type
      SimpleVarray p;
      if (reader.IsDBNull(0))
        p = SimpleVarray.Null;
      else
        p = (SimpleVarray)reader.GetValue(0);

      Console.WriteLine("Row {0}: {1}", rowCount++, p);
    }

    // Clean up
    reader.Dispose();
    cmd.Dispose();
    con.Close();
    con.Dispose();
  }
}

/* SimpleVarray Class
**   An instance of a SimpleVarray class represents an
**   ODP_VARRAY_SAMPLE_TYPE object
**   A custom type must implement INullable and IOracleCustomType interfaces
*/
public class SimpleVarray : IOracleCustomType, INullable
{
  [OracleArrayMapping()]
  public  Int32[] Array;

  private OracleUdtStatus[] m_statusArray;
  public OracleUdtStatus[] StatusArray
  {
    get
    {
      return this.m_statusArray;
    }
    set
    {
      this.m_statusArray = value;
    }
  }

  private bool m_bIsNull;

  public bool IsNull
  {
    get
    {
      return m_bIsNull;
    }
  }

  public static SimpleVarray Null
  {
    get
    {
      SimpleVarray obj = new SimpleVarray();
      obj.m_bIsNull = true;
      return obj;
    }
  }

  public void ToCustomObject(OracleConnection con, IntPtr pUdt)
  {
    object objectStatusArray = null;
    Array = (Int32[])OracleUdt.GetValue(con, pUdt, 0, out objectStatusArray);
    m_statusArray = (OracleUdtStatus[])objectStatusArray;
  }

  public void FromCustomObject(OracleConnection con, IntPtr pUdt)
  {
    OracleUdt.SetValue(con, pUdt, 0, Array, m_statusArray);
  }

  public override string ToString()
  {
    if (m_bIsNull)
      return "SimpleVarray.Null";
    else
    {
      string rtnstr = String.Empty;
      if (m_statusArray[0] == OracleUdtStatus.Null)
        rtnstr = "NULL";
      else
        rtnstr = Array.GetValue(0).ToString();
      for (int i = 1; i < m_statusArray.Length; i++)
      {
        if (m_statusArray[i] == OracleUdtStatus.Null)
          rtnstr += "," + "NULL";
        else
          rtnstr += "," + Array.GetValue(i).ToString();
      }
      return "SimpleVarray(" + rtnstr + ")";
    }
  }
}

/* SimpleVarrayFactory Class
**   An instance of the SimpleVarrayFactory class is used to create 
**   SimpleVarray objects
*/
[OracleCustomTypeMapping("SCOTT.ODP_VARRAY_SAMPLE_TYPE")]
public class SimpleVarrayFactory :
  IOracleCustomTypeFactory,   IOracleArrayTypeFactory
{
  // IOracleCustomTypeFactory
  public IOracleCustomType CreateObject()
  {
    return new SimpleVarray();
  }

  // IOracleArrayTypeFactory Inteface
  public Array CreateArray(int numElems)
  {
    return new Int32[numElems];
  }

  public Array CreateStatusArray(int numElems)
  {
    // CreateStatusArray may return null if null status information 
    // is not required.
    return new OracleUdtStatus[numElems];
  }
}

