// Database Setup, if you have not done so yet
/*

connect scott/tiger@oracle
drop table odp_nt_sample_person_rel_tab;
drop type odp_nt_sample_person_coll_type;
drop type odp_nt_sample_student_type;
drop type odp_nt_sample_person_type;

create type odp_nt_sample_person_type as object 
  (name varchar2(30), address varchar2(60), age number(3)) NOT FINAL;
/
create type odp_nt_sample_student_type under odp_nt_sample_person_type
 (dept_id number(2), major varchar2(20));
/
create type odp_nt_sample_person_coll_type as 
 table of odp_nt_sample_person_type;
/

create table odp_nt_sample_person_rel_tab 
 (col1 odp_nt_sample_person_coll_type) nested table col1 store as nt_s;

*/

//C#

using System;
using System.Data;
using System.Collections;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

/// <summary name=PsfArray2>
/// Nested table Sample : Demonstrates how to map, fetch, and manipulate 
///   nested table of UDTs that has a inheritance hierarchy 
///   (i.e. parent and child types)
/// </summary>
class NestedTableSample
{
  static void Main(string[] args)
  {
    string constr = "user id=scott;password=tiger;data source=oracle";
    string sql1 = "insert into odp_nt_sample_person_rel_tab values(:param)";
    string sql2 = "select col1 from odp_nt_sample_person_rel_tab";

    // Create a new Person object
    Person p1 = new Person();
    p1.Name = "John";
    p1.Address = "Address1";
#if NET20
    // Since Age is a .NET 2.0 Nullable Type (which can store nulls), the
    // AgeIsNull property is not required.
#else
    p1.AgeIsNull = false;
#endif
    p1.Age = 20;

    // Create a new Student object
    Student s1 = new Student();
    s1.Name = "Jim";
    s1.Address = "Address1";
#if NET20
    // Since Age is a .NET 2.0 Nullable Type (which can store nulls), the
    // AgeIsNull property is not required.
#else
    s1.AgeIsNull = false;
#endif
    s1.Age = 25;
    s1.Major = "Physics";

    // Create a new Student object
    Student s2 = new Student();
    s2.Name = "Alex";
    s2.Address = "Address3";
#if NET20
    // Since Age is a .NET 2.0 Nullable Type (which can store nulls), the
    // AgeIsNull property is not required.
#else
    s2.AgeIsNull = false;
#endif
    s2.Age = 21;
    s2.Major = "Math";

    // Create a new person array
    Person[] pa = new Person[] { p1, s1 };

    // Establish a connection to Oracle
    OracleConnection con = new OracleConnection(constr);
    con.Open();

    OracleCommand cmd = new OracleCommand(sql1, con);
    cmd.CommandText = sql1;

    OracleParameter param = new OracleParameter();
    param.OracleDbType = OracleDbType.Array;
    param.Direction = ParameterDirection.Input;

    // Note: The UdtTypeName is case-senstive
    param.UdtTypeName = "SCOTT.ODP_NT_SAMPLE_PERSON_COLL_TYPE";
    param.Value = pa;
    cmd.Parameters.Add(param);

    // Insert a nested table of (person, student) into a column of a table
    cmd.ExecuteNonQuery();

    // Modify some elements in Person array
    pa[1].Address = "Modified Address";
    pa[1].Age = pa[1].Age + 1;

    // Add/remove some elements by converting the Person[] to an ArrayList
    ArrayList list = new ArrayList(pa);

    // Remove the first element
    list.RemoveAt(0);

    // Add a new student
    list.Add(s2);
    pa = (Person[])list.ToArray(typeof(Person));

    param.Value = pa;

    // Insert a nested table of (student, person, student, student) 
    //   into a column of a table
    cmd.ExecuteNonQuery();

    cmd.CommandText = sql2;
    cmd.CommandType = CommandType.Text;
    OracleDataReader reader = cmd.ExecuteReader();

    // Fetch each row
    int rowCount = 0;
    while (reader.Read())
    {
      // Fetch the array and print out each element
      Person[] p = (Person[])reader.GetValue(0);
      for (int i = 0; i < p.Length; i++)
        Console.WriteLine("Row {0}, Person[{1}]: {2} ", 
          rowCount, i, p.GetValue(i));
      rowCount++;
    }

    // Clean up
    reader.Dispose();
    cmd.Dispose();
    con.Close();
    con.Dispose();
  }
}

/* Person Class
**   An instance of a Person class represents an 
**     ODP_NT_SAMPLE_PERSON_TYPE object
**   A custom type must implement INullable and IOracleCustomType interfaces
*/
public class Person : INullable, IOracleCustomType
{
  private bool m_bIsNull;         // Whether the Person object is NULL    
  private string m_name;          // "NAME" attribute  
  private OracleString m_address; // "ADDRESS" attribute  
#if NET20
  // Use .NET 2.0 Nullable Types to store NULL attribute values
  private int?    m_age;              // "AGE" attribute
#else
  private int m_age;              // "AGE" attribute

  // Note that if the "NAME" attribute is NULL, then m_name will be set to null
  private bool m_bAgeIsNull = true; // Whether the "AGE" attribute is NULL 
#endif // NET20

  // Implementation of INullable.IsNull
  public virtual bool IsNull
  {
    get
    {
      return m_bIsNull;
    }
  }

  // Person.Null is used to return a NULL Person object
  public static Person Null
  {
    get
    {
      Person p = new Person();
      p.m_bIsNull = true;
      return p;
    }
  }

  // Specify the OracleObjectMappingAttribute to map "Name" to "NAME"
  [OracleObjectMappingAttribute("NAME")]
  // The mapping can also be specified using attribute index 0
  // [OracleObjectMappingAttribute(0)]
  public string Name
  {
    get
    {
      return m_name;
    }
    set
    {
      m_name = value;
    }
  }

  // Specify the OracleObjectMappingAttribute to map "Address" to "ADDRESS"
  [OracleObjectMappingAttribute("ADDRESS")]
  // The mapping can also be specified using attribute index 1
  // [OracleObjectMappingAttribute(1)]
  public OracleString Address
  {
    get
    {
      return m_address;
    }
    set
    {
      m_address = value;
    }
  }

  // Specify the OracleObjectMappingAttribute to map "Age" to "AGE"
  [OracleObjectMappingAttribute("AGE")]
  // The mapping can also be specified using attribute index 2
  // [OracleObjectMappingAttribute(2)]
#if NET20
  public int? Age
#else
  public int Age
#endif
  {
    get
    {
      return m_age;
    }
    set
    {
      m_age = value;
    }
  }

#if NET20  
  // Since Age is a .NET 2.0 Nullable Type (which can store nulls), the
  // AgeIsNull property is not required.
#else
  public bool AgeIsNull
  {
    get
    {
      return m_bAgeIsNull;
    }
    set
    {
      m_bAgeIsNull = value;
    }
  }
#endif

  // Implementation of IOracleCustomType.FromCustomObject()
  public virtual void FromCustomObject(OracleConnection con, IntPtr pUdt)
  {
    // Convert from the Custom Type to Oracle Object

    // Set the "NAME" attribute.     
    // By default the "NAME" attribute will be set to NULL
    if (m_name != null)
    {
      OracleUdt.SetValue(con, pUdt, "NAME", m_name);
      // The "NAME" attribute can also be accessed by specifying index 0
      // OracleUdt.SetValue(con, pUdt, 0, m_name);
    }

    // Set the "ADDRESS" attribute.     
    // By default the "ADDRESS" attribute will be set to NULL
    if (!m_address.IsNull)
    {
      OracleUdt.SetValue(con, pUdt, "ADDRESS", m_address);
      // The "ADDRESS" attribute can also be accessed by specifying index 1
      // OracleUdt.SetValue(con, pUdt, 1, m_address);
    }

    // Set the "AGE" attribute.
#if NET20
    // By default the "AGE" attribute will be set to NULL
    if (m_age != null)
    {
      OracleUdt.SetValue(con, pUdt, "AGE", m_age);
      // The "AGE attribute can also be accessed by specifying index 2
      // OracleUdt.SetValue(con, pUdt, 2, m_age);
    }    
#else
    // By default the "AGE" attribute will be set to NULL
    if (!m_bAgeIsNull)
    {
      OracleUdt.SetValue(con, pUdt, "AGE", m_age);
      // The "AGE attribute can also be accessed by specifying index 2
      // OracleUdt.SetValue(con, pUdt, 2, m_age);
    }
#endif
  }

  // Implementation of IOracleCustomType.ToCustomObject()
  public virtual void ToCustomObject(OracleConnection con, IntPtr pUdt)
  {
    // Convert from the Oracle Object to a Custom Type

    // Get the "NAME" attribute
    // If the "NAME" attribute is NULL, then null will be returned
    m_name = (string)OracleUdt.GetValue(con, pUdt, "NAME");

    // The "NAME" attribute can also be accessed by specifying index 0
    // m_name = (string)OracleUdt.GetValue(con, pUdt, 0);

    // Get the "ADDRESS" attribute
    // If the "ADDRESS" attribute is NULL, 
    // then OracleString.Null will be returned
    m_address = (OracleString)OracleUdt.GetValue(con, pUdt, "ADDRESS");

    // The "NAME" attribute can also be accessed by specifying index 1
    // m_address = (OracleString)OracleUdt.GetValue(con, pUdt, 1);

    // Get the "AGE" attribute
#if NET20
    // If the "AGE" attribute is NULL, then null will  be returned
    m_age = (int?)OracleUdt.GetValue(con, pUdt, "AGE");
    // The "AGE" attribute can also be accessed by specifying index 2
    // m_age = (int?)OracleUdt.GetValue(con, pUdt, 2);    
#else
    // If the "AGE" attribute is NULL, then OracleUdt.GetValue will 
    //   return DBNull.Value
    if (!(m_bAgeIsNull = OracleUdt.IsDBNull(con, pUdt, "AGE")))
      m_age = (int)OracleUdt.GetValue(con, pUdt, "AGE");

    // The "AGE" attribute can also be accessed by specifying index 2
    // if (!(m_bAgeIsNull = OracleUdt.IsDBNull(con, pUdt, 2)))
    //   m_age = (int)OracleUdt.GetValue(con, pUdt, 2);    
#endif    

  }

  public override string ToString()
  {
    // Return a string representation of the custom object
    if (m_bIsNull)
      return "Person.Null";
    else
    {
      string name = (m_name == null) ? "NULL" : m_name;
      string address = (m_address.IsNull) ? "NULL" : m_address.Value;
#if NET20
      string age      = (m_age == null)? "NULL" : m_age.ToString(); 
#else
      string age = (m_bAgeIsNull) ? "NULL" : m_age.ToString();
#endif
      return "Person(" + name + ", " + address + ", " + age + ")";
    }
  }
}

/* PersonFactory Class
**   An instance of the PersonFactory class is used to create Person objects
*/
[OracleCustomTypeMappingAttribute("SCOTT.ODP_NT_SAMPLE_PERSON_TYPE")]
public class PersonFactory : IOracleCustomTypeFactory
{
  // Implementation of IOracleCustomTypeFactory.CreateObject()
  public IOracleCustomType CreateObject()
  {
    // Return a new custom object
    return new Person();
  }
}

/* Student Class
**  An instance of a Student class represents an 
**    ODP_NT_SAMPLE_STUDENT_TYPE object
**  Note that we do not map the "DEPT_ID" attribute (attribute index 3), 
**    so it will always be NULL
**  A custom type must implement INullable and IOracleCustomType interfaces
*/
public class Student : Person, INullable, IOracleCustomType
{
  private bool m_bIsNull;           // Whether the Student object is NULL
  private string m_major;           // "MAJOR" attribute

  // Implementation of INullable.IsNull
  public override bool IsNull
  {
    get
    {
      return m_bIsNull;
    }
  }

  // Student.Null is used to return a NULL Student object
  public new static Student Null
  {
    get
    {
      Student s = new Student();
      s.m_bIsNull = true;
      return s;
    }
  }

  // Specify the OracleObjectMappingAttribute to map "Major" to "MAJOR"
  [OracleObjectMappingAttribute("MAJOR")]
  // The mapping can also be specified using attribute index 4
  // [OracleObjectMappingAttribute(4)]
  public string Major
  {
    get
    {
      return m_major;
    }
    set
    {
      m_major = value;
    }
  }

  // Implementation of IOracleCustomType.FromCustomObject()
  public override void FromCustomObject(OracleConnection con, IntPtr pUdt)
  {
    // Convert from the Custom Type to Oracle Object
    // Invoke the base class conversion method
    base.FromCustomObject(con, pUdt);

    // Set the "MAJOR" attribute. 
    // By default the "MAJOR" attribute will be set to NULL
    if (m_major != null)
      OracleUdt.SetValue(con, pUdt, "MAJOR", m_major);

    // The "MAJOR" attribute can also be accessed by specifying index 4
    // OracleUdt.SetValue(con, pUdt, 4, m_major);
  }

  // Implementation of IOracleCustomType.ToCustomObject()
  public override void ToCustomObject(OracleConnection con, IntPtr pUdt)
  {
    // Convert from the Oracle Object to a Custom Type
    // Invoke the base class conversion method
    base.ToCustomObject(con, pUdt);

    // Get the "MAJOR" attribute
    // If the "MAJOR" attribute is NULL, then "null" will be returned
    m_major = (string)OracleUdt.GetValue(con, pUdt, "MAJOR");

    // The "MAJOR" attribute can also be accessed by specifying index 4
    // m_major = (string)OracleUdt.GetValue(con, pUdt, 4);
  }

  public override string ToString()
  {
    // Return a string representation of the custom object
    if (m_bIsNull)
    {
      return "Student.Null";
    }
    else
    {
      string name = (Name == null) ? "NULL" : Name;
      string address = (Address.IsNull) ? "NULL" : Address.Value;
#if NET20
      string age = (Age == null) ? "NULL" : Age.ToString();
#else
      string age = (AgeIsNull) ? "NULL" : Age.ToString();
#endif
      string major = (m_major == null) ? "NULL" : m_major;
      return "Student(" + name + ", " + address + ", " + age + ", " +
        major + ")";
    }
  }
}

/* StudentFactory Class
**   An instance of the StudentFactory class is used to create Student objects
*/
[OracleCustomTypeMappingAttribute("SCOTT.ODP_NT_SAMPLE_STUDENT_TYPE")]
public class StudentFactory : IOracleCustomTypeFactory
{
  // Implementation of IOracleCustomTypeFactory.CreateObject()
  public IOracleCustomType CreateObject()
  {
    // Return a new custom object
    return new Student();
  }
}

/* PersonArrayFactory Class
**   An instance of the PersonArrayFactory class is used to create Person Array
*/
[OracleCustomTypeMappingAttribute("SCOTT.ODP_NT_SAMPLE_PERSON_COLL_TYPE")]
public class PersonArrayFactory : IOracleArrayTypeFactory
{
  // IOracleArrayTypeFactory Inteface
  public Array CreateArray(int numElems)
  {
    return new Person[numElems];
  }

  public Array CreateStatusArray(int numElems)
  {
    // An OracleUdtStatus[] is not required to store null status information
    return null;
  }

}


