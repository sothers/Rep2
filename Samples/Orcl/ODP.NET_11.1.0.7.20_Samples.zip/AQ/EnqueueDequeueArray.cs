/* Database setup required for this demo

------------------------------------------------------------------
-- SQL to grant appropriate privilege to SCOTT
------------------------------------------------------------------
grant all on DBMS_AQADM to scott;

------------------------------------------------------------------
-- PLSQL to create queue-table and queue and start queue for SCOTT
------------------------------------------------------------------
BEGIN
  DBMS_AQADM.CREATE_QUEUE_TABLE(
    queue_table=>'scott.test_xmlq_tab', 
    queue_payload_type=>'SYS.XMLType', 
    multiple_consumers=>FALSE);

  DBMS_AQADM.CREATE_QUEUE(
    queue_name=>'scott.test_xmlq', 
    queue_table=>'scott.test_xmlq_tab');

  DBMS_AQADM.START_QUEUE(queue_name=>'scott.test_xmlq');
END;
/

------------------------------------------------------------------
-- PLSQL to stop queue and drop queue & queue-table from SCOTT
------------------------------------------------------------------
BEGIN
  DBMS_AQADM.STOP_QUEUE('scott.test_xmlq');

  DBMS_AQADM.DROP_QUEUE(
    queue_name => 'scott.test_xmlq', 
    auto_commit => TRUE);

  DBMS_AQADM.DROP_QUEUE_TABLE(
    queue_table => 'scott.test_xmlq_tab',
    force => FALSE, 
    auto_commit => TRUE);
END;
/
*/

using System;
using System.Text;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

namespace ODPSample
{
  /// <summary>
  /// Demonstrates enqueueing of two messages using EnqueueArray() and 
  /// dequeueing of two messages using DequeueArray().
  /// </summary>
  class EnqueueDequeueArray
  {
    static void Main(string[] args)
    {
      // Create connection
      string constr = "user id=scott;password=tiger;data source=oracle";
      OracleConnection con = new OracleConnection(constr);

      // Create queue
      OracleAQQueue queue = new OracleAQQueue("scott.test_xmlq", con);

      try
      {
        // Open connection
        con.Open();

        // Begin txn for enqueue
        OracleTransaction txn = con.BeginTransaction();

        // Set message type for the queue
        queue.MessageType = OracleAQMessageType.Xml;

        // Prepare messages with XML payload
        OracleAQMessage[] enqMsgs = new OracleAQMessage[2];
        OracleXmlType msg1 = new OracleXmlType(con, "<PERSON><FIRSTNAME>Bob</FIRSTNAME></PERSON>");
        OracleXmlType msg2 = new OracleXmlType(con, "<PERSON><LASTNAME>Marley</LASTNAME></PERSON>");

        enqMsgs[0] = new OracleAQMessage(msg1);
        enqMsgs[1] = new OracleAQMessage(msg2);

        // Prepare to Enqueue
        queue.EnqueueOptions.Visibility = OracleAQVisibilityMode.OnCommit;

        // Enqueue message array
        queue.EnqueueArray(enqMsgs);

        for (int i = 0; i < enqMsgs.Length; i++)
        {
          Console.WriteLine("===== Array Enqueued Message #{0} =====", i);
          Console.WriteLine("Array Enqueued Message Payload      : \n"
            + ((OracleXmlType)(enqMsgs[i].Payload)).Value);
        }

        // Enqueue txn commit
        txn.Commit();

        // Dispose OracleXmlType payload
        msg1.Dispose();
        msg2.Dispose();

        // Begin txn for Dequeue
        txn = con.BeginTransaction();

        // Prepare to Dequeue
        queue.DequeueOptions.Visibility = OracleAQVisibilityMode.OnCommit;
        queue.DequeueOptions.Wait = 10;
        queue.DequeueOptions.ProviderSpecificType = true;

        // Dequeue message array
        OracleAQMessage[] deqMsgs = queue.DequeueArray(2);

        Console.WriteLine();
        for (int i = 0; i < deqMsgs.Length; i++)
        {
          Console.WriteLine("===== Array Dequeued Message #{0} =====", i);
          Console.WriteLine("Array Dequeued Message Payload      :\n "
            + ((OracleXmlType)(deqMsgs[i].Payload)).Value);
        }

        // Dequeue txn commit
        txn.Commit();

        // Dispose OracleXmlType payload
        for (int i = 0; i < deqMsgs.Length; i++)
        {
          ((OracleXmlType)(deqMsgs[i].Payload)).Dispose();
        }

      }
      catch (Exception e)
      {
        Console.WriteLine("Error: {0}", e.Message);
      }
      finally
      {
        // Close/Dispose objects
        queue.Dispose();
        con.Close();
        con.Dispose();
      }
    }
  }
}

