﻿/* Database setup required for this demo

------------------------------------------------------------------
-- SQL to grant appropriate privilege to SCOTT
------------------------------------------------------------------
grant all on DBMS_AQADM to scott;
  
------------------------------------------------------------------
-- SQL to create the UDT
------------------------------------------------------------------
 CREATE TYPE scott.order_typ AS object(
   custno                 NUMBER,
   item                   VARCHAR2(30),
   description            VARCHAR2(1000));
/

------------------------------------------------------------------
-- PLSQL to create queue-table and queue and start queue for SCOTT
------------------------------------------------------------------
BEGIN
  DBMS_AQADM.CREATE_QUEUE_TABLE(
    queue_table=>'scott.testudt_q_tab', 
    queue_payload_type=>'scott.order_typ', 
    multiple_consumers=>FALSE);

  DBMS_AQADM.CREATE_QUEUE(
    queue_name=>'scott.testudt_q', 
    queue_table=>'scott.testudt_q_tab');

  DBMS_AQADM.START_QUEUE(queue_name=>'scott.testudt_q');
END;
/

------------------------------------------------------------------
-- PLSQL to stop queue and drop queue & queue-table from SCOTT
------------------------------------------------------------------
BEGIN
  DBMS_AQADM.STOP_QUEUE('scott.testudt_q');

  DBMS_AQADM.DROP_QUEUE(
    queue_name => 'scott.testudt_q', 
    auto_commit => TRUE);

  DBMS_AQADM.DROP_QUEUE_TABLE(
    queue_table => 'scott.testudt_q_tab',
    force => FALSE, 
    auto_commit => TRUE);
END;
/
*/

using System;
using System.Text;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

namespace ODPSample
{
  /// <summary>
  /// Demonstrates Enqueuing and Dequeuing a UDT (Order Class)
  /// using a single consumer queue
  /// </summary>
  class EnqueueDequeueUDT
  {
    static void Main(string[] args)
    {
      // Create connection
      string constr = "user id=scott;password=tiger;data source=oracle";
      OracleConnection con = new OracleConnection(constr);

      // Create queue
      OracleAQQueue queue = new OracleAQQueue("scott.testudt_q", con);

      try
      {
        con.Open();

        // Begin txn for enqueue
        OracleTransaction txn = con.BeginTransaction();

        // Prepare queue
        queue.MessageType = OracleAQMessageType.Udt;  //This must be set for UDT
        queue.UdtTypeName = "SCOTT.ORDER_TYP"; // This must be set for UDT

        // Prepare message and UDT payload
        OracleAQMessage enqMsg = new OracleAQMessage();

        // Create a new Order object
        Order sales_order = new Order();

        sales_order.Custno = 6104;
        sales_order.Item = "ToothBrush";
        sales_order.Description = "Super Plaque Crushing Model";

        enqMsg.Payload = sales_order;

        // Prepare to Enqueue
        queue.EnqueueOptions.Visibility = OracleAQVisibilityMode.OnCommit;

        // Enqueue message
        queue.Enqueue(enqMsg);

        Console.WriteLine("MessageId of Enqueued Sales Order : " + ByteArrayToString(enqMsg.MessageId));
        Console.WriteLine("Enqueued Sales Order Details: " + sales_order.ToString());

        // Enqueue txn commit
        txn.Commit();

        // Begin txn for Dequeue
        txn = con.BeginTransaction();

        // Prepare to Dequeue
        queue.DequeueOptions.Visibility = OracleAQVisibilityMode.OnCommit;
        queue.DequeueOptions.Wait = 10;

        // Dequeue message
        OracleAQMessage deqMsg = queue.Dequeue();

        Order warehouse_order = (Order)deqMsg.Payload;

        Console.WriteLine("MessageId of Dequeued Warehouse Order: " + ByteArrayToString(deqMsg.MessageId));
        Console.WriteLine("Dequeued Warehouse Packing Order Details: " + warehouse_order.ToString());

        // Dequeue txn commit
        txn.Commit();
      }
      catch (Exception e)
      {
        Console.WriteLine("Error: {0}", e.Message);
      }
      finally
      {
        // Close/Dispose objects
        queue.Dispose();
        con.Close();
        con.Dispose();
      }
    }

    // Function to convert byte[] to string
    static private string ByteArrayToString(byte[] byteArray)
    {
      StringBuilder sb = new StringBuilder();
      for (int n = 0; n < byteArray.Length; n++)
      {
        sb.Append((int.Parse(byteArray[n].ToString())).ToString("X"));
      }
      return sb.ToString();
    }
  }
}

/* Order Class
**   An instance of a Order class represents an order_typ object
**   A custom type must implement INullable and IOracleCustomType interfaces
*/
public class Order : INullable, IOracleCustomType
{
    private bool m_bIsNull;              // Whether the Order object is NULL    
    private int    m_custno;             // "CUSTNO" attribute
    private string m_item;               // "ITEM" attribute  
    private OracleString m_description;  // "DESCRIPTION" attribute  

    // Implementation of INullable.IsNull
    public virtual bool IsNull
    {
        get
        {
            return m_bIsNull;
        }
    }

    // Order.Null is used to return a NULL Order object
    public static Order Null
    {
        get
        {
            Order o = new Order();
            o.m_bIsNull = true;
            return o;
        }
    }

    // Specify the OracleObjectMappingAttribute to map "custno" to "CUSTNO"
    [OracleObjectMappingAttribute("CUSTNO")]
    // The mapping can also be specified using attribute index 0
    // [OracleObjectMappingAttribute(0)]

    public int Custno
    {
        get
        {
            return m_custno;
        }
        set
        {
            m_custno = value;
        }
    }

    // Specify the OracleObjectMappingAttribute to map "Item" to "ITEM"
    [OracleObjectMappingAttribute("ITEM")]
    // The mapping can also be specified using attribute index 1
    // [OracleObjectMappingAttribute(1)]
    public string Item
    {
        get
        {
            return m_item;
        }
        set
        {
            m_item = value;
        }
    }

    // Specify the OracleObjectMappingAttribute to map "Description" to "DESCRIPTION"
    [OracleObjectMappingAttribute("DESCRIPTION")]
    // The mapping can also be specified using attribute index 2
    // [OracleObjectMappingAttribute(2)]
    public OracleString Description
    {
        get
        {
            return m_description;
        }
        set
        {
            m_description = value;
        }
    }



    // Implementation of IOracleCustomType.FromCustomObject()
    public virtual void FromCustomObject(OracleConnection con, IntPtr pUdt)
    {
        // Convert from the Custom Type to Oracle Object

        // Set the "CUSTNO" attribute.    

    // By default the "CUSTNO" attribute will be set to NULL
    if (m_custno != null)
    {
      OracleUdt.SetValue(con, pUdt, "CUSTNO", m_custno);
      // The "CUSTNO attribute can also be accessed by specifying index 0
      // OracleUdt.SetValue(con, pUdt, 0, m_custno);
    }    


        // Set the "NAME" attribute.     
        // By default the "ITEM" attribute will be set to NULL
        if (m_item != null)
        {
            OracleUdt.SetValue(con, pUdt, "ITEM", m_item);
            // The "ITEM" attribute can also be accessed by specifying index 1
            // OracleUdt.SetValue(con, pUdt, 1, m_item);
        }

        // Set the "DESCRIPTION" attribute.     
        // By default the "DESCRIPTION" attribute will be set to NULL
        if (!m_description.IsNull)
        {
            OracleUdt.SetValue(con, pUdt, "DESCRIPTION", m_description);
            // The "DESCRIPTION" attribute can also be accessed by specifying index 2
            // OracleUdt.SetValue(con, pUdt, 2, m_description);
        }

    }

    // Implementation of IOracleCustomType.ToCustomObject()
    public virtual void ToCustomObject(OracleConnection con, IntPtr pUdt)
    {
        // Convert from the Oracle Object to a Custom Type

        // Get the "CUSTNO" attribute

        // If the "CUSTNO" attribute is NULL, then null will  be returned
        m_custno = (int)OracleUdt.GetValue(con, pUdt, "CUSTNO");
        // The "CUSTNO" attribute can also be accessed by specifying index 0
        // m_custno = (int?)OracleUdt.GetValue(con, pUdt, 0);    


        // Get the "ITEM" attribute
        // If the "ITEM" attribute is NULL, then null will be returned
        m_item = (string)OracleUdt.GetValue(con, pUdt, "ITEM");

        // The "ITEM" attribute can also be accessed by specifying index 1
        // m_item = (string)OracleUdt.GetValue(con, pUdt, 1);

        // Get the "DESCRIPTION" attribute
        // If the "DESCRIPTION" attribute is NULL, then OracleString.Null will be returned
        m_description = (OracleString)OracleUdt.GetValue(con, pUdt, "DESCRIPTION");

        // The "DESCRIPTION" attribute can also be accessed by specifying index 2
        // m_description = (OracleString)OracleUdt.GetValue(con, pUdt, 2);

    }

    public override string ToString()
    {
        // Return a string representation of the custom object
        if (m_bIsNull)
            return "Order.Null";
        else
        {

            string custno  = (m_custno == null) ? "NULL" : m_custno.ToString(); 
            string item = (m_item == null) ? "NULL" : m_item;
            string description = (m_description.IsNull) ? "NULL" : m_description.Value;
            return "Order(" + custno + ", " + item + ", " + description + ")";
        }
    }
}

/* OrderFactory Class
**   An instance of the OrderFactory class is used to create Order objects
*/
[OracleCustomTypeMappingAttribute("SCOTT.ORDER_TYP")]
public class OrderFactory : IOracleCustomTypeFactory
{
    // Implementation of IOracleCustomTypeFactory.CreateObject()
    public IOracleCustomType CreateObject()
    {
        // Return a new custom object
        return new Order();
    }
}