These samples show how to use specific ODP.NET features with Oracle Database from .NET Framework 2.0 or higher.  This is the ODP.NET sample code included with ODP.NET 11.1.0.7.20. Subjects include:

1) LOB             		
2) REF Cursor      		
3) Array Binding   	
4) Assoc. Array    	
5) DataSet         		
6) Globalization   	
7) TAF             		
8) Transaction     		
9) XML             		
10)EventHandler    		
11)ClientFactory		
12)CommandBuilder             
13)Connection                   
14)ConnectionStringBuilder     
15)DataReader                   
16)DataSourceEnumSample         
17)UDT                     
18)AQ

===========
LOB Samples 
===========

Sample 1: Demonstrates how an populate and obtain LOB data
          from a DataSet.

Sample 2: Demonstrates how an OracleClob object is obtained 
          as an output parameter of an anonymous PL/SQL block

Sample 3: Demonstrates how an OracleClob object is obtained 
          from an output parameter of a stored procedure

Sample 4: Demonstrates how the LOB column data can be
          read as a .NET type by utilizing stream reads.

Sample 5: Demonstrates how to bind an OracleClob object 
          as a parameter.  This sample also refetches the newly 
          updated CLOB data using an OracleDataReader and an 
          OracleClob object.

Sample6: Demostrates LOB updates using row-level locking.

Sample7: Demostrates LOB updates using result set locking.

AccessBFile: demonstrates accessing BFILEs through ODP.NET.

==================
REF CURSOR SAMPLES
==================

Sample 1: Demonstrates how a REF Cursor is obtained as an 
          OracleDataReader

Sample 2: Demonstrates how a REF Cursor is obtained as an 
          OracleDataReader through the use of an OracleRefCursor object.

Sample 3: Demonstrates how multiple REF Cursors can be accessed 
          by a single OracleDataReader

Sample 4: Demonstrates how a DataSet can be populated from a 
          REF Cursor. The sample also demonstrates how a REF 
          Cursor can be updated.

Sample 5: Demonstrates how a DataSet can be populated from an
          OracleRefCursor object.

Sample 6: Demonstrates how to populate a DataSet with 
          multiple REF Cursors selectively

Sample 7: Demonstrates how to selectively obtain 
          OracleDataReader objects from the REF Cursors

====================
ARRAY BINDING SAMPLE
====================

Sample: Demonstrates array binding

===================
ASSOC. ARRAY SAMPLE
===================

Sample: Demonstrates PL/SQL Associative Array binding

==============
DATASET SAMPLE
==============

Sample 1: DMLOperOnDS
Sample 2: DSDRwithLOB
Sample 3: DSPopulate
Sample 4: DSPopulateVB
Sample 5: DSwithRefCur
Sample 6: SafeTypeMapping
Sample 7: RelationalData
Sample 8: RelationalDataVB


=============
Globalization
=============

Sample 1: Globalization

===
TAF
===

Sample 1: Failover

===========
TRANSACTION
===========

Sample 1: 		SavepointSample
psfTxnScope: 		Demonstrate the usage of TransactionScope.
psfEnlistTransaction:   Demonstrate the usage of EnlistTransaction API.

===========
XML Samples 
===========

XmlProp:        Demonstrates how to use the OracleXmlQueryProperties class.
                Using the OracleXmlSaveProperties class is similar.

XmlQuery:       Demonstrates how to retrieve relational data as an
                XML document.

XmlSave:        Demonstrates how to save changes to relational data
                using an XML document.

XMLStreamProp:  Demonstrates properties and methods of OracleXmlStream

XMLTypeBind:    Demonstrates how to bind OracleXmlType as input parameter

XMLTypeDemo:    Demonstrates properties and methods of OracleXmlType

XMLTypeDS:      Demonstrates how to populate and obtain XMLType data
                from a DataSet.

XMLTypeGet:     Demonstrates how to get XMLType column as Oracle Type or
                .NET type

XMLView:        Usage of OracleXmlType class to retrieve native XML, etc.

XMLViewVB:      VB version -  Usage of OracleXmlType class to retrieve 
                native XML, etc.

XMLTypeSBProp:  Demonstrates properties and methods of OracleXmlType for 
                schema based XML data.

============
EventHandler
============

RowUpdateEventHandler: demonstrate how one can trap the OracleRowUpdatingEvent 
	and OracleRowUpdatedEvent using VB.NET.

==========
ClientFactory
==========

RefClientFactory:   Demonstrates how to use the OracleClientFactory class


=============
CommandBuilder
=============

RefCommandBuilder3:   Demonstrate the CommandBuilder's SchemaSeparator property.
RefCommandBuilder4:   Demonstrate CommandBuilders's QuoteIdentifier method.
RefCommandBuilder5:   Demonstrate CommandBuilders's UnquoteIdentifier method.


=========
Connection
=========

RefConnection6c:   Demonstrate Connection's all GetSchema() method.
RefConnection6d:   Demonstrate Connection's all GetSchema(string) method overload.
RefConnection6e:   Demonstrate Connection's all GetSchema(string, string[]) method overload.


==================
ConnectionStringBuilder
==================

RefConnectionStringBuilder1:   Demonstrates how to use the ConnectionStringBuilder class.


=========
DataReader
=========

RefDataReader2a:   Demonstrates DataReader's VisibleFieldCount & HiddenFieldCount properties.


===================
DataSourceEnumSample
===================

RefDataSourceEnumSample:   Demonstrates the functionality of OracleDataSourceEnumerator class.

===
UDT
===

NestedTable: Demonstrates how to map, fetch, and manipulate nested table of UDTs 
             that has a inheritance hierarchy (i.e. parent and child types)

Object1:     Demonstrates how to map, fetch, and manipulate Oracle UDTs as 
             custom objects.

Object2:     Demonstrates map and manipulate UDTs that has inheritance hierarchy 
             (i.e. parent and child types).  This sample also demonstrates an 
             alternative approach of using application config file to specify 
             the custom type mapping, rather than through the declaration of 
             the OracleCustomTypeMappingAttribute attribute on the factory class.

Object3:     Demonstrates how to map and fetch types similar to Oracle Spatial 
             Types as Custom Types.

Ref1:        Demonstrates how to fetch UDTs that are referenced by REFs.

Ref2:        Demonstrates how to obtain Custom Type objects from OracleRef 
             objects.  It also demonstrates how to update UDTs through the 
             OracleRef object and to obtain the appropriate instantce type for 
             those UDTs that have an inheritance hierarchy from OracleRef objects.

VArray:      Demonstrates how to map, fetch, and manipulate the Oracle VARRAY as 
             a custom object

===
AQ
===

EnqueueDequeue        : Demonstrates Enqueuing and Dequeuing raw message using a 
		        single consumer queue.

AdvanceEnqueueDequeue : Demonstrates Enqueuing and Dequeuing raw message using a 
			secure, multiple consumer queue

EnqueueDequeueArray   : Demonstrates enqueueing of two messages using EnqueueArray() 
		        and dequeueing of two messages using DequeueArray().

Listen      	      : Demonstrates how a thread can listen and wait until a message 
		        is enqueued. Once a message is enqueued, the listening thread returns 
		        from the blocked Listen() method invocation and dequeues the message.

Notification          : Demonstrates how the application can be notified when a message is 
  		        available in a queue.

1) Appropriate modification of the Data Source attribute in the 
   connection strings
2) A SCOTT/TIGER schema in the Oracle database.
3) A correct reference path to Oracle.DataAccess.dll.
4) Check the sample's Readme.html, if one exists.