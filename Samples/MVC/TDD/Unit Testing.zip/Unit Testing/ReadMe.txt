This project uses the Microsoft NorthWind database.
It can be downloaded from here:
http://northwinddatabase.codeplex.com/

The configuration assumes SqlExpress (data source=.\sqlexpress), you will need to change the configuration
for a different SQL instance by modifying the data source (data source=???).
The following shows the current setting in the connectionString:
  <connectionStrings>
    <add name="NorthwindEntities"
         connectionString="metadata=res://*/NorthwindModel.csdl|res://*/NorthwindModel.ssdl|res://*/NorthwindModel.msl;provider=System.Data.SqlClient;provider connection string=&quot;data source=.\sqlexpress;initial catalog=Northwind;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework&quot;"
         providerName="System.Data.EntityClient" />
  </connectionStrings>

