﻿using DataLibrary;
using System;
using System.Collections.Generic;
namespace InventoryServiceLayer
{
    interface IInventoryService : IDisposable
    {
        /*
         * Just a small set of requirements for demo purposes
         */
        int CountProductsInCategory(int categoryId);
        event EventHandler OnSaved;
        event EventHandler OnSaving;
        void PurchaseProduct(int ID);
    }
}
