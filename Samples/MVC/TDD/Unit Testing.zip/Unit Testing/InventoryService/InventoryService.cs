﻿using DataLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLibrary.Repository;

namespace InventoryServiceLayer
{
    public class InventoryService : IInventoryService
    {

        public event EventHandler OnSaving = (o, e) => { };
        public event EventHandler OnSaved = (o, e) => { };

        DataAccess _dataAccess;
        public InventoryService()
            : this(new DataAccess())
        {

        }

        public InventoryService(DataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }
        #region Unit Test

        /*
         * 
         * These methods are tested in the unit test project.
         */
        public void PurchaseProduct(int ID)
        {
            throw new NotImplementedException();

        }

        public int CountProductsInCategory(int categoryId)
        {
            throw new NotImplementedException();

        }

        public void CommitChanges()
        {
            throw new NotImplementedException();
        }


        public void Dispose()
        {
            throw new NotImplementedException();
        }
        
        #endregion
    }

    [Serializable]
    public class OutOfStockException : Exception
    {
        public OutOfStockException() { }
        public OutOfStockException(string message) : base(message) { }
        public OutOfStockException(string message, Exception inner) : base(message, inner) { }
        protected OutOfStockException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }
}
