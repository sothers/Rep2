﻿
/*
 * Terminology
 * 
 * Fake: A fake simulates just enough of the real behavior to enable tests of your component to work.
 * Useful when abstraction required but its behavior is not of interest
 * 
 * Stubs: Stubs are generated from interfaces in the target project (SUT).
 * The Stub object is just an implementation of the interface designed to return specific values
 * 
 * Shims: Shims simply re-route the call from the production target to the test delegate.
 * Useful when you are calling a platform method whose source you can't change, or "black box" testing.
 * 
 * Spies: Give insight into the behavior of SUT. Can record data passed from SUT, 
 * check that events are handled, or verify the order of demarcated operations.
 */
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using DataLibrary.Repository;
using DataLibrary;
using DataLibrary.Repository.Fakes;
using System.Collections.Generic;

using System.Linq;
using InventoryServiceLayer;
using Microsoft.QualityTools.Testing.Fakes.Stubs;
using Microsoft.QualityTools.Testing.Fakes;

namespace InventoryTestProject
{


    [TestClass]
    public class InventoryTest
    {
        List<Product> _products;
        List<Category> _categories;
        DataAccess _realDataProvider;
        InventoryService _realInventoryService;
        // TODO: Add stub backing fields for ProductRepository, CategoryRepository, and UnitOfWork
        
        [TestInitialize]
        public void TestInitialize()
        {
            // TODO: Add stubs for the CategoryRepository, ProductRepository, and UnitOfWork

            _categories = new List<Category>();
            _categories.Add(new Category() { CategoryID = 1, CategoryName = "Beverages" });
            _categories.Add(new Category() { CategoryID = 2, CategoryName = "Snacks" });

            _products = new List<Product>();
            _products.Add(new Product() { ProductID = 1, CategoryID = 1, ProductName = "Chai", UnitPrice = 10 , UnitsInStock = 10});
            _products.Add(new Product() { ProductID = 2, CategoryID = 1, ProductName = "Sweet Tea", UnitPrice = 20 });
            _products.Add(new Product() { ProductID = 3, CategoryID = 1, ProductName = "Orange Juice", UnitPrice = 11, UnitsInStock = 1 });
            _products.Add(new Product() { ProductID = 5, CategoryID = 2, ProductName = "Potato Chips", UnitPrice = 4, UnitsInStock = 3 });
            _products.Add(new Product() { ProductID = 6, CategoryID = 2, ProductName = "Chocolate Chip Cookies", UnitPrice = 2, UnitsInStock = 5 });


            // TODO: Create instances of the real DataProvider and real InventoryService 

        }

        [TestMethod]
        public void CountProductsInCategory_WhenCalled_ReturnTotalNumberOfProducts()
        {
            // TODO: Implement behavior for ProductRepository.GetProductsByCategory
            // TODO: Call InventoryService.CountProductsInCategory
            // TODO: Assert count accurate; 3 for category 1
            Assert.Inconclusive();
        }

        [TestMethod]
        public void PurchaseProduct_WhenProductInStock_UnitsInStockIsDecremented()
        {
            // TODO: Implement behavior for ProductRepository.GetProduct and ProductRepository.UpdateProduct
            // TODO: Call InventoryService.PurchaseProduct
            // TODO: Assert UnitsInStock decremented

            Assert.Inconclusive();

        }

        [TestMethod]
        public void PurchaseProduct_WhenCalledWithProductInStock_ProductIsUpdated()
        {
            // TODO: Implement behavior for ProductRepository.GetProduct and ProductRepository.UpdateProduct
            // TODO: Call InventoryService.PurchaseProduct
            // TODO: Assert UpdateProduct is called

            Assert.Inconclusive();

        }


        [TestMethod]
        public void PurchaseProduct_WhenProductNotInStock_ThrowsOutOfStock()
        {
            // TODO: Implement behavior for ProductRepository.GetProduct and ProductRepository.UpdateProduct
            // TODO: Call InventoryService.PurchaseProduct

            Assert.Inconclusive();
        }


        [TestMethod]
        public void CommitChanges_WhenCalled_OnSavingEventIsRaisedBeforeAndAfterSave()
        {
            // TODO: Use the SpyPersist class to spy on the InventoryService.CommitChanges method.
            // This will verify that OnSaving is called before SaveChanges, followed by OnSaved

            Assert.Inconclusive();

        }


        [TestMethod]
        public void Dispose_WhenServiceDisposed_DataProviderAlsoDisposed()
        {

            // TODO: Use a shim to verify that the InventoryService.Dispose method causes the
            // data provider to be disposed

            Assert.Inconclusive();

        }

    }
    public class SpyPersist 
    {
        public SpyPersist()
        {
            OnSaving = OnSaveChanges = OnSaveChanges = false;
        }
        public bool OnSaving { get; set; }
        public bool OnSaveChanges { get; set; }
        public bool OnSaved { get; set; }

        private InventoryService _provider = null;
        private StubIUnitOfWork _uow = null;
        public SpyPersist(InventoryService provider, StubIUnitOfWork uow)
        {
            _provider = provider;
            _provider.OnSaving += Provider_OnSaving;
            _provider.OnSaved += Provider_OnSaved;
            _uow = uow;
            _uow.Save = UoW_OnSave;
        }

        void Provider_OnSaving(object sender, EventArgs e)
        {
            OnSaving = true;
        }

        void UoW_OnSave()
        {
            if (!OnSaving) // must follow OnSaving
            {
                throw new DemarcationException();
            }
            OnSaveChanges = true;
        }

        void Provider_OnSaved(object sender, EventArgs e)
        {
            if (!OnSaveChanges) // must follow OnSave
            {
                throw new DemarcationException();
            }
            OnSaved = true;
        }

      
    }

    public class DemarcationException : Exception
    {
        public DemarcationException() { }

    }


}
