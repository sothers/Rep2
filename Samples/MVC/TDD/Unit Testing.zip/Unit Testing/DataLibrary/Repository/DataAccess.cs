﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLibrary.Repository
{
    public class DataAccess : IDisposable
    {
        IUnitOfWork _context;
        IProductRepository _productRepository;
        ICategoryRepository _categoryRepository;
        public DataAccess() 
        {
            _context = new NorthwindEntities() as IUnitOfWork;
            _productRepository = new ProductRepository(_context);
            _categoryRepository = new CategoryRepository(_context);

        }

        // support DI for testing, IOC
        public DataAccess(IUnitOfWork ctx, ICategoryRepository categoryRepository, IProductRepository productRepository)
        {
            _context = ctx;
            _productRepository = productRepository;
            _categoryRepository = categoryRepository;
        }

        /*
         * Usually we would customize the data access layer
         * thus not needing to expose the repositories, but
         * this is an option
         */
        #region Exposed Repositories
        public IUnitOfWork Context
        {
            get { return _context; }
            set { _context = value; }
        }
        public ICategoryRepository ICategoryRepository
        {
            get
            {
                return _categoryRepository;
            }

        }
        public IProductRepository IProductRepository
        {
            get
            {
                return _productRepository;
            }
        }
        
        #endregion

        public void SaveChanges()
        {
            _context.Save();
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
