﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLibrary.Repository
{
    internal class CategoryRepository : ICategoryRepository
    {
        NorthwindEntities _ctx = null;
        public CategoryRepository(IUnitOfWork unitOfWork)
        {
            if (unitOfWork == null)
            {
                throw new ArgumentNullException("unitOfWork");
            }
            _ctx = unitOfWork as NorthwindEntities;
        }

        public IEnumerable<Category> GetCategories()
        {
            return _ctx.Categories.ToList();
        }

        public Category GetCategory(int id)
        {
            return _ctx.Categories.Single(c => c.CategoryID == id);
        }

        public void AddCategory(string categoryName, string description)
        {
            Category category = new Category()
            {
                CategoryName = categoryName,
                Description = description,
            };
            _ctx.Categories.Add(category);
        }
    }
}
