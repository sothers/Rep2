﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLibrary.Repository
{
    internal class ProductRepository : IProductRepository
    {
        NorthwindEntities _ctx = null;
        public ProductRepository(IUnitOfWork unitOfWork)
        {
            if (unitOfWork == null)
            {
                throw new ArgumentNullException("unitOfWork");
            }
            _ctx = unitOfWork as NorthwindEntities;
        }
        public IEnumerable<Product> GetProducts()
        {
            return _ctx.Products.ToList();
        }

        public IEnumerable<Product> GetProductsByCategory(int id)
        {
            return _ctx.Products.Where( c => c.CategoryID == id).ToList();
        }

        public Product GetProduct(int id)
        {
            return _ctx.Products.SingleOrDefault(p => p.ProductID == id);
        }

        public void UpdateProduct(Product entity)
        {
            _ctx.Entry<Product>(entity).State = EntityState.Modified;
        }


    }
}
