﻿using DataLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLibrary.Repository;

namespace InventoryServiceLayer
{
    public class InventoryService : IInventoryService
    {

        public event EventHandler OnSaving = (o, e) => { };
        public event EventHandler OnSaved = (o, e) => { };

        DataAccess _dataAccess;
        public InventoryService()
            : this(new DataAccess())
        {

        }

        public InventoryService(DataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }
        #region Unit Test

        /*
         * 
         * These methods are tested in the unit test project.
         */
        public void PurchaseProduct(int id)
        {
            Product p = _dataAccess.IProductRepository.GetProduct(id);

            if (!p.UnitsInStock.HasValue || p.UnitsInStock == 0)
            {
                throw new OutOfStockException();
            }

            --(p.UnitsInStock);
            _dataAccess.IProductRepository.UpdateProduct(p);

        }

        public int CountProductsInCategory(int id)
        {
            int count = (from p in _dataAccess.IProductRepository.GetProductsByCategory(id)
                         select p).Count();
            return count;

        }

        public void CommitChanges()
        {
            OnSaving(this, EventArgs.Empty);
            _dataAccess.SaveChanges();
            OnSaved(this, EventArgs.Empty);


        }


        public void Dispose()
        {
            _dataAccess.Dispose();
        }
        
        #endregion
    }

    [Serializable]
    public class OutOfStockException : Exception
    {
        public OutOfStockException() { }
        public OutOfStockException(string message) : base(message) { }
        public OutOfStockException(string message, Exception inner) : base(message, inner) { }
        protected OutOfStockException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }
}
