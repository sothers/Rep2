ASP.NET MVC 5 Authentication Filters
==========================

Explore the new IAuthenticationFilter which allows you to customize authentication within an ASP.NET MVC 5 application. This code is for the Article in DNC .NET Magazine Issue 9 (November-December 2013). The magazine is absolutely Free. [Subscribe Now](http://www.dotnetcurry.com/magazine).

* Author: [Raj Aththanayake](http://www.dotnetcurry.com/Author.aspx?AuthorName=Raj%20Aththanayake)
* Twitter: [@raj_kba](http://www.twitter.com/raj_kba)
* Date: November 1, 2013
* Version: 0.0.1
* Website: [DNC Magazine](http://www.dncmagazine.com)
* GitHub: [DNC Magazine on Github](https://github.com/dotnetcurry/mvc5-auth-filter-dncmag-09)
