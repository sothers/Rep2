﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.Mvc;
using System.Net;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication1.Controllers
{
    public class PersonModel
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }

    [Route("api/people")]
    public class PersonController : Controller
    {
        static List<PersonModel> people = new List<PersonModel>
        {
            new PersonModel {Name = "Brock", Age = 32 },
            new PersonModel {Name = "Alice", Age = 52 },
            new PersonModel {Name = "Bob", Age = 42 },
        };

        [HttpGet]
        [Route("")]
        public IActionResult Get()
        {
            return new ObjectResult(people);
        }

        [HttpGet]
        [Route("{id:int}")]
        //[Produces("application/xml")]
        public IActionResult Get(int id)
        {
            if (id >= people.Count)
            {
                return HttpNotFound();
            }

            return new ObjectResult(people[id]);
        }


        [HttpPut]
        [Route("{id:int}")]
        public IActionResult Put(int id, [FromBody] PersonModel model)
        {
            if (id >= people.Count)
            {
                return HttpNotFound();
            }

            people[id] = model;

            return new HttpStatusCodeResult((int)HttpStatusCode.NoContent);
        }
    }
}
