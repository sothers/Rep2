﻿using Microsoft.AspNet.Razor.Runtime.TagHelpers;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace WebApplication1
{
    [TargetElement("app-name")]
    [TargetElement(Attributes ="app-name")]
    public class AppNameTagHelper : TagHelper
    {
        private MyConfig _config;

        public AppNameTagHelper(MyConfig config)
        {
            _config = config;
        }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            if (output.TagName == "app-name")
            {
                output.TagName = "div";
            }

            output.Content.SetContent(_config.AppName);
        }
    }
}
