﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.Builder;
using Microsoft.AspNet.Mvc.Xml;
using Microsoft.AspNet.Http;
using Microsoft.Framework.DependencyInjection;
using Microsoft.Framework.Configuration;
using Microsoft.Framework.Runtime;

namespace WebApplication1
{
    public interface IFoo
    {
        string GetFoo();
    }
    public class Foo : IFoo
    {
        private MyConfig _config;

        public Foo(MyConfig config)
        {
            _config = config;
        }

        public string GetFoo()
        {
            return _config.AppName + " from the Foo class";
        }
    }

    public class MyConfig
    {
        public string AppName { get; set; }
    }
    

    public class Startup
    {
        IConfiguration config;

        public Startup(IApplicationEnvironment env)
        {
            var builder = 
                new ConfigurationBuilder(env.ApplicationBasePath)
                .AddJsonFile("config.json")
                .AddJsonFile($"config.{env.Configuration}.json", false)
                .AddEnvironmentVariables();

            config = builder.Build();
        }

        public void ConfigureServices(IServiceCollection services)
        {

            services.AddInstance(new MyConfig
            {
                AppName = config.Get("app:appName")
            });

            //services.AddSingleton<IFoo, Foo>();
            //services.AddInstance<IFoo>(new Foo());
            services.AddTransient<IFoo, Foo>();
            //services.AddScoped<IFoo, Foo>();

            services.AddMvc().ConfigureMvc(mvc =>
            {
                //mvc.Filters.Add(new Authoriz)
                //mvc.AntiForgeryOptions.CookieName
                //mvc.ViewEngines.Add()
                
                //mvc.RespectBrowserAcceptHeader = true;
                mvc.OutputFormatters.Add(new XmlDataContractSerializerOutputFormatter());
            });
        }

        public void Configure(IApplicationBuilder app)
        {
            app.UseMvc(routes =>
            {
                routes.MapRoute("default", 
                    "{controller=Home}/{action=Index}");
            });

            //app.UseMiddleware<MyMiddleware>();
            //app.Run(async (context) =>
            //{
            //    var foo = context.RequestServices.GetRequiredService<IFoo>();
            //    await context.Response.WriteAsync(foo.GetFoo());
            //});
        }
    }
}
