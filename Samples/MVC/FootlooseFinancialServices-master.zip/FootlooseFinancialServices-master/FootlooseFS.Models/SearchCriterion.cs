﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FootlooseFS.Models
{
    public class SearchCriterion
    {
        public string Column { get; set; }
        public string Value { get; set; }
    }
}