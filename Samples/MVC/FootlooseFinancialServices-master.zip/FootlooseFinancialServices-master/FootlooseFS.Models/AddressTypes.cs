﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FootlooseFS.Models
{
    public enum AddressTypes
    {
        Home = 1,
        Work = 2,
        Alternate = 3
    }
}
