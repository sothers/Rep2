﻿namespace IBuyStuff.Application.InputModels.Home
{
    public class IndexInputModel
    {
        public IndexInputModel()
        {
            NumberOfFeaturedProducts = 3;
        }
        public int NumberOfFeaturedProducts { get; set; } 
    }
}