﻿namespace IBuyStuff.Application.Commands
{
    public class Command
    {
        public string Id { get; set; } 
    }
}