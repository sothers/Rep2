﻿namespace IBuyStuff.QueryModel.Shared
{
    public enum Gender
    {
        Male = 1,
        Female = 2
    }
}