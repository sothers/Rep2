﻿namespace IBuyStuff.QueryModel.Shared
{
    public class InvalidCreditCard : CreditCard
    {
        public static InvalidCreditCard Instance = new InvalidCreditCard();
    }
}