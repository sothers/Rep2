﻿namespace IBuyStuff.QueryModel.Shared
{
    public enum CreditCardType
    {
        Unknown = 0,
        Visa = 1,
        Mastercard = 2,
        Amex = 3
    }
}