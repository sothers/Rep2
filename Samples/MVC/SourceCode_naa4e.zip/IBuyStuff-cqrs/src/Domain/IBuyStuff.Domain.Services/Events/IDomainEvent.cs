﻿namespace IBuyStuff.Domain.Services.Events
{
    public interface IDomainEvent
    {
         
    }
}