﻿namespace IBuyStuff.Domain
{
    public interface IAggregateRoot
    {
    }
}