﻿namespace IBuyStuff.Domain.Orders
{
    public class OrderPaymentConfirmation
    {
        public string TransactionId { get; set; }
    }
}
